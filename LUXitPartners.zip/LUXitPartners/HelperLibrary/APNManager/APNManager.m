//
//  APNManager.m
//  Luxit-Partners
//
//  Created by GP on 31/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "APNManager.h"

#import <AudioToolbox/AudioToolbox.h>

@implementation APNManager

#pragma mark- Singleton

static APNManager * _sharedAPNManager = nil;

+(APNManager *)singleton
{
    @synchronized([APNManager class])
    {
        if (!_sharedAPNManager)
        {
            _sharedAPNManager=[[self alloc] init];
        }
        
		return _sharedAPNManager;
	}
	return nil;
}


+(id)alloc
{
	@synchronized([APNManager class])
    {
		_sharedAPNManager = [super alloc];
		
        return _sharedAPNManager;
	}
	return nil;
}


-(id)init
{
	self = [super init];
	
    if (self != nil)
    {
        _notificationPopover=[[NotificationPopover alloc]init];
       
        appDelegate().receiveRemoteNotification=^(NSDictionary *dictionary,BOOL isFromBackground)
        {
            [self performSelector:@selector(handlePushNotificationOnReception:) withObject:dictionary afterDelay:0.5];
        };
	}
	return self;
}


- (void)handlePushNotificationOnReception:(NSDictionary *)userInfo
{
    //[ccManager() showAlertWithTitle:[NSString stringWithFormat:@"%@",userInfo] message:@"" buttons:nil completion:nil];
    
    NSDictionary *_jobDictionary=[[[userInfo objectForKey:@"aps"]objectForKey:@"record"]objectForKey:@"jobDescription"];

    if ([[[_jobDictionary objectForKey:@"jobStatus"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]isEqualToString:@"Searching"])
    {
        if (_updateViewOnReceptionOfRemoteNotification)
        {
            NSDateFormatter *_dateFormatter = [[NSDateFormatter alloc] init];
            
            NSTimeZone *_standardTimeZone = [NSTimeZone timeZoneWithName:SERVER_TIMEZONE];
            [_dateFormatter setTimeZone:_standardTimeZone];
            [_dateFormatter setDateFormat:SERVER_TIMEFORMAT];
            
            NSDate *_jobTiming = [_dateFormatter dateFromString:[_jobDictionary objectForKey:@"date"]];
            
            NSMutableDictionary *_jobDetail=[NSMutableDictionary dictionaryWithDictionary:[[userInfo objectForKey:@"aps"]objectForKey:@"record"]];
         
            NSMutableDictionary *_jobDescription=[NSMutableDictionary dictionaryWithDictionary:[_jobDetail objectForKey:@"jobDescription"]];
            NSDateFormatter *_newDateFormatter=[[NSDateFormatter alloc]init];
            [_newDateFormatter setDateFormat:SERVER_TIMEFORMAT];
            [_jobDescription setObject:[_newDateFormatter stringFromDate:_jobTiming] forKey:@"date"];
            
            [_jobDetail setObject:_jobDescription forKey:@"jobDescription"];
            
            NSMutableDictionary *_consumerDescription=[NSMutableDictionary dictionaryWithDictionary:[_jobDetail objectForKey:@"consumerInfo"]];
          
            if ([((NSDictionary *)[[[userInfo objectForKey:@"aps"]objectForKey:@"record"]objectForKey:@"consumerInfo"]).allKeys containsObject:@"rating"] && (NSNull *)[((NSDictionary *)[[[userInfo objectForKey:@"aps"]objectForKey:@"record"]objectForKey:@"consumerInfo"]) objectForKey:@"rating"]!=[NSNull null])
            {
                
            }
            else
            {
                [_consumerDescription setObject:@"0" forKey:@"rating"];
            }
            
            [_jobDetail setObject:_consumerDescription forKey:@"consumerInfo"];
            _updateViewOnReceptionOfRemoteNotification(YES,_jobDetail,NO);
        }
    }
    else  if ([[[_jobDictionary objectForKey:@"jobStatus"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]isEqualToString:@"cancel by consumer"])
    {
        [ccManager() showAlertWithTitle:[[userInfo objectForKey:@"aps"]objectForKey:@"alert"] message:nil buttons:nil completion:nil];
       
        NSMutableDictionary *_jobDetail=[NSMutableDictionary dictionaryWithDictionary:[[NSUserDefaults standardUserDefaults]objectForKey:@"LastJobDetail"]];
        [_jobDetail setObject:@"3" forKey:@"status"];
        [[NSUserDefaults standardUserDefaults]setObject:_jobDetail forKey:@"LastJobDetail"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [appDelegate().jobDetail updateWithAttributes:_jobDetail];
       
         appDelegate().jobDetail.changed=YES;
       
        if (_updateViewOnReceptionOfRemoteNotification)
        {
            _updateViewOnReceptionOfRemoteNotification(NO,nil,NO);
        }
    }
    else
    {
        if (_updateViewOnReceptionOfRemoteNotification)
        {
            _updateViewOnReceptionOfRemoteNotification(NO,nil,YES);
        }
    }
}

@end

APNManager *apnManager(void){
    return [APNManager singleton];
}
