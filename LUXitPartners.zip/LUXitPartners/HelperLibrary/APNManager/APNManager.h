//
//  APNManager.h
//  Luxit-Partners
//
//  Created by GP on 31/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "NotificationPopover.h"

@interface APNManager : NSObject
{
    NotificationPopover *_notificationPopover;
}
@property (nonatomic, copy)void(^updateViewOnReceptionOfRemoteNotification)(BOOL,NSDictionary *,BOOL);

+ (APNManager *)singleton;

@end

APNManager *apnManager(void);