//
//  CustomLayer.h
//  Luxit-Partners
//
//  Created by GP on 31/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//
typedef enum
{
    GMVertical,
    GMHorizontal
}
GradientMode;

#import <UIKit/UIKit.h>

@interface CustomLayer : UIView

- (id)initWithFrame:(CGRect)frame withColors:(NSArray *)colors gradientMode:(GradientMode)mode;

@end
