#import "APNManager.h"
#import "APIManager.h"
#import "CustomLayer.h"
#import "LAAppDelegate.h"
#import "MBProgressHUD.h"
#import "CustomComponents.h"
#import "NSMutableAttributedString+CustomString.h"
#import "UIViewController+LAParentViewController.h"


#define FONT_AVENIRNEXT_REGULAR   @"Avenir Next"
#define FONT_AVENIRNEXT_BOLD      @"AvenirNext-Bold"
#define FONT_AVENIRNEXT_DEMI      @"AvenirNext-DemiBold"
#define FONT_AVENIRNEXT_LIGHT     @"AvenirNext-UltraLight"
#define FONT_AVENIRNEXT_MEDIUM    @"AvenirNext-Medium"


#define   APP_THEME_COLOR       [UIColor colorWithRed:76.0/255.0f   green:162.0/255.0f  blue:203.0/255.0f   alpha:1.0]
#define   COLOR_THEME_RED       [UIColor colorWithRed:225.0/255.0   green:57.0/255.0    blue:55.0/255.0     alpha:1.0]
#define   COLOR_THEME_BLUE      [UIColor colorWithRed:33.0/255.0    green:60.0/255.0    blue:136.0/255.0    alpha:1.0]
#define   COLOR_THEME_BROWN     [UIColor colorWithRed:175.0/255.0   green:131.0/255.0   blue:84.0/255.0     alpha:1.0]
#define   COLOR_THEME_LIGHTBLUE [UIColor colorWithRed:157.0/255.0   green:219.0/255.0   blue:255.0/255.0    alpha:1.0]
#define   COLOR_THEME_DARKGRAY  [UIColor colorWithRed:51.0/255.0    green:50.0/255.0    blue:52.0/255.0     alpha:1.0]
#define   COLOR_THEME_LIGHTPINK [UIColor colorWithRed:253.0/255.0   green:215.0/255.0   blue:187.0/255.0    alpha:1.0]


#define SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)
#define SCREEN_MAX_LENGTH (MAX(SCREEN_WIDTH, SCREEN_HEIGHT))
#define SCREEN_MIN_LENGTH (MIN(SCREEN_WIDTH, SCREEN_HEIGHT))

#define IS_IPHONE_5             ([[UIScreen mainScreen ] bounds].size.height >= 568.0f)
#define IS_IPHONE               (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
#define IS_IPHONE_6P            (IS_IPHONE && SCREEN_MAX_LENGTH == 736.0)
#define IS_IPHONE_6             (IS_IPHONE && SCREEN_MAX_LENGTH > 600.0)
#define DEGREES_IN_RADIANS(x)   (M_PI * x / 180.0)

#define  APPURL                     @"http://register.luxit.me/index.php/userapis/"
#define  APPURL_1                   @"http://register.luxit.me/index.php/technicianapis/"
#define  APPURL_2                   @"http://register.luxit.me/index.php/Jobapis/"
#define  APPURL_3                   @"http://register.luxit.me/index.php/paymentapis/"
//#define  APPURL_4                   @"http://register.luxit.me/index.php/Myjobs/"
#define  IMAGEURL                   @"http://register.luxit.me/app/webroot/img/profile/%@"

#define  LOGIN_EXTENSION            @"login"
#define  SIGNUP_EXTENSION           @"signup"
#define  FORGOTPASSWORD_EXTENSION   @"forget_password"
#define  JOBSTATUS_EXTENSION        @"last_accepted_job_status"
#define  AVAILABILITY_EXTENSION     @"changeavailablity"
#define  GETJOBS_EXTENSION          @"getJob"
#define  CHANGEJOBSTATUS_EXTENSION  @"change_job_status"
#define  SENDFEEDBACK_EXTENSION     @"sendfeedback"
#define  GETJOBHISTORY_EXTENSION    @"get_technician_job_history"
#define  CHANGELOCATION_EXTENSION   @"change_location"
#define  GETUSERDETAIL_EXTENSION    @"get_technician_detail"
#define  UPDATEPASSWORD_EXTENSION   @"changePassword"
#define  UPDATETOKEN_EXTENSION      @"update_deviceToken"
#define  CHECKLUXINGJOBCOUNT        @"checkforluxing"


#define  FBIconImagePath            @"https://graph.facebook.com/%@/picture?width=%@&height=%@"


#define  SERVER_TIMEZONE            @"Australia/Sydney"
#define  SERVER_TIMEFORMAT          @"yyyy-MM-dd HH:mm:ss"

//com.luxit.luxitPartners
