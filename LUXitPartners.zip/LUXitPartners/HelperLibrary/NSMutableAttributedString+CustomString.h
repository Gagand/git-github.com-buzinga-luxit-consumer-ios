//
//  NSMutableAttributedString+CustomString.h
//  Luxit-Partners
//
//  Created by GP on 31/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//


#define kASTextColor        @"TextColor"
#define kASCharacterSpace   @"CharacterSpace"
#define kASText             @"Text"
#define kASTextFont         @"TextFont"
#define kASLineSpace        @"LineSpace"
#define kASTextAlignment    @"TextAlginment"
#define kASIsUnderLine      @"IsUnderLine"

#import <Foundation/Foundation.h>

@interface NSMutableAttributedString (CustomString)

+ (NSMutableAttributedString *) attributedStringWithCharacterSpace:(float)space string:(NSString *)string fontName:(NSString *)fontName fontSize:(float)size textColor:(UIColor *)color lineSpace:(float)lineSpace;

+ (NSMutableAttributedString *) attributedStringWithAttributes:(NSDictionary *)attributes;

@end
