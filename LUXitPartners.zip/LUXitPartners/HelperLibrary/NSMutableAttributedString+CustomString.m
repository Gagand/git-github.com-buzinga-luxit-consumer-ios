//
//  NSMutableAttributedString+CustomString.m
//  Luxit-Partners
//
//  Created by GP on 31/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "NSMutableAttributedString+CustomString.h"

@implementation NSMutableAttributedString (CustomString)

+ (NSMutableAttributedString *) attributedStringWithCharacterSpace:(float)space string:(NSString *)string fontName:(NSString *)fontName fontSize:(float)size textColor:(UIColor *)color lineSpace:(float)lineSpace
{
    NSMutableParagraphStyle *_style = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    [_style setAlignment:NSTextAlignmentCenter];
    [_style setLineBreakMode:NSLineBreakByWordWrapping];
   
    if (lineSpace>0)
    {
        [_style setLineSpacing:lineSpace];
    }
   
    
    UIFont *_font1 = [UIFont fontWithName:fontName size:size];
    
    NSDictionary *_dict1 = @{
                             NSUnderlineStyleAttributeName:@(NSUnderlineStyleNone),
                             NSFontAttributeName:_font1,
                             NSParagraphStyleAttributeName:_style,
                             NSForegroundColorAttributeName:color
                             };
    
    NSMutableAttributedString *_attributedString = [[NSMutableAttributedString alloc] init];

    [_attributedString appendAttributedString:[[NSAttributedString alloc] initWithString:string    attributes:_dict1]];
   
    if (space>0.0)
    {
        [_attributedString addAttribute:NSKernAttributeName value:@(space) range:NSMakeRange(0, [string length])];
    }

    return _attributedString;
}

+ (NSMutableAttributedString *) attributedStringWithAttributes:(NSDictionary *)attributes
{
    NSMutableParagraphStyle *_style = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    [_style setAlignment:NSTextAlignmentCenter];
    [_style setLineBreakMode:NSLineBreakByWordWrapping];
    
    if ([attributes.allKeys containsObject:kASLineSpace])
    {
        [_style setLineSpacing:[[attributes objectForKey:kASLineSpace]floatValue]];
    }
    
    if ([attributes.allKeys containsObject:kASTextAlignment])
    {
        [_style setAlignment:[[attributes objectForKey:kASTextAlignment]integerValue]];
    }
    
    UIFont *_font1 = [UIFont fontWithName:@"Helvatica" size:12];
    
    if ([attributes.allKeys containsObject:kASTextFont])
    {
        _font1= [attributes objectForKey:kASTextFont];
    }
    
    UIColor *_color=[UIColor blackColor];
    
    if ([attributes.allKeys containsObject:kASTextColor])
    {
        _color= [attributes objectForKey:kASTextColor];
    }
    
    NSDictionary *_dict1 = @{
                             NSUnderlineStyleAttributeName:@(NSUnderlineStyleNone),
                             NSFontAttributeName:_font1,
                             NSParagraphStyleAttributeName:_style,
                             NSForegroundColorAttributeName:_color
                             };
   
    NSMutableAttributedString *_attributedString = [[NSMutableAttributedString alloc] init];
    
    NSString *_string=@"";
   
    if ([attributes.allKeys containsObject:kASText])
    {
        _string= [attributes objectForKey:kASText];
    }
    
    
    [_attributedString appendAttributedString:[[NSAttributedString alloc] initWithString:_string    attributes:_dict1]];
   

  
    if ([attributes.allKeys containsObject:kASCharacterSpace])
    {
        [_attributedString addAttribute:NSKernAttributeName value:@([[attributes objectForKey:kASCharacterSpace] floatValue]) range:NSMakeRange(0, [_string length])];
    }
    
    if ([attributes.allKeys containsObject:kASIsUnderLine])
    {
         [_attributedString addAttribute:NSUnderlineStyleAttributeName value:@(NSUnderlineStyleSingle) range:NSMakeRange(0, [_string length])];
    }

    return _attributedString;
}
@end
