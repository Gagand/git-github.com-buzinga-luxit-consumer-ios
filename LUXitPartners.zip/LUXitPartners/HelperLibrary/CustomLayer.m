//
//  CustomLayer.m
//  Luxit-Partners
//
//  Created by GP on 31/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "CustomLayer.h"

@implementation CustomLayer

- (id)initWithFrame:(CGRect)frame withColors:(NSArray *)colors gradientMode:(GradientMode)mode
{
    self = [super initWithFrame:frame];
   
    if (self)
    {
        CAGradientLayer *_gradient = [CAGradientLayer layer];
        
        if (mode==GMHorizontal)
        {
            _gradient.startPoint = CGPointMake(0.0, 0.5);
            _gradient.endPoint = CGPointMake(1.0, 0.5);
        }
    
        _gradient.anchorPoint = CGPointZero;
        _gradient.frame = self.bounds;
        
        NSMutableArray *_colorsArray=[NSMutableArray arrayWithCapacity:colors.count];
        
        for (UIColor *color in colors)
        {
            [_colorsArray addObject:(id)[color CGColor]];
        }
        
        _gradient.colors =_colorsArray;
        [self.layer addSublayer:_gradient];
    }
   
    return self;
}



@end
