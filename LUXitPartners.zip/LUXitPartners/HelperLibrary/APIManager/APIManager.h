//
//  APIManager.h
//  Luxit-Partners
//
//  Created by GP on 31/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface APIManager : NSObject

- (void)loginWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)sendPasswordWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)fetchLastCreatedJobStatusWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)changeAvailablityWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)fetchValidJobsWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*,NSMutableArray *))completion;

- (void)acceptJobsWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)markJobsAsArrivedWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*,BOOL))completion;
- (void)checkForJobCount:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*, BOOL, NSDictionary*))completion;

- (void)markJobsAsCompleteWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*,BOOL))completion;

- (void)sendPositiveFeedbackForJobsWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)cancelJobsWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*,BOOL))completion;

- (void)sendFeedbackForJobWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)updateUserLocationCoordinateWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)fetchJobHistoryForJobWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*,NSMutableArray *))completion;
- (void)getprofileDetailWithCompletion:(void(^)(BOOL,BOOL))completion;

- (void)updatePasswordWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)updateDeviceTokenWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

@end

APIManager *API(void);
