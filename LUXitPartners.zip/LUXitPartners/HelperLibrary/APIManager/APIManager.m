//
//  APIManager.m
//  Luxit-Partners
//
//  Created by GP on 31/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "APIManager.h"

@implementation APIManager

- (void)loginWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_email=[attributes objectForKey:@"email"];
    NSString *_password=[attributes objectForKey:@"password"];
    NSString *_deviceToken=[attributes objectForKey:@"deviceToken"];
    NSString *_deviceType=[attributes objectForKey:@"deviceType"];
    NSString *_userType=[attributes objectForKey:@"userType"];

    NSCharacterSet *set = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ0123456789"];
    
    NSString *encodedPassword = [_password stringByAddingPercentEncodingWithAllowedCharacters:set];
    NSString *encodedEmail = [_email stringByAddingPercentEncodingWithAllowedCharacters:set];
    
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL,LOGIN_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"email=%@&password=%@&device_token=%@&device_type=%@&usertype=%@",encodedEmail,encodedPassword,_deviceToken,_deviceType,_userType];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
    
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 NSMutableDictionary *_userInfoDictionary=[NSMutableDictionary dictionaryWithDictionary:[[_dictionary objectForKey:@"message"]objectForKey:@"User"]];
                 if ([[_userInfoDictionary objectForKey:@"role_id"]intValue]==3)
                 {
                     if ([[[_dictionary objectForKey:@"message"]objectForKey:@"PaymentInfo"]isKindOfClass:[NSDictionary class]])
                     {
                         NSDictionary *_paymentMethodInfo=[[_dictionary objectForKey:@"message"]objectForKey:@"PaymentInfo"];
                         if (_paymentMethodInfo.allKeys.count>0)
                         {
                             [_userInfoDictionary setObject:_paymentMethodInfo forKey:@"paymentInfo"];
                         }
                         else
                         {
                             [_userInfoDictionary setObject:[NSMutableDictionary dictionaryWithCapacity:0] forKey:@"paymentInfo"];
                         }
                     }
                     else
                     {
                         [_userInfoDictionary setObject:[NSMutableDictionary dictionaryWithCapacity:0] forKey:@"paymentInfo"];
                     }
                     
                     [[NSUserDefaults standardUserDefaults]setObject:_userInfoDictionary forKey:@"UserInfo"];
                     [[NSUserDefaults standardUserDefaults]synchronize];
                     
                     [appDelegate().userInfo updateWithAttributes:_userInfoDictionary];
                     
                     if (completion)
                         completion(YES,nil);
                 }
                 else
                 {
                     NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"Invalid user for app",@"description", nil]];
                     
                     if (completion)
                         completion(NO,_error);
                 }
             }
             else
             {
                 NSString *_errorTitle=@"Error";
                 if ([[_dictionary objectForKey:@"message"]rangeOfString:@"lease fill in all fields and verify that"].length!=NSNotFound){
                     _errorTitle=@"Login details not valid";
                 }
                 
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:_errorTitle,@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}


- (void)sendPasswordWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_email=[attributes objectForKey:@"email"];
    NSCharacterSet *set = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ0123456789"];
    
    NSString *encodedEmail = [_email stringByAddingPercentEncodingWithAllowedCharacters:set];
    
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL,FORGOTPASSWORD_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"email=%@",encodedEmail];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
          
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"])
                 {
                     [progressHud() hide];
                     [ccManager() showAlertWithTitle:@"Info" message:@"Your account has been suspended." buttons:nil completion:nil];
                     return;
                 }
                 
                 
                 NSString *_errorTitle=@"Error";
                 if ([[_dictionary objectForKey:@"message"]rangeOfString:@"email format"].length!=NSNotFound){
                     _errorTitle=@"Email";
                 }
                 
                 NSError*_error = [NSError errorWithDomain:_errorTitle code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:_errorTitle,@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}


- (void)fetchLastCreatedJobStatusWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{

    NSTimeZone *_currentTimeZone = [NSTimeZone localTimeZone];
    
    NSString *_userId=[attributes objectForKey:@"userId"];
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_1,JOBSTATUS_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"technician_id=%@&time_zone=%@",_userId,_currentTimeZone.name];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
             
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 NSMutableDictionary *_records=nil;
                 
                 if ([[_dictionary objectForKey:@"record"] isKindOfClass:[NSDictionary class]])
                 {
                     _records=[_dictionary objectForKey:@"record"];
                 }
                 else
                 {
                     _records=[[_dictionary objectForKey:@"record"] objectAtIndex:0];
                 }
                 
                 if ([_records isKindOfClass:[NSDictionary class]])
                 {
                     NSDictionary *_jobDescriptionDictionary=[_records objectForKey:@"jobDescription"];
                     
                     NSMutableDictionary *_jobDetail=[NSMutableDictionary dictionaryWithCapacity:10];
                     [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"id"] forKey:@"id"];
                     [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"itemName"] forKey:@"itemName"];
                     [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"itemPrice"] forKey:@"itemPrice"];
                     [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"date"]  forKey:@"date"];
                     [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"location"]  forKey:@"location"];
                     [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"search_duration"]  forKey:@"timeInterval"];
                     [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"cancel_amount"] forKey:@"cancellationFees"];
                      [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"technician_cancellation_fee"] forKey:@"technicianCancellationFees"];
                     
                     if ([_jobDescriptionDictionary.allKeys containsObject:@"technician_fee"] && (NSNull *)[_jobDescriptionDictionary objectForKey:@"technician_fee"]!=[NSNull null])
                     {
                         [_jobDetail setObject:[NSString stringWithFormat:@"%f",[[_jobDescriptionDictionary objectForKey:@"technician_fee"]floatValue]] forKey:@"technicianFee"];
                     }
 
                     int _status=0;
                     
                     if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Searching"])
                     {
                         _status=0;
                         [_jobDetail setObject:[NSMutableDictionary dictionaryWithCapacity:0]  forKey:@"consumer"];
                     }
                     else if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Accept"])
                     {
                         _status=1;
                        
                         NSMutableDictionary *_customerInfo=[NSMutableDictionary dictionaryWithDictionary:[_records objectForKey:@"consumerInfo"]];
                         if ([((NSDictionary *)[_records objectForKey:@"consumerInfo"]).allKeys containsObject:@"rating"] && (NSNull *)[((NSDictionary *)[_records objectForKey:@"consumerInfo"]) objectForKey:@"rating"]!=[NSNull null]) {}
                         else
                         {
                             [_customerInfo setObject:@"0" forKey:@"rating"];
                         }
                         [_jobDetail setObject:_customerInfo forKey:@"consumer"];
                         
                     }
                     else if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Cancel by consumer"])
                     {
                         _status=2;
                         
                         NSMutableDictionary *_customerInfo=[NSMutableDictionary dictionaryWithDictionary:[_records objectForKey:@"consumerInfo"]];
                         if ([((NSDictionary *)[_records objectForKey:@"consumerInfo"]).allKeys containsObject:@"rating"] && (NSNull *)[((NSDictionary *)[_records objectForKey:@"consumerInfo"]) objectForKey:@"rating"]!=[NSNull null]) {}
                         else
                         {
                             [_customerInfo setObject:@"0" forKey:@"rating"];
                         }
                         [_jobDetail setObject:_customerInfo forKey:@"consumer"];;
                     }
                     else if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Cancel by technician"])
                     {
                         [_jobDetail setObject:@"0"  forKey:@"timeInterval"];
                         _status=3;
                        
                         NSMutableDictionary *_customerInfo=[NSMutableDictionary dictionaryWithDictionary:[_records objectForKey:@"consumerInfo"]];
                         if ([((NSDictionary *)[_records objectForKey:@"consumerInfo"]).allKeys containsObject:@"rating"] && (NSNull *)[((NSDictionary *)[_records objectForKey:@"consumerInfo"]) objectForKey:@"rating"]!=[NSNull null]) {}
                         else
                         {
                             [_customerInfo setObject:@"0" forKey:@"rating"];
                         }
                         [_jobDetail setObject:_customerInfo forKey:@"consumer"];
                     }
                     else if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Working"])
                     {
                         _status=4;
                         
                         NSMutableDictionary *_customerInfo=[NSMutableDictionary dictionaryWithDictionary:[_records objectForKey:@"consumerInfo"]];
                         if ([((NSDictionary *)[_records objectForKey:@"consumerInfo"]).allKeys containsObject:@"rating"] && (NSNull *)[((NSDictionary *)[_records objectForKey:@"consumerInfo"]) objectForKey:@"rating"]!=[NSNull null]) {}
                         else
                         {
                             [_customerInfo setObject:@"0" forKey:@"rating"];
                         }
                         [_jobDetail setObject:_customerInfo forKey:@"consumer"];
                     }
                     else if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Completed"])
                     {
                         _status=5;
                         
                         NSMutableDictionary *_customerInfo=[NSMutableDictionary dictionaryWithDictionary:[_records objectForKey:@"consumerInfo"]];
                         if ([((NSDictionary *)[_records objectForKey:@"consumerInfo"]).allKeys containsObject:@"rating"] && (NSNull *)[((NSDictionary *)[_records objectForKey:@"consumerInfo"]) objectForKey:@"rating"]!=[NSNull null]) {}
                         else
                         {
                             [_customerInfo setObject:@"0" forKey:@"rating"];
                         }
                         [_jobDetail setObject:_customerInfo forKey:@"consumer"];
                     }
                     else if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Feedback"])
                     {
                         _status=8;
                       
                         NSMutableDictionary *_customerInfo=[NSMutableDictionary dictionaryWithDictionary:[_records objectForKey:@"consumerInfo"]];
                         if ([((NSDictionary *)[_records objectForKey:@"consumerInfo"]).allKeys containsObject:@"rating"] && (NSNull *)[((NSDictionary *)[_records objectForKey:@"consumerInfo"]) objectForKey:@"rating"]!=[NSNull null]) {}
                         else
                         {
                             [_customerInfo setObject:@"0" forKey:@"rating"];
                         }
                         [_jobDetail setObject:_customerInfo forKey:@"consumer"];
                     }
                     else if([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Feedback Received"])
                     {
                          _status=9;
                        
                         NSMutableDictionary *_customerInfo=[NSMutableDictionary dictionaryWithDictionary:[_records objectForKey:@"consumerInfo"]];
                         if ([((NSDictionary *)[_records objectForKey:@"consumerInfo"]).allKeys containsObject:@"rating"] && (NSNull *)[((NSDictionary *)[_records objectForKey:@"consumerInfo"]) objectForKey:@"rating"]!=[NSNull null]) {}
                         else
                         {
                             [_customerInfo setObject:@"0" forKey:@"rating"];
                         }
                         [_jobDetail setObject:_customerInfo forKey:@"consumer"];
                     }
                     
                     else
                     {
                         _status=0;
                         
                         [_jobDetail setObject:[NSMutableDictionary dictionaryWithCapacity:0]  forKey:@"consumer"];
                         
                     }
                     
                     [_jobDetail setObject:[NSString stringWithFormat:@"%i",_status]  forKey:@"status"];
                     
                     if ([self getStatusValue]==_status)
                     {
                         appDelegate().jobDetail.changed=NO;
                     }
                     else
                     {
                         appDelegate().jobDetail.changed=YES;
                     }
                     
                     
                     [[NSUserDefaults standardUserDefaults]setObject:_jobDetail forKey:@"LastJobDetail"];
                     [[NSUserDefaults standardUserDefaults]synchronize];
                     
                     [appDelegate().jobDetail updateWithAttributes:_jobDetail];
                     
                     if (completion)
                         completion(YES,nil);
                     
                 }
                 else
                 {
                     NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error. Please try again.",@"description", nil]];
                     
                     if (completion)
                         completion(NO,_error);
                 }
                 
             }
             else
             {
                 if ([[_dictionary objectForKey:@"message"]rangeOfString:@"No record found"].length!=NSNotFound)
                 {
                     [[NSUserDefaults standardUserDefaults]setObject:[NSMutableDictionary dictionaryWithCapacity:0] forKey:@"LastJobDetail"];
                     [[NSUserDefaults standardUserDefaults]synchronize];
                    
                     if (appDelegate().jobDetail.status!=JSNoJob)
                     {
                         appDelegate().jobDetail.changed=YES;
                         [appDelegate().jobDetail updateWithAttributes:nil];
                     }

                     if (completion)
                         completion(YES,nil);
                     
                     return ;
                     
                 }
                 
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}


- (void)changeAvailablityWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_userId=[attributes objectForKey:@"userId"];
    NSString *_availability =[attributes objectForKey:@"availability"];
   
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_1,AVAILABILITY_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"availablity=%@&userId=%@",_availability,_userId];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
      
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"])
                 {
                     [progressHud() hide];
                     [ccManager() showAlertWithTitle:@"Info" message:@"Your account has been suspended." buttons:nil completion:nil];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"UserInfo"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"isLuxingEnabale"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"LastJobDetail"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"HistoryInfo"];
                     [[NSUserDefaults standardUserDefaults]synchronize];
                     
                     [appDelegate().jobDetail updateWithAttributes:nil];
                     [appDelegate().userInfo updateWithAttributes:nil];
                     [appDelegate() showLoginViewController];
                     return;
                     
                 }
                 
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}

- (int)getStatusValue
{
    if (appDelegate().jobDetail.status==JSSearching)
        return 0;
    else if (appDelegate().jobDetail.status==JSPending)
        return 1;
    else if (appDelegate().jobDetail.status==JSNoJob)
        return 2;
    else if (appDelegate().jobDetail.status==JSCancelByTechnician)
        return 3;
    else if (appDelegate().jobDetail.status==JSStarted)
        return 4;
    else if (appDelegate().jobDetail.status==JSCompleted)
        return 5;
    else if (appDelegate().jobDetail.status==JSCancelledUnpaid)
        return 6;
    else if (appDelegate().jobDetail.status==JSCompleteUnpaid)
        return 7;
    else if (appDelegate().jobDetail.status==JSNeedFeedback)
        return 8;
    else
        return 9;
}


- (void)fetchValidJobsWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*,NSMutableArray *))completion
{
    NSString *_userId=[attributes objectForKey:@"userId"];
  
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_1,GETJOBS_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"technician_id=%@",_userId];

    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error,nil);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];

             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil,[_dictionary objectForKey:@"record"]);
             }
             else
             {
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"])
                 {
                     [progressHud() hide];
                     [ccManager() showAlertWithTitle:@"Info" message:@"Your account has been suspended." buttons:nil completion:nil];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"UserInfo"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"isLuxingEnabale"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"LastJobDetail"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"HistoryInfo"];
                     [[NSUserDefaults standardUserDefaults]synchronize];
                     
                     [appDelegate().jobDetail updateWithAttributes:nil];
                     [appDelegate().userInfo updateWithAttributes:nil];
                     [appDelegate() showLoginViewController];
                     
                     return;
                     
                 }
      
                 
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error,nil);
             }
         }
     }];

}


- (void)acceptJobsWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_userId=[attributes objectForKey:@"userId"];
    NSString *_jobId=[attributes objectForKey:@"jobId"];
    NSString *_status=[attributes objectForKey:@"status"];
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_2,CHANGEJOBSTATUS_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"technician_id=%@&job_id=%@&status=%@",_userId,_jobId,_status];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
  
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"]){
                     [progressHud() hide];
                     [ccManager() showAlertWithTitle:@"Info" message:@"Your account has been suspended." buttons:nil completion:nil];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"UserInfo"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"isLuxingEnabale"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"LastJobDetail"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"HistoryInfo"];
                     [[NSUserDefaults standardUserDefaults]synchronize];
                     
                     [appDelegate().jobDetail updateWithAttributes:nil];
                     [appDelegate().userInfo updateWithAttributes:nil];
                     [appDelegate() showLoginViewController];
                     return;
                     
                 }
                 
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
    
}


- (void)markJobsAsArrivedWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*,BOOL))completion
{
    NSString *_userId=[attributes objectForKey:@"userId"];
    NSString *_jobId=[attributes objectForKey:@"jobId"];
    NSString *_status=[attributes objectForKey:@"status"];
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_2,CHANGEJOBSTATUS_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"technician_id=%@&job_id=%@&status=%@",_userId,_jobId,_status];
    NSLog(@"%@",_urlString);
    NSLog(@"%@",_postParameters);
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error,NO);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
           
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
  
                 if (completion)
                     completion(YES,nil,NO);
             }
             else
             {
                  if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"])
                  {
                     [progressHud() hide];
                     [ccManager() showAlertWithTitle:@"Info" message:@"Your account has been suspended." buttons:nil completion:nil];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"UserInfo"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"isLuxingEnabale"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"LastJobDetail"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"HistoryInfo"];
                     [[NSUserDefaults standardUserDefaults]synchronize];
                     
                     [appDelegate().jobDetail updateWithAttributes:nil];
                     [appDelegate().userInfo updateWithAttributes:nil];
                     [appDelegate() showLoginViewController];
                     return;
                     
                 }
                   NSLog(@"%@",[[NSString alloc]initWithData:responseData encoding:NSUTF8StringEncoding]);
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid command"])
                 {
                     if (completion)
                         completion(NO,nil,YES);
                     
                     return ;
                 }
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"PreAuth Token is not Valid"])
                 {
                       NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"Please connect with LUXit team. There is some error.",@"description", nil]];
                     if (completion)
                         completion(NO,_error,NO);
                     
                     return ;
                 }
                 
                 
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error,NO);
             }
         }
     }];
}


- (void)markJobsAsCompleteWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*,BOOL))completion
{
    NSString *_userId=[attributes objectForKey:@"userId"];
    NSString *_jobId=[attributes objectForKey:@"jobId"];
    NSString *_status=[attributes objectForKey:@"status"];
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_2,CHANGEJOBSTATUS_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"technician_id=%@&job_id=%@&status=%@",_userId,_jobId,_status];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error,NO);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
             
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil,NO);
             }
             else
             {
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"])
                 {
                     [progressHud() hide];
                     [ccManager() showAlertWithTitle:@"Info" message:@"Your account has been suspended." buttons:nil completion:nil];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"UserInfo"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"isLuxingEnabale"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"LastJobDetail"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"HistoryInfo"];
                     [[NSUserDefaults standardUserDefaults]synchronize];
                     
                     [appDelegate().jobDetail updateWithAttributes:nil];
                     [appDelegate().userInfo updateWithAttributes:nil];
                     [appDelegate() showLoginViewController];
                     return;
                     
                 }
                 
                 if ([[_dictionary objectForKey:@"message"]rangeOfString:@"Invalid command"].length!=NSNotFound)
                 {
                     if (completion)
                         completion(NO,nil,YES);
                     
                     return ;
                 }
                 
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error,NO);
             }
         }
     }];
}

- (void)sendPositiveFeedbackForJobsWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_userId=[attributes objectForKey:@"userId"];
    NSString *_jobId=[attributes objectForKey:@"jobId"];
    NSString *_status=[attributes objectForKey:@"status"];
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_2,CHANGEJOBSTATUS_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"technician_id=%@&job_id=%@&status=%@",_userId,_jobId,_status];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
             
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"])
                 {
                     [progressHud() hide];
                     [ccManager() showAlertWithTitle:@"Info" message:@"Your account has been suspended." buttons:nil completion:nil];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"UserInfo"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"isLuxingEnabale"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"LastJobDetail"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"HistoryInfo"];
                     [[NSUserDefaults standardUserDefaults]synchronize];
                     
                     [appDelegate().jobDetail updateWithAttributes:nil];
                     [appDelegate().userInfo updateWithAttributes:nil];
                     [appDelegate() showLoginViewController];
                     return;
                     
                 }
                 
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];

}

- (void)cancelJobsWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*, BOOL))completion
{
    NSString *_userId=[attributes objectForKey:@"userId"];
    NSString *_jobId=[attributes objectForKey:@"jobId"];
    NSString *_status=[attributes objectForKey:@"status"];
    NSString *_comment=[attributes objectForKey:@"comment"];
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_2,CHANGEJOBSTATUS_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"technician_id=%@&job_id=%@&status=%@&comment=%@",_userId,_jobId,_status,_comment];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error,NO);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
             
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil,NO);
             }
             else
             {
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"])
                 {
                     [progressHud() hide];
                     [ccManager() showAlertWithTitle:@"Info" message:@"Your account has been suspended." buttons:nil completion:nil];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"UserInfo"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"isLuxingEnabale"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"LastJobDetail"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"HistoryInfo"];
                     [[NSUserDefaults standardUserDefaults]synchronize];
                     
                     [appDelegate().jobDetail updateWithAttributes:nil];
                     [appDelegate().userInfo updateWithAttributes:nil];
                     [appDelegate() showLoginViewController];
                     return;
                     
                 }
                 
                 if ([[_dictionary objectForKey:@"message"]rangeOfString:@"Invalid command"].length!=NSNotFound)
                 {
                     if (completion)
                         completion(NO,nil,YES);
                     
                     return ;
                 }
                 
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error,NO);
             }
         }
     }];
}


- (void)sendFeedbackForJobWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_userId=[attributes objectForKey:@"userId"];
    NSString *_jobId=[attributes objectForKey:@"jobId"];
    NSString *_status=[attributes objectForKey:@"status"];
    NSString *_comment=[attributes objectForKey:@"comment"];
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_1,SENDFEEDBACK_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"technician_id=%@&job_id=%@&isPositive=%@&comments=%@",_userId,_jobId,_status,_comment];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
             
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"])
                 {
                     [progressHud() hide];
                     [ccManager() showAlertWithTitle:@"Info" message:@"Your account has been suspended." buttons:nil completion:nil];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"UserInfo"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"isLuxingEnabale"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"LastJobDetail"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"HistoryInfo"];
                     [[NSUserDefaults standardUserDefaults]synchronize];
                     
                     [appDelegate().jobDetail updateWithAttributes:nil];
                     [appDelegate().userInfo updateWithAttributes:nil];
                     [appDelegate() showLoginViewController];
                     return;
                     
                 }
                 
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}


- (void)updateUserLocationCoordinateWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_userId=[attributes objectForKey:@"userId"];
    NSString *_lat=[attributes objectForKey:@"lat"];
    NSString *_lng=[attributes objectForKey:@"lng"];
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_1,CHANGELOCATION_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"technician_id=%@&lat=%@&long=%@",_userId,_lat,_lng];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error.\nPlease try again.",@"description", nil]];
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
      
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"])
                 {                     [progressHud() hide];
                     [ccManager() showAlertWithTitle:@"Info" message:@"Your account has been suspended." buttons:nil completion:nil];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"UserInfo"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"isLuxingEnabale"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"LastJobDetail"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"HistoryInfo"];
                     [[NSUserDefaults standardUserDefaults]synchronize];
                     
                     [appDelegate().jobDetail updateWithAttributes:nil];
                     [appDelegate().userInfo updateWithAttributes:nil];
                     [appDelegate() showLoginViewController];
                     return;
                     
                 }
                 
                 if ([[_dictionary objectForKey:@"message"]rangeOfString:@"No record found"].length!=NSNotFound)
                 {
                     if (completion)
                         completion(YES,nil);
                     
                     return ;
                     
                 }
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}


- (void)fetchJobHistoryForJobWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*, NSMutableArray*))completion
{
    NSString *_userId=[attributes objectForKey:@"userId"];
    NSString *_month=[attributes objectForKey:@"month"];
    NSString *_year=[attributes objectForKey:@"year"];
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_1,GETJOBHISTORY_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"technician_id=%@&mm=%@&yyyy=%@",_userId,_month,_year];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error,nil);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
     
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                
                 if (completion)
                     completion(YES,nil,[_dictionary objectForKey:@"record"]);
             }
             else
             {
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"])
                 {
                     [progressHud() hide];
                     [ccManager() showAlertWithTitle:@"Info" message:@"Your account has been suspended." buttons:nil completion:nil];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"UserInfo"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"isLuxingEnabale"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"LastJobDetail"];
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"HistoryInfo"];
                     [[NSUserDefaults standardUserDefaults]synchronize];
                     
                     [appDelegate().jobDetail updateWithAttributes:nil];
                     [appDelegate().userInfo updateWithAttributes:nil];
                     [appDelegate() showLoginViewController];
                     return;
                     
                 }
                 
                 if ([[_dictionary objectForKey:@"message"]rangeOfString:@"No record found"].length!=NSNotFound)
                 {
                     if (completion)
                         completion(YES,nil,[NSMutableArray arrayWithCapacity:0]);
                     
                     return ;
                     
                 }
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error,nil);
             }
         }
     }];
}

- (void)getprofileDetailWithCompletion:(void(^)(BOOL,BOOL))completion
{
    NSString *_userId=appDelegate().userInfo.userId;

    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_1,GETUSERDETAIL_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"technician_id=%@",_userId];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (!error)
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 NSDictionary *_technicianInfo=[[_dictionary objectForKey:@"record"]objectForKey:@"technicianInfo"];
                 
                 NSMutableDictionary *_userInfo=[NSMutableDictionary dictionaryWithDictionary:[[NSUserDefaults standardUserDefaults]objectForKey:@"UserInfo"]];
                 [_userInfo setObject:[_technicianInfo objectForKey:@"first_name"] forKey:@"first_name"];
                 [_userInfo setObject:[_technicianInfo objectForKey:@"last_name"] forKey:@"last_name"];
                 [_userInfo setObject:[_technicianInfo objectForKey:@"mobileNo"] forKey:@"mobile"];
                 [_userInfo setObject:[_technicianInfo objectForKey:@"image"] forKey:@"image"];
                 
                 if ([_technicianInfo.allKeys containsObject:@"rating"] && (NSNull *)[_technicianInfo objectForKey:@"rating"]!=[NSNull null])
                 {
                     [_userInfo setObject:[_technicianInfo objectForKey:@"rating"] forKey:@"rating"];
                 }
                 else
                 {
                     [_userInfo setObject:@"0" forKey:@"rating"];
                 }
                 [[NSUserDefaults standardUserDefaults]setObject:_userInfo forKey:@"UserInfo"];
                 [[NSUserDefaults standardUserDefaults]synchronize];
                 [appDelegate().userInfo updateWithAttributes:_userInfo];
                 
                 
                 if ([[[_technicianInfo objectForKey:@"availablity"]uppercaseString]boolValue])
                 {
                     if (completion)
                         completion(YES,YES);
                 }
                 else
                 {
                     if (completion)
                         completion(YES,NO);
                 }
             }
         }
     }];
}

- (void)updatePasswordWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_userId=[attributes objectForKey:@"userId"];
    NSString *_oldPassword=[attributes objectForKey:@"oldPassword"];
    NSString *_newPassword=[attributes objectForKey:@"newPassword"];
    
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL,UPDATEPASSWORD_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"user_id=%@&oldpassword=%@&newpassword=%@",_userId,_oldPassword,_newPassword];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
    
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                 NSString *_errorTitle=@"Error";
                 if ([[_dictionary objectForKey:@"message"]rangeOfString:@"ur Current Password is not corre"].length!=NSNotFound){
                     _errorTitle=@"Current Password";
                 }
                 
                 
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:_errorTitle,@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}

- (void)updateDeviceTokenWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_userId=appDelegate().userInfo.userId;
   
    NSString *_deviceToken=[[NSUserDefaults standardUserDefaults]objectForKey:@"deviceToken"];
    
    if(_deviceToken==NULL)
        return;
    
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_2,UPDATETOKEN_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"user_id=%@&device_token=%@",_userId,_deviceToken];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
             
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                 
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}
@end

APIManager *API(void)
{
    return [[APIManager alloc]init];
}