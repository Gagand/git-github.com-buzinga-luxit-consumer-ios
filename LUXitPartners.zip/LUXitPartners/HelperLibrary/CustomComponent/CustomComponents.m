//
//  CustomComponents.m
//  Luxit-Partners
//
//  Created by GP on 31/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//


#import "CustomComponents.h"
#import <objc/runtime.h>

//-------------------------------------------------------------------------------//
//
// BUTTON WRAPPER
//-------------------------------------------------------------------------------//

@interface CustomButtonWrapper : UIButton
@property (nonatomic, copy)void(^completionBlock)(UIButton *);
@end
@implementation CustomButtonWrapper
- (id)init{
    self=[super init];
    if (self)
        [self addTarget:self action:@selector(buttonAction) forControlEvents:UIControlEventTouchUpInside];
    return self;
}
- (void)buttonAction{
    if(_completionBlock)
        _completionBlock(self);
}
@end

//-------------------------------------------------------------------------------//
//
// UIALERTVIEW CATEOGRY
//-------------------------------------------------------------------------------//
@interface AlertWrapper : NSObject <UIAlertViewDelegate>
@property (nonatomic, copy)AlertViewCompletionBlock alertViewCompletionBlock;
@end

@implementation AlertWrapper
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (_alertViewCompletionBlock)
        _alertViewCompletionBlock(alertView, buttonIndex);
}
- (void)alertViewCancel:(UIAlertView *)alertView{
    if (_alertViewCompletionBlock)
        _alertViewCompletionBlock(alertView, alertView.cancelButtonIndex);
}
@end
static const char kAlertWrapper;
@implementation UIAlertView (Custom)
- (void)showWithCompletion:(void(^)(UIAlertView *alertView, NSInteger buttonIndex))completion{
    AlertWrapper *_alertWrapper = [[AlertWrapper alloc] init];
    _alertWrapper.alertViewCompletionBlock = completion;
    self.delegate = _alertWrapper;
    objc_setAssociatedObject(self, &kAlertWrapper, _alertWrapper, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self show];
}
@end

//-------------------------------------------------------------------------------//
//
// UITEXTFIELD CATEOGRY
//-------------------------------------------------------------------------------//
@interface TextFieldWrapper : NSObject <UITextFieldDelegate>
@property (nonatomic, copy)TextEditingCompletionBlock textFieldCompletionBlock;
@end

@implementation TextFieldWrapper
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (_textFieldCompletionBlock)
        _textFieldCompletionBlock(textField,TFTextEditingBegin);
}
-(void)textFieldDidEndEditing:(UITextField *)textField{
    if (_textFieldCompletionBlock)
        _textFieldCompletionBlock(textField,TFTextEditingEnd);
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    if (_textFieldCompletionBlock)
        _textFieldCompletionBlock(textField,TFTextEditingReturn);
    return YES;
}

@end
static const char kTextFieldWrapper;
@implementation UITextField (Custom)
- (void)setTextFieldCompletion:(void(^)(UITextField *alertView, TFStatus))completion{
    TextFieldWrapper *_tfWrapper = [[TextFieldWrapper alloc] init];
    _tfWrapper.textFieldCompletionBlock = completion;
    self.delegate = _tfWrapper;
    objc_setAssociatedObject(self, &kTextFieldWrapper, _tfWrapper, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

}
- (BOOL)canPerformAction:(SEL)action withSender:(id)sender{
    return NO;
}
@end

//-------------------------------------------------------------------------------//
//
// UITEXTVIEW CATEOGRY
//-------------------------------------------------------------------------------//

@interface TextViewWrapper : NSObject <UITextViewDelegate>
@property (nonatomic, copy)TextEditingCompletionBlock textViewCompletionBlock;
@end

@implementation TextViewWrapper
- (void)textViewDidBeginEditing:(UITextView *)textView{
    if (_textViewCompletionBlock)
        _textViewCompletionBlock(textView,TFTextEditingBegin);
}
-(void)textViewDidEndEditing:(UITextView *)textView{
    if (_textViewCompletionBlock)
        _textViewCompletionBlock(textView,TFTextEditingEnd);
}
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if ([text isEqualToString:@"\n"]) {
        if (_textViewCompletionBlock)
            _textViewCompletionBlock(textView,TFTextEditingReturn);
        return NO;
    }
    return YES;
}
@end
static const char kTextViewWrapper;
@implementation UITextView (Custom)
- (void)setTextViewCompletion:(void(^)(UITextField *alertView, TFStatus))completion{
    TextViewWrapper *_tvWrapper = [[TextViewWrapper alloc] init];
    _tvWrapper.textViewCompletionBlock = completion;
    self.delegate = _tvWrapper;
    objc_setAssociatedObject(self, &kTextViewWrapper, _tvWrapper, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    
}
@end

//-------------------------------------------------------------------------------//
//
// CUSTOM NAVIGATIONCONTROLLER
//-------------------------------------------------------------------------------//
@implementation UINavigationController (Custom)
- (void)customizeNavigationBarWithAttributes:(NSDictionary *)attributes{
    [self.navigationBar setBackgroundImage:[UIImage new]  forBarMetrics:UIBarMetricsDefault];
    self.navigationBar.shadowImage  = [UIImage new];
    if ([self.navigationBar respondsToSelector:@selector(setBarTintColor:)]) {
        if ([[attributes allKeys]containsObject:kCCBarTintColor])
            self.navigationBar.barTintColor =[attributes objectForKey:kCCBarTintColor];
    }
    else{
        if ([[attributes allKeys]containsObject:kCCBarTintColor]){
            [[UINavigationBar appearance] setBackgroundImage:[[UIImage alloc] init] forBarMetrics:UIBarMetricsDefault];
            [[UINavigationBar appearance] setBackgroundColor:[attributes objectForKey:kCCBarTintColor]];
        }
    }
    if ([self.navigationBar respondsToSelector:@selector(setTintColor:)]){
        if ([[attributes allKeys]containsObject:kCCTintColor])
            self.navigationBar.tintColor =[attributes objectForKey:kCCTintColor];
    }
    self.navigationBar.translucent  = NO;
    #pragma clang diagnostic push
    #pragma clang diagnostic ignored "-Wdeprecated-declarations"
    if ([[attributes allKeys]containsObject:kCCTextFont] && [[attributes allKeys]containsObject:kCCTextColor])
         self.navigationBar.titleTextAttributes = [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:[attributes objectForKey:kCCTextColor],[attributes objectForKey:kCCTextFont], nil] forKeys:[NSArray arrayWithObjects:UITextAttributeTextColor,UITextAttributeFont, nil]];
     else if ([[attributes allKeys]containsObject:kCCTextFont])
         self.navigationBar.titleTextAttributes = [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:[attributes objectForKey:kCCTextFont], nil] forKeys:[NSArray arrayWithObjects:UITextAttributeFont, nil]];
     else if ([[attributes allKeys]containsObject:kCCTextColor])
         self.navigationBar.titleTextAttributes = [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:[attributes objectForKey:kCCTextColor], nil] forKeys:[NSArray arrayWithObjects:UITextAttributeTextColor, nil]];
}
@end

//-------------------------------------------------------------------------------//
//
// UIACTIONSHEET CATEOGRY
//-------------------------------------------------------------------------------//
@interface ActionSheetWrapper : NSObject <UIActionSheetDelegate>
@property (nonatomic, copy)ActionSheetCompletionBlock actionSheetCompletionBlock;
@end
@implementation ActionSheetWrapper
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (self.actionSheetCompletionBlock)
        self.actionSheetCompletionBlock(actionSheet, buttonIndex);
}
-(void)actionSheetCancel:(UIActionSheet *)actionSheet{
    if (self.actionSheetCompletionBlock)
        self.actionSheetCompletionBlock(actionSheet, actionSheet.cancelButtonIndex);
}
@end
static const char kActionSheetWrapper;
@implementation UIActionSheet (Custom)
- (void)showWithCompletion:(void(^)(UIActionSheet *actionSheet, NSInteger buttonIndex))completion{
    ActionSheetWrapper *_asWrapper = [[ActionSheetWrapper alloc] init];
    _asWrapper.actionSheetCompletionBlock = completion;
    self.delegate = _asWrapper;
    objc_setAssociatedObject(self, &kActionSheetWrapper, _asWrapper, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
@end

//-------------------------------------------------------------------------------//
//
// CUSTOM COMPONENT IMPLEMENTATION
//-------------------------------------------------------------------------------//
@implementation CustomComponents
#pragma mark- Singleton
static CustomComponents * _sharedCCManager = nil;


+(CustomComponents *)singleton{
    @synchronized([CustomComponents class]){
		if (!_sharedCCManager)
            _sharedCCManager=[[self alloc] init];
		return _sharedCCManager;
	}
	return nil;
}


+(id)alloc{
	@synchronized([CustomComponents class]){
		_sharedCCManager = [super alloc];
		return _sharedCCManager;
	}
	return nil;
}


-(id)init{
	self = [super init];
	if (self != nil) {}
	return self;
}


- (UIButton *)buttonWithAttributes:(NSDictionary *)attributes frame:(CGRect)frame completion:(void(^)(UIButton *))completion{
    CustomButtonWrapper *_btn=[[CustomButtonWrapper alloc]init];;
    _btn.imageView.contentMode=UIViewContentModeScaleAspectFit;
    _btn.frame=frame;
    _btn.clipsToBounds=YES;
    _btn.titleLabel.numberOfLines=10;
    _btn.titleLabel.textAlignment=NSTextAlignmentCenter;
    if ([[attributes allKeys]containsObject:kCCBackgroundColor])
        _btn.backgroundColor=[attributes objectForKey:kCCBackgroundColor];
    if ([[attributes allKeys]containsObject:kCCTag])
        _btn.tag=[[attributes objectForKey:kCCTag]intValue];
    if ([[attributes allKeys]containsObject:kCCTextColor])
        [_btn setTitleColor:[attributes objectForKey:kCCTextColor] forState:UIControlStateNormal];
    if ([[attributes allKeys]containsObject:kCCTextAlignment])
        _btn.titleLabel.textAlignment=[[attributes objectForKey:kCCTextAlignment]intValue];
    if ([[attributes allKeys]containsObject:kCCCornerRadius])
        _btn.layer.cornerRadius=[[attributes objectForKey:kCCCornerRadius]floatValue];
    if ([[attributes allKeys]containsObject:kCCBorderColor])
        _btn.layer.borderColor=((UIColor *)[attributes objectForKey:kCCBorderColor]).CGColor;
    if ([[attributes allKeys]containsObject:kCCBorderWidth])
        _btn.layer.borderWidth=[[attributes objectForKey:kCCBorderWidth] floatValue];
    if ([[attributes allKeys]containsObject:kCCImage])
        [_btn setImage:[attributes objectForKey:kCCImage] forState:UIControlStateNormal];
    if ([[attributes allKeys]containsObject:kCCContentMode])
        _btn.imageView.contentMode=[[attributes objectForKey:kCCContentMode]intValue];
    if ([[attributes allKeys]containsObject:kCCAlpha])
        _btn.alpha=[[attributes objectForKey:kCCAlpha]floatValue];
    if ([[attributes allKeys]containsObject:kCCTextFont])
        _btn.titleLabel.font=[attributes objectForKey:kCCTextFont];
    if ([[attributes allKeys]containsObject:kCCText])
         [_btn setTitle:[attributes objectForKey:kCCText] forState:UIControlStateNormal];
   
    if (completion)
        _btn.completionBlock=completion;

    return _btn;
}


- (UIImageView *)imageViewWithAttributes:(NSDictionary *)attributes frame:(CGRect)frame{
    UIImageView *_imgView=[[UIImageView alloc]initWithFrame:frame];
    _imgView.clipsToBounds=YES;
    if ([[attributes allKeys]containsObject:kCCBackgroundColor])
        _imgView.backgroundColor=[attributes objectForKey:kCCBackgroundColor];
    if ([[attributes allKeys]containsObject:kCCAlpha])
        _imgView.alpha=[[attributes objectForKey:kCCAlpha]floatValue];
    if ([[attributes allKeys]containsObject:kCCTag])
        _imgView.tag=[[attributes objectForKey:kCCTag]intValue];
    if ([[attributes allKeys]containsObject:kCCContentMode])
        _imgView.contentMode=[[attributes objectForKey:kCCContentMode]intValue];
    if ([[attributes allKeys]containsObject:kCCImage])
        _imgView.image=[attributes objectForKey:kCCImage];
    if ([[attributes allKeys]containsObject:kCCCornerRadius])
        _imgView.layer.cornerRadius=[[attributes objectForKey:kCCCornerRadius]floatValue];
    if ([[attributes allKeys]containsObject:kCCBorderColor])
        _imgView.layer.borderColor=((UIColor *)[attributes objectForKey:kCCBorderColor]).CGColor;
    if ([[attributes allKeys]containsObject:kCCBorderWidth])
        _imgView.layer.borderWidth=[[attributes objectForKey:kCCBorderWidth] floatValue];
    return _imgView;
}


- (UIView *)viewWithAttributes:(NSDictionary *)attributes frame:(CGRect)frame{
    UIView *_view=[[UIView alloc]initWithFrame:frame];
    _view.clipsToBounds=YES;
    if ([[attributes allKeys]containsObject:kCCBackgroundColor])
        _view.backgroundColor=[attributes objectForKey:kCCBackgroundColor];
    if ([[attributes allKeys]containsObject:kCCAlpha])
        _view.alpha=[[attributes objectForKey:kCCAlpha]floatValue];
    if ([[attributes allKeys]containsObject:kCCTag])
        _view.tag=[[attributes objectForKey:kCCTag]intValue];
    if ([[attributes allKeys]containsObject:kCCCornerRadius])
        _view.layer.cornerRadius=[[attributes objectForKey:kCCCornerRadius]floatValue];
    if ([[attributes allKeys]containsObject:kCCBorderColor])
        _view.layer.borderColor=((UIColor *)[attributes objectForKey:kCCBorderColor]).CGColor;
    if ([[attributes allKeys]containsObject:kCCBorderWidth])
        _view.layer.borderWidth=[[attributes objectForKey:kCCBorderWidth] floatValue];
    return _view;
}


- (UILabel *)labelWithAttributes:(NSDictionary *)attributes frame:(CGRect)frame{
    UILabel *_label=[[UILabel alloc]initWithFrame:frame];
    _label.clipsToBounds=YES;
    _label.numberOfLines=0;
    if ([[attributes allKeys]containsObject:kCCBackgroundColor])
        _label.backgroundColor=[attributes objectForKey:kCCBackgroundColor];
    else
        _label.backgroundColor=[UIColor clearColor];
    if ([[attributes allKeys]containsObject:kCCAlpha])
        _label.alpha=[[attributes objectForKey:kCCAlpha]floatValue];
    if ([[attributes allKeys]containsObject:kCCTag])
        _label.tag=[[attributes objectForKey:kCCTag]intValue];
    if ([[attributes allKeys]containsObject:kCCCornerRadius])
        _label.layer.cornerRadius=[[attributes objectForKey:kCCCornerRadius]floatValue];
    if ([[attributes allKeys]containsObject:kCCBorderColor])
        _label.layer.borderColor=((UIColor *)[attributes objectForKey:kCCBorderColor]).CGColor;
    if ([[attributes allKeys]containsObject:kCCBorderWidth])
        _label.layer.borderWidth=[[attributes objectForKey:kCCBorderWidth] floatValue];
    if ([[attributes allKeys]containsObject:kCCText])
        _label.text=[attributes objectForKey:kCCText];
    if ([[attributes allKeys]containsObject:kCCTextColor])
        _label.textColor=[attributes objectForKey:kCCTextColor];
    if ([[attributes allKeys]containsObject:kCCTextAlignment])
        _label.textAlignment=[[attributes objectForKey:kCCTextAlignment]intValue];
    if ([[attributes allKeys]containsObject:kCCTextFont])
         _label.font=[attributes objectForKey:kCCTextFont];
    
    return _label;
}


- (UITextField *)textFieldWithAttributes:(NSDictionary *)attributes frame:(CGRect)frame target:(id)target completion:(void(^)(UITextField *,TFStatus))completion{
    UITextField *_txtField=[[UITextField alloc]initWithFrame:frame];
     _txtField.backgroundColor=[UIColor clearColor];
    if ([[attributes allKeys]containsObject:kCCTextAlignment])
        _txtField.textAlignment=[[attributes objectForKey:kCCTextAlignment]intValue];
    if ([[attributes allKeys]containsObject:kCCBackgroundColor])
        _txtField.backgroundColor=[attributes objectForKey:kCCBackgroundColor];
    if ([[attributes allKeys]containsObject:kCCAlpha])
        _txtField.alpha=[[attributes objectForKey:kCCAlpha]floatValue];
    if ([[attributes allKeys]containsObject:kCCTag])
        _txtField.tag=[[attributes objectForKey:kCCTag]intValue];
    if ([[attributes allKeys]containsObject:kCCCornerRadius])
        _txtField.layer.cornerRadius=[[attributes objectForKey:kCCCornerRadius]floatValue];
    if ([[attributes allKeys]containsObject:kCCBorderColor])
        _txtField.layer.borderColor=((UIColor *)[attributes objectForKey:kCCBorderColor]).CGColor;
    if ([[attributes allKeys]containsObject:kCCBorderWidth])
        _txtField.layer.borderWidth=[[attributes objectForKey:kCCBorderWidth] floatValue];
    if ([[attributes allKeys]containsObject:kCCTextColor])
        _txtField.textColor=[attributes objectForKey:kCCTextColor];
    if ([[attributes allKeys]containsObject:kCCTextFont])
        _txtField.font=[attributes objectForKey:kCCTextFont];
    if ([[attributes allKeys]containsObject:kCCPlaceHolderText])
        _txtField.placeholder=[attributes objectForKey:kCCPlaceHolderText];
    if ([[attributes allKeys]containsObject:kCCSecureEntery])
        _txtField.secureTextEntry=[[attributes objectForKey:kCCSecureEntery]boolValue];
    if ([[attributes allKeys]containsObject:kCCReturnKey])
        _txtField.returnKeyType=[[attributes objectForKey:kCCReturnKey]intValue];
    if ([[attributes allKeys]containsObject:kCCKeyboardType])
        _txtField.keyboardType=[[attributes objectForKey:kCCKeyboardType]intValue];
    if ([[attributes allKeys]containsObject:kCCPlaceHolderColor] && [[attributes allKeys]containsObject:kCCPlaceHolderText])
        _txtField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:[attributes objectForKey:kCCPlaceHolderText] attributes:@{NSForegroundColorAttributeName: [attributes objectForKey:kCCPlaceHolderColor]}];
    
    
    _txtField.contentVerticalAlignment=UIControlContentVerticalAlignmentCenter;
    _txtField.autocapitalizationType=UITextAutocapitalizationTypeNone;
    _txtField.autocorrectionType=UITextAutocorrectionTypeNo;
    _txtField.delegate=target;
    
    [_txtField setLeftViewMode:UITextFieldViewModeAlways];
    CGFloat _width=frame.size.height+5.0;
    if (![[attributes allKeys]containsObject:kCCLeftView])
        _width=10.0;
    UIView *_leftSideIconView=[[UIView alloc]initWithFrame:CGRectMake(0.0, 0.0, _width, frame.size.height)];
    _leftSideIconView.backgroundColor=[UIColor clearColor];
    if ([[attributes allKeys]containsObject:kCCLeftView])
        [_leftSideIconView addSubview:[attributes objectForKey:kCCLeftView]];
    _txtField.leftView=_leftSideIconView;
   
    if ([[attributes allKeys]containsObject:kCCRightView]){
        [_txtField setRightViewMode:UITextFieldViewModeWhileEditing];
        UIView *_rightSideIconView=[[UIView alloc]initWithFrame:CGRectMake(0.0, 0.0, 40, frame.size.height)];
        _rightSideIconView.backgroundColor=[UIColor clearColor];
        UIView *_rightView=(UIView *)[attributes objectForKey:kCCRightView];
        _rightView.center=CGPointMake(_rightSideIconView.frame.size.width/2, _rightSideIconView.frame.size.height/2);
        [_rightSideIconView addSubview:_rightView];
        _txtField.rightView=_rightSideIconView;
    }
    
    if(completion)
        [_txtField setTextFieldCompletion:completion];
  
    return _txtField;
}


- (UITextView *)textViewWithAttributes:(NSDictionary *)attributes frame:(CGRect)frame target:(id)target completion:(void(^)(UITextField *,TFStatus))completion{
    UITextView *_txtView=[[UITextView alloc]initWithFrame:frame];
    _txtView.backgroundColor=[UIColor clearColor];
    if ([[attributes allKeys]containsObject:kCCBackgroundColor])
        _txtView.backgroundColor=[attributes objectForKey:kCCBackgroundColor];
    if ([[attributes allKeys]containsObject:kCCAlpha])
        _txtView.alpha=[[attributes objectForKey:kCCAlpha]floatValue];
    if ([[attributes allKeys]containsObject:kCCTag])
        _txtView.tag=[[attributes objectForKey:kCCTag]intValue];
    if ([[attributes allKeys]containsObject:kCCCornerRadius])
        _txtView.layer.cornerRadius=[[attributes objectForKey:kCCCornerRadius]floatValue];
    if ([[attributes allKeys]containsObject:kCCBorderColor])
        _txtView.layer.borderColor=((UIColor *)[attributes objectForKey:kCCBorderColor]).CGColor;
    if ([[attributes allKeys]containsObject:kCCBorderWidth])
        _txtView.layer.borderWidth=[[attributes objectForKey:kCCBorderWidth] floatValue];
    if ([[attributes allKeys]containsObject:kCCTextColor])
        _txtView.textColor=[attributes objectForKey:kCCTextColor];
    if ([[attributes allKeys]containsObject:kCCTextFont])
        _txtView.font=[attributes objectForKey:kCCTextFont];
    if ([[attributes allKeys]containsObject:kCCSecureEntery])
        _txtView.secureTextEntry=[[attributes objectForKey:kCCSecureEntery]boolValue];
    if ([[attributes allKeys]containsObject:kCCReturnKey])
        _txtView.returnKeyType=[[attributes objectForKey:kCCReturnKey]intValue];
    if ([[attributes allKeys]containsObject:kCCKeyboardType])
        _txtView.keyboardType=[[attributes objectForKey:kCCKeyboardType]intValue];
    _txtView.autocapitalizationType=UITextAutocapitalizationTypeNone;
    _txtView.autocorrectionType=UITextAutocorrectionTypeNo;
    _txtView.delegate=target;
    
     if(completion)
        [_txtView setTextViewCompletion:completion];
    
    return _txtView;
}


- (UITableView *)tableViewWithAttributes:(NSDictionary *)attributes frame:(CGRect)frame target:(id)target{
    UITableView *_tableView=[[UITableView alloc]initWithFrame:frame];
    _tableView.delegate=target;
    _tableView.dataSource=target;
    _tableView.backgroundColor=[UIColor clearColor];
    if ([[attributes allKeys]containsObject:kCCBackgroundColor])
        _tableView.backgroundColor=[attributes objectForKey:kCCBackgroundColor];
    if ([[attributes allKeys]containsObject:kCCAlpha])
        _tableView.alpha=[[attributes objectForKey:kCCAlpha]floatValue];
    if ([[attributes allKeys]containsObject:kCCTag])
        _tableView.tag=[[attributes objectForKey:kCCTag]intValue];
    if ([[attributes allKeys]containsObject:kCCCornerRadius])
        _tableView.layer.cornerRadius=[[attributes objectForKey:kCCCornerRadius]floatValue];
    if ([[attributes allKeys]containsObject:kCCBorderColor])
        _tableView.layer.borderColor=((UIColor *)[attributes objectForKey:kCCBorderColor]).CGColor;
    if ([[attributes allKeys]containsObject:kCCBorderWidth])
        _tableView.layer.borderWidth=[[attributes objectForKey:kCCBorderWidth] floatValue];
    if ([[attributes allKeys]containsObject:kCCSeparatorColor])
        _tableView.separatorColor=[attributes objectForKey:kCCSeparatorColor];
    return _tableView;
}

- (void)showAlertWithTitle:(NSString *)title message:(NSString *)message buttons:(NSArray *)buttons completion:(void(^)(NSInteger))completion{
    UIAlertView *_alertView=[[UIAlertView alloc]initWithTitle:title message:message delegate:nil cancelButtonTitle:nil otherButtonTitles: nil];
    if (buttons.count>0) {
        for (NSString *_buttonTitle in buttons)
            [_alertView addButtonWithTitle:_buttonTitle];
    }
    else{
        [_alertView addButtonWithTitle:@"OK"];
    }
   
    [_alertView showWithCompletion:^(UIAlertView *alertView,NSInteger buttonIndex){
        if(completion)
            completion(buttonIndex);
    }];
}

- (void)customizeNavigationBarWithAttributes:(NSDictionary *)attributes navigationController:(UINavigationController *)navController{
    [navController customizeNavigationBarWithAttributes:attributes];
}

- (void)showActionSheetWithCompletion:(void(^)(UIActionSheet *,NSInteger))completion actionSheet:(UIActionSheet *)actionSheet{
    [actionSheet showWithCompletion:completion];
}
@end
CustomComponents *ccManager(void){
    return [CustomComponents singleton];
}