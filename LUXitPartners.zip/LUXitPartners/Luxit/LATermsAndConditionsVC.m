//
//  LATermsAndConditionsVC.m
//  Luxit-Partners
//
//  Created by GP on 24/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "LATermsAndConditionsVC.h"

@implementation LATermsAndConditionsVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    NSDictionary *_attributes=nil;
    _attributes=@{
                  kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                  kASTextColor:COLOR_THEME_BROWN,
                  kASText:@"TERMS & CONDITIONS",
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                  };
    
    CGRect _frame=CGRectMake(0.0, 15.0, 190, 50.0);
    
    UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
    [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
    
    self.navigationItem.titleView=_headerLabel;
    
    _attributes=@{
                  kCCImage: [UIImage imageNamed:@"Arrow.png"]
                  };
    
    UIButton *_backButton=[ccManager() buttonWithAttributes:_attributes frame:CGRectMake(0.0, 5.0, 80.0, 50.0) completion:^(UIButton *sender){[self.navigationController popViewControllerAnimated:YES];}];
    
    UIBarButtonItem *_backButtonItem=[[UIBarButtonItem alloc]initWithCustomView:_backButton];
    
    UIBarButtonItem *_leftSpaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    _leftSpaceItem.width = -31.0;
    
    self.navigationItem.leftBarButtonItems=[NSArray arrayWithObjects:_leftSpaceItem,_backButtonItem, nil];
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_webView==nil)
    {
        _webView=[[UIWebView alloc]initWithFrame:self.view.bounds];
        _webView.delegate=self;
        _webView.opaque=NO;
        _webView.scalesPageToFit = YES;
        _webView.autoresizesSubviews = YES;
        _webView.backgroundColor=[UIColor clearColor];
        [self.view addSubview:_webView];
        
        NSString *_docFilePath = [[NSBundle mainBundle] pathForResource:@"Service Provider Agreement - Luxit" ofType:@"docx"];
        NSURL *_url = [NSURL fileURLWithPath:_docFilePath];
        NSURLRequest *_request = [NSURLRequest requestWithURL:_url];
        [_webView loadRequest:_request];
        
        
        _activityIndicatorView=[[UIActivityIndicatorView alloc]initWithFrame:self.view.bounds];
        _activityIndicatorView.activityIndicatorViewStyle=UIActivityIndicatorViewStyleGray;
        [self.view addSubview:_activityIndicatorView];
        [_activityIndicatorView startAnimating];
    }
}


- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [_activityIndicatorView stopAnimating];
}


- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [_activityIndicatorView stopAnimating];
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    _webView.frame=self.view.bounds;
}
@end
