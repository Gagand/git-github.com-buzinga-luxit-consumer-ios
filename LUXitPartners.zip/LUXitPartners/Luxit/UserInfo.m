//
//  UserInfo.m
//  Luxit-Partners
//
//  Created by GP on 04/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "UserInfo.h"

@implementation UserInfo

- (void)updateWithAttributes:(NSDictionary *)attributes
{
    if (attributes.allKeys.count>0)
    {
        _rating=0;
        
        _isUserAvailable=YES;
       
        _firstName=[[attributes objectForKey:@"first_name"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        _lastName=[[attributes objectForKey:@"last_name"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        _email=[[attributes objectForKey:@"email"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        
        _name=[[NSString stringWithFormat:@"%@ %@",_firstName,_lastName]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        
        if ([attributes.allKeys containsObject:@"id"])
        {
            _userId=[[attributes objectForKey:@"id"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        }
        else
        {
            _userId=[[attributes objectForKey:@"user_id"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        }
        
        _fbId=[[attributes objectForKey:@"fbid"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
       
        if ([attributes.allKeys containsObject:@"mobile"])
        {
           _mobile=[[attributes objectForKey:@"mobile"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        }
        else
        {
            _mobile=@"";
        }

        _imagePath=[[attributes objectForKey:@"image"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];

        if ([attributes.allKeys containsObject:@"rating"])
        {
            _rating=[[attributes objectForKey:@"rating"]intValue]/2.0;
        }
        
    }
    else
    {
         [[UIApplication sharedApplication] unregisterForRemoteNotifications];
        _isUserAvailable=NO;
    }
}

@end

