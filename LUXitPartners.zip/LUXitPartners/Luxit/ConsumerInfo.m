//
//  ConsumerInfo.m
//  Luxit-Partners
//
//  Created by GP on 11/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "ConsumerInfo.h"

@implementation ConsumerInfo

- (void)updateWithAttributes:(NSDictionary *)attributes
{
    _name=@"";
    _mobile=@"";
    _imagePath=@"";
    _rating=0;
    _firstName=@"";
    _lastName=@"";
    
    if ([attributes.allKeys containsObject:@"mobileNo"] && (NSNull *)[attributes objectForKey:@"mobileNo"]!=[NSNull null] )
    {
        _mobile=[attributes objectForKey:@"mobileNo"];
    }
    

    if ([attributes.allKeys containsObject:@"first_name"] && (NSNull *)[attributes objectForKey:@"first_name"]!=[NSNull null] )
    {
        _firstName=[attributes objectForKey:@"first_name"];
    }
    
    if ([attributes.allKeys containsObject:@"last_name"] && (NSNull *)[attributes objectForKey:@"last_name"]!=[NSNull null] )
    {
        _lastName=[attributes objectForKey:@"last_name"];
    }
    
    if ([attributes.allKeys containsObject:@"name"] && (NSNull *)[attributes objectForKey:@"name"]!=[NSNull null] )
    {
        _name=[attributes objectForKey:@"name"];
    }
    else
    {
        _name=[[NSString stringWithFormat:@"%@ %@",_firstName,_lastName]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    }
    
    if ([attributes.allKeys containsObject:@"image"] && (NSNull *)[attributes objectForKey:@"image"]!=[NSNull null] )
    {
        _imagePath=[[attributes objectForKey:@"image"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    }
    
    if ([attributes.allKeys containsObject:@"rating"])
    {
        _rating=[[attributes objectForKey:@"rating"]intValue]/2;
    }

}

@end
