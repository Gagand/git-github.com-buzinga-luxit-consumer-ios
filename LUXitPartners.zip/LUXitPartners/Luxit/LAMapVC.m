//
//  LAMapVC.m
//  Luxit-Partners
//
//  Created by GP on 11/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "LAMapVC.h"
#import "Constant.h"
#import "LAUserHomeVC.h"
#import "LAParentViewController.h"

@implementation LAMapVC

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    CGRect _frame=CGRectMake(0.0, 15.0, 190, 50.0);
   
    NSDictionary *_attributes;
    _attributes=@{
                  kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                  };
   
    UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
    
    
    _attributes=@{
                  kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                  kASTextColor:COLOR_THEME_BROWN,
                  kASText:@"MAP",
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                  };
    [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
    
    self.navigationItem.titleView=_headerLabel;
    
    
    _attributes=@{
                  kCCImage: [UIImage imageNamed:@"Arrow.png"]
                  };
   
    UIButton *_backButton=[ccManager() buttonWithAttributes:_attributes frame:CGRectMake(0.0, 5.0, 80.0, 50.0) completion:^(UIButton *sender){
        [self.navigationController popViewControllerAnimated:YES];
    }];
    
   
    UIBarButtonItem *_backButtonItem=[[UIBarButtonItem alloc]initWithCustomView:_backButton];
    
   
    UIBarButtonItem *_leftSpaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    _leftSpaceItem.width = -31.0;
    
   
    self.navigationItem.leftBarButtonItems=[NSArray arrayWithObjects:_leftSpaceItem,_backButtonItem, nil];
   
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_mapView==nil)
    {
        _mapView=[[MKMapView alloc]initWithFrame:CGRectMake(0.0, 0.0, self.view.frame.size.width, self.view.frame.size.height)];
        _mapView.delegate=self;
        _mapView.showsUserLocation=YES;
    
        [self.view addSubview:_mapView];
        
        dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^
        {
            CLLocationCoordinate2D _userLocationCoordinate = [self geoCodeUsingAddress:appDelegate().jobDetail.location];
            
            dispatch_async(dispatch_get_main_queue(), ^
            {
                  CLLocationCoordinate2D _cooridinate= {.latitude =  _userLocationCoordinate.latitude, .longitude =  _userLocationCoordinate.longitude};
                
                MKCoordinateSpan _span = {.latitudeDelta =  1.58, .longitudeDelta =  1.58};
                  MKCoordinateRegion _region = {_cooridinate, _span};
                
                [_mapView setRegion:_region];
                
                MKPointAnnotation *_annotationPoint = [[MKPointAnnotation alloc] init];
                _annotationPoint.coordinate = _userLocationCoordinate;
               
                [_mapView addAnnotation:_annotationPoint];
            });
        });
        
        // DIVIDER (BELOW HEADER)
        NSDictionary *_attributes=nil;
        _attributes=@{
                      kCCImage:[UIImage imageNamed:@"seprator.png"]
                      };
       
        CGRect _frame;
        _frame=CGRectMake(0.0, 0.0,self.view.frame.size.width , 1.0);
        
        UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
        [self.view addSubview:_divider];
    }
}


// get lattitude and logitude from location name
- (CLLocationCoordinate2D) geoCodeUsingAddress:(NSString *)address
{
    NSString *esc_addr =  [address stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    NSString *req = [NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?sensor=false&address=%@", esc_addr];
    
    NSData *_responseData=[NSData dataWithContentsOfURL:[NSURL URLWithString:req]];
    
    double _lLat=0.0;
    double _lLng=0.0;
    
    NSDictionary *_responseDictionary=[NSJSONSerialization JSONObjectWithData:_responseData options:0 error:nil];
    
    if ([[_responseDictionary objectForKey:@"status"]isEqualToString:@"OK"])
    {
        NSArray *_resultArray=[_responseDictionary objectForKey:@"results"];
        
        if (_resultArray.count>0)
        {
            if([[[_resultArray objectAtIndex:0]allKeys]containsObject:@"geometry"])
            {
                NSDictionary *_geometry=[[_resultArray objectAtIndex:0]objectForKey:@"geometry"];
                
                if ([[_geometry allKeys]containsObject:@"location"])
                {
                    NSDictionary *_location=[_geometry objectForKey:@"location"];
                    _lLat=[[_location objectForKey:@"lat"]doubleValue];
                    _lLng=[[_location objectForKey:@"lng"]doubleValue];
                    
                }
            }
        }
    }
    
    CLLocationCoordinate2D center;
    center.latitude = _lLat;
    center.longitude = _lLng;
    return center;
}

@end
