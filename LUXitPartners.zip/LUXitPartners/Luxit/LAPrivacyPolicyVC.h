//
//  LAPrivacyPolicyVC.h
//  Luxit-Partners
//
//  Created by GP on 24/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LAPrivacyPolicyVC :  UIViewController<UIWebViewDelegate>
{
    UIWebView *_webView;
    UIActivityIndicatorView *_activityIndicatorView;
}

@end
