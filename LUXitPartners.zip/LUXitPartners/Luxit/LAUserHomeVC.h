//
//  LAUserHomeVC.h
//  Luxit-Partners
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Job.h"
#import "JobDetail.h"
#import "LAReceiptVC.h"
#import "LAReceiptVC.h"
#import "LAAcceptJobVC.h"
#import "LAJobDetailVC.h"
#import "LAJobDetailVC.h"

@interface LAUserHomeVC : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    UIView              *_welcomeWindow;
    UITableView         *_tableView;
    UIImageView         *_profileImageView;
    UIButton            *_statusButton;
    UILabel             *_statusLabel;
    CALayer             *_maskLayer;
    CABasicAnimation    *_maskAnimation;
    BOOL                _isClockingON;
    BOOL                _isJobStatusFeteched;
    BOOL                _isCancellationPopoverVisible;
    BOOL                _isTimerViewVisible;
    BOOL                _isViewVisible;
    LAAcceptJobVC       *_acceptVC;
    int                 _jobCount;
    NSMutableArray      *_ratingStarImageviewsArray;
    int                 _timeDifference;
}


- (void)resetLuxitClock;
- (void) methodCallOnExceeding3job;

@end
