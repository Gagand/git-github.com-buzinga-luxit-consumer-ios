//
//  UIViewController+LAParentViewController.h
//  Luxit-Partners
//
//  Created by GP on 21/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LAParentViewController;

@interface UIViewController (LAParentViewController)

@property(nonatomic,readonly,retain) LAParentViewController *menuContainerViewController;

@end
