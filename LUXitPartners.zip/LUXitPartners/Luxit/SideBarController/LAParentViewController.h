//
//  LAParentViewController.h
//  Luxit-Partners
//
//  Created by GP on 21/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

typedef enum
{
    CloseSimple,
    CloseWithCompleteScreen
}
CloseStatus;


typedef enum
{
    MSOpen,
    MSClosed
}
MenuState;

#import <UIKit/UIKit.h>

#import "LAHistoryVC.h"
#import "LAAboutUsVC.h"
#import "LAHelpAndFeedbackVC.h"
#import "LAChangePasswordVC.h"

#define panThreshold  15.0

@interface LAParentViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UIGestureRecognizerDelegate,UIActionSheetDelegate>
{
    UIView                  *_logoutView;
    UIView                  *_conatinerView;
    UIView                  *_optionWindow;
    UIView                  *_containerView;
    UITableView             *_tableView;
    NSMutableArray          *_menuItems;
    UIPanGestureRecognizer  *_panGesture;
    UITapGestureRecognizer  *_tapGesture;
}

@property (nonatomic, copy) void (^finishedUpdatingView)();
@property (nonatomic, assign) NSInteger selectedRowIndex;
@property (nonatomic, strong) id centerViewController;
@property (nonatomic, readwrite) MenuState menuState;

+ (LAParentViewController *)containerWithCenterViewController:(id)centerViewController;
- (void)openSideMenu;
- (void)closeSideMenu:(CloseStatus)status;
- (void)toggleSideMenuState;
- (void)enablePan;
- (void)disablePan;
- (void)switchView;

@end
