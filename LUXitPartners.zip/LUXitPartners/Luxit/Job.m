//
//  Job.m
//  Luxit-Partners
//
//  Created by GP on 11/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Job.h"

@implementation Job

- (id)initWithAttributes:(NSDictionary *)attributes
{
    self=[super init];
  
    if (self)
    {
        _dateFormatter=[[NSDateFormatter alloc]init];
        
        NSDictionary *_jobDescription=[attributes objectForKey:@"jobDescription"];

        if ([_jobDescription.allKeys containsObject:@"job_id"])
        {
             _jobId=[_jobDescription objectForKey:@"job_id"];
        }
        else
        {
            _jobId=[_jobDescription objectForKey:@"id"];
        }
       
        _itemName=[_jobDescription objectForKey:@"itemName"];
        _itemPrice=[[_jobDescription objectForKey:@"itemPrice"]doubleValue];
        _timeInterval=[[_jobDescription objectForKey:@"search_duration"]doubleValue];
        _location=[_jobDescription objectForKey:@"location"];
        _cancellationFees=[[_jobDescription objectForKey:@"cancel_amount"]floatValue];
        
        _technicianCancellationFees=0.0;
        
        if ([_jobDescription.allKeys containsObject:@"technician_cancellation_fee"] && (NSNull *)[_jobDescription objectForKey:@"technician_cancellation_fee"]!=[NSNull null])
        {
            _technicianCancellationFees=[[_jobDescription objectForKey:@"technician_cancellation_fee"]floatValue];
        }
        
        _technicianFee=0.0;
        
        
        if ([_jobDescription.allKeys containsObject:@"technician_fee"] && (NSNull *)[_jobDescription objectForKey:@"technician_fee"]!=[NSNull null])
        {
            _technicianFee=[[_jobDescription objectForKey:@"technician_fee"]floatValue];
        }
        else
        {
            _technicianFee=_itemPrice;
        }
        
        
        
        [_dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        
        _saveDateString=[_jobDescription objectForKey:@"date"];
      
        if ([_jobDescription.allKeys containsObject:@"notification_date"])
        {
            _notificationDateString=[_jobDescription objectForKey:@"notification_date"];
        }
        else
        {
           _notificationDateString=[_jobDescription objectForKey:@"date"];
        }
        
        
        _date=[_dateFormatter dateFromString:[_jobDescription objectForKey:@"date"]];
        
        [_dateFormatter setDateFormat:@"MMMM dd, yyyy"];
        _dateString=[_dateFormatter stringFromDate:_date];
        
        
        [_dateFormatter setDateFormat:@"HH:mm"];
        _timeString=[_dateFormatter stringFromDate:_date];
        
        _consumer=[[ConsumerInfo alloc]init];
        [_consumer updateWithAttributes:[attributes objectForKey:@"consumerInfo"]];
        
    }
    return self;
}
@end
