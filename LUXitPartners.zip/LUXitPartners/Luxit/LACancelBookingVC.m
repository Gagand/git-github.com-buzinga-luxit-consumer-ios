//
//  LACancelBookingVC.m
//  Luxit-Partners
//
//  Created by GP on 03/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "LAUserHomeVC.h"
#import "LACancelBookingVC.h"
#import "LAParentViewController.h"

@implementation LACancelBookingVC

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    self.navigationItem.hidesBackButton=YES;
    
    CGRect _frame=CGRectMake(0.0, 15.0, 200, 50.0);
    
    NSDictionary *_attributes;
    _attributes=@{
                  kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                  };
    UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
    
    
    _attributes=@{
                  kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                  kASTextColor:COLOR_THEME_BROWN,
                  kASText:@"CANCEL BOOKING",
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                  };
    [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
    
    self.navigationItem.titleView=_headerLabel;
 
    _attributes=@{
                  kCCBackgroundColor: [UIColor colorWithWhite:0.0 alpha:0.2]
                  };
    
    _frame=CGRectMake(0.0, 0.0, self.view.frame.size.width, 0.5);
    
    [self.view addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];
    
    
    _attributes=@{
                  kASTextColor: COLOR_THEME_BROWN,
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0],
                  kASText:@"Confirm",
                  kASCharacterSpace:[NSNumber numberWithFloat:1.2],
                  kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                  };
    _frame=CGRectMake(0.0, 0.0, 80.0, 50.0);
   
    UIButton *_confirmButton=[ccManager() buttonWithAttributes:nil frame:_frame completion:^(UIButton *sender){
        [self confirmButtonAction];
    }];
    [_confirmButton setAttributedTitle:[NSMutableAttributedString attributedStringWithAttributes:_attributes] forState:UIControlStateNormal];
    
    
    UIBarButtonItem *_confirmButtonItem=[[UIBarButtonItem alloc]initWithCustomView:_confirmButton];
   
    
    UIBarButtonItem *_rightSpaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    _rightSpaceItem.width = -20.0;
   
    
    self.navigationItem.rightBarButtonItems=[NSArray arrayWithObjects:_rightSpaceItem,_confirmButtonItem, nil];
    
    
    [self.menuContainerViewController disablePan];
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_commentTextView==nil)
    {
        // DIVIDER (BELOW HEADER)
        NSDictionary *_attributes=nil;
        CGRect _frame;
        _frame=CGRectMake(0.0, 0.0,self.view.frame.size.width , 1.0);
        _attributes=@{
                      kCCImage:[UIImage imageNamed:@"seprator.png"]
                      };
        UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
        [self.view addSubview:_divider];

        _attributes=@{
                      kASTextColor: COLOR_THEME_BROWN,
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:13.0],
                      kASText:@"Please leave a detailed explanation as to why you are cancelling the booking. We will be in contact with you on why the booking was cancelled.",
                      kASCharacterSpace:[NSNumber numberWithFloat:0.52/2.0]
                      };
        
        _frame=CGRectMake(16.0, 19.0, self.view.frame.size.width-32, 80.0);
        
        UILabel *_staticInfoLabel=[ccManager() labelWithAttributes:nil frame:_frame];
        _staticInfoLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
        [self.view addSubview:_staticInfoLabel];
        
        _frame=CGRectMake(self.view.frame.size.width/2-12.0, _frame.origin.y+_frame.size.height+36.0, 24, 0.5);
        
        NSArray *_colors=nil;
        _colors=@[
                  COLOR_THEME_LIGHTPINK,
                  COLOR_THEME_LIGHTPINK
                  ];
        
        CustomLayer*_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMVertical];
        [self.view addSubview:_customLayer];
        
        _attributes=@{
                      kCCText:@"Type explanation here",
                      kCCTextColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0],
                      kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:15.0]
                      };
        
        CGRect _placeHolderFrame=CGRectMake(21.0, _frame.origin.y+_frame.size.height+20.0, self.view.frame.size.width-42.0, 34.0);
        
        _placeHolderLabel=[ccManager() labelWithAttributes:_attributes frame:_placeHolderFrame];
        
        [self.view addSubview:_placeHolderLabel];
        
        _frame=CGRectMake(17.0, _frame.origin.y+_frame.size.height+20.0, self.view.frame.size.width-34.0, self.view.frame.size.height-(_frame.origin.y+_frame.size.height)-236.0);
        
        _attributes=@{
                      kCCTextColor:COLOR_THEME_BROWN,
                      kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:15.0],
                      kCCReturnKey:[NSNumber numberWithInt:UIReturnKeySend]
                      };
        _commentTextView=[ccManager() textViewWithAttributes:_attributes frame:_frame target:self completion:nil];
        [self.view addSubview:_commentTextView];
        [_commentTextView becomeFirstResponder];
        
    }
}


#pragma mark------------------------------------------------------------
#pragma mark TEXTVIEW DELEGATE
#pragma mark------------------------------------------------------------

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    [self performSelector:@selector(checkPlaceHolder) withObject:nil afterDelay:0.01];
    
    if ([text isEqualToString:@"\n"])
    {
        [self sendFeedback];
        
        return NO;
    }
    return YES;
}

- (void)checkPlaceHolder
{
    if (_commentTextView.text.length>0)
    {
        [_placeHolderLabel setHidden:YES];
    }
    else
    {
        [_placeHolderLabel setHidden:NO];
    }
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONS
#pragma mark------------------------------------------------------------


- (void)sendFeedback
{
    NSString *_commentString=[_commentTextView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    
    if (_commentString.length==0)
    {
        [ccManager() showAlertWithTitle:@"Info" message:@"Please add your comments" buttons:nil completion:nil];
        return;
    }
    
    [progressHud() showWithTitle:@"Please wait"];
    
    NSDictionary *_attributes=@{
                                @"userId":appDelegate().userInfo.userId,
                                @"status":@"3",
                                @"jobId":appDelegate().jobDetail.jobId,
                                @"comment":_commentString
                                };
    
    [API() cancelJobsWithAttributes:_attributes completion:^(BOOL success, NSError *error,BOOL invalid)
     {
         if (success)
         {
              [progressHud() hide];
            
             NSMutableDictionary *_jobDetail=[NSMutableDictionary dictionaryWithDictionary:[[NSUserDefaults standardUserDefaults]objectForKey:@"LastJobDetail"]];
             [_jobDetail setObject:@"3" forKey:@"status"];
             [[NSUserDefaults standardUserDefaults]setObject:_jobDetail forKey:@"LastJobDetail"];
             [[NSUserDefaults standardUserDefaults]synchronize];
             
             [appDelegate().jobDetail updateWithAttributes:_jobDetail];
              appDelegate().jobDetail.changed=YES;
             
             if ([[NSUserDefaults standardUserDefaults]boolForKey:@"isLuxingEnabale"])
             {
               [ccManager() showAlertWithTitle:@" Would you like to keep LUXing and find more work?" message:@"" buttons:@[@"No",@"Yes"] completion:^(NSInteger buttonIndex){
                   if (buttonIndex==0)
                   {
                       LAUserHomeVC *_userHomeVC=(LAUserHomeVC *)[self.navigationController.viewControllers objectAtIndex:0];
                       [_userHomeVC resetLuxitClock];
                       
                      
                   }
                   [self.menuContainerViewController switchView];
               }];
             }
             else
             {
                 [self.menuContainerViewController switchView];
             }
         }
         else
         {
             if (invalid)
             {
                 [progressHud() showWithTitle:@"Please wait"];
                 
                 NSDictionary *_attributes=@{
                                             @"userId":appDelegate().userInfo.userId
                                             };
                 [API() fetchLastCreatedJobStatusWithAttributes:_attributes completion:^(BOOL success,NSError *error1)
                  {
                      [progressHud() hide];
                      if (success)
                      {
                          [self.menuContainerViewController switchView];
                      }
                      else
                      {
                          [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
                      }
                  }];
                 return;
             }
              [progressHud() hide];
             [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
             
         }
     }];

}

- (void)confirmButtonAction
{
    [self sendFeedback];
}
@end
