//
//  LAHelpAndFeedbackVC.m
//  Luxit-Partners
//
//  Created by GP on 24/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "LAHelpAndFeedbackVC.h"
#import "LAParentViewController.h"

@implementation LAHelpAndFeedbackVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    // HEADER LABEL
    NSDictionary *_attributes;
    _attributes=@{
                  kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                  kASTextColor:COLOR_THEME_BROWN,
                  kASText:@"HELP & FEEDBACK",
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                  };
    
    CGRect _frame=CGRectMake(0.0, 15.0, 190, 50.0);
   
    UILabel *_headerLabel=[ccManager() labelWithAttributes:nil frame:_frame];
    [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
    self.navigationItem.titleView=_headerLabel;
    
    // DISABLE SLIDING GESTURE
    [self.menuContainerViewController disablePan];
    
    // LEFT BAR BUTTON(HOME BUTTON)
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"Home.png"] style:UIBarButtonItemStylePlain target:self action:@selector(homeButtonAction)];
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_scrollView==nil)
    {
        // DIVIDER (BELOW HEADER)
        NSDictionary *_attributes=nil;
        CGRect _frame;
        _frame=CGRectMake(0.0, 0.0,self.view.frame.size.width , 1.0);
        _attributes=@{
                      kCCImage:[UIImage imageNamed:@"seprator.png"]
                      };
        UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
        [self.view addSubview:_divider];
        
        float _yOffset=152.5;
        
      
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:0.75/2.0],
                      kASTextColor:COLOR_THEME_BROWN,
                      kASText:@"Contact LUXit to:",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:15.0]
                      };
        
        _frame=CGRectMake(0.0, _yOffset, self.view.frame.size.width, 16.0);
        
        UILabel *_contactLuxitStaticLabel=[ccManager() labelWithAttributes:nil frame:_frame];
        _contactLuxitStaticLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
        [self.view addSubview:_contactLuxitStaticLabel];
        
        _yOffset+=16.0+16.0;
        
        NSArray *_colors=nil;
        _colors=@[
                  [UIColor colorWithRed:175.0/255.0 green:131.0/255.0 blue:84.0/255.0 alpha:1.0],
                  [UIColor colorWithRed:247.0/255.0 green:217.0/255.0 blue:184.0/255.0 alpha:1.0]
                  ];
        
        CustomLayer *_layer=[[CustomLayer alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-12.0, _yOffset, 24.0, 0.5) withColors:_colors gradientMode:GMHorizontal];
        _layer.alpha=0.8;
        [self.view addSubview:_layer];
        
        _yOffset+=16.0;
        
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:0.52/2.0],
                      kASTextColor:COLOR_THEME_BROWN,
                      kASText:@"Update your personal details",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:13.0]
                      };
      
        _frame=CGRectMake(0.0, _yOffset, self.view.frame.size.width, 13.0);
       
        UILabel *_personalDetailsStaticLabel=[ccManager() labelWithAttributes:nil frame:_frame];
        _personalDetailsStaticLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
        [self.view addSubview:_personalDetailsStaticLabel];
        
        _yOffset+=20.0;
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:0.52/2.0],
                      kASTextColor:COLOR_THEME_BROWN,
                      kASText:@"Give feedback",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:13.0]
                      };
       
        _frame=CGRectMake(0.0, _yOffset, self.view.frame.size.width, 13.0);
        
        UILabel *_feedbackStaticLabel=[ccManager() labelWithAttributes:nil frame:_frame];
        _feedbackStaticLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
        [self.view addSubview:_feedbackStaticLabel];

        _attributes=@{
                      kCCBackgroundColor:COLOR_THEME_DARKGRAY
                      };
        _frame=CGRectMake(0.0, self.view.frame.size.height-43.5, self.view.frame.size.width, 43.5);
        UIButton *_contactusButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
            [self contactUsButtonAction];
        }];
      
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:1.35],
                      kASTextColor:COLOR_THEME_BROWN,
                      kASText:@"CONTACT US",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0]
                      };
        [_contactusButton setAttributedTitle:[NSMutableAttributedString attributedStringWithAttributes:_attributes] forState:UIControlStateNormal];
        [self.view addSubview:_contactusButton];
        
    }
}


- (void) viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [self.menuContainerViewController enablePan];
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONS
#pragma mark------------------------------------------------------------

- (void)homeButtonAction
{
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)contactUsButtonAction
{
    MFMailComposeViewController* _mailController = [[MFMailComposeViewController alloc] init];
    _mailController.mailComposeDelegate = self;
    [_mailController setSubject:@"Partner - Help & Feedback"];
    [_mailController setToRecipients:@[@"support@luxit.me"]];
    [self presentViewController:_mailController animated:YES completion:nil];
}


- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
