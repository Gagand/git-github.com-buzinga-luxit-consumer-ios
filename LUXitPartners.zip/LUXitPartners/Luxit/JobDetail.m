//
//  JobDetail.m
//  Luxit-Partners
//
//  Created by GP on 11/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "JobDetail.h"

#define LOCAL_NOTIFICATION_TAG @"LOCAL_NOTIFICATION_TAG"

@implementation JobDetail

- (id)init
{
    self=[super init];
    
    if (self)
    {
        _consumer=[[ConsumerInfo alloc]init];
        
        _dateFormatter=[[NSDateFormatter alloc]init];
        
    }
    
    return self;
}

- (void)updateWithAttributes:(NSDictionary *)attributes
{
    if (attributes.count>0)
    {
        _isJobAvailable=YES;
        _jobId=[attributes objectForKey:@"id"];
        _itemName=[attributes objectForKey:@"itemName"];
        _itemPrice=[[attributes objectForKey:@"itemPrice"]doubleValue];
        _timeInterval=[[attributes objectForKey:@"timeInterval"]doubleValue];
        _location=[attributes objectForKey:@"location"];
        _timeInterval=[[attributes objectForKey:@"timeInterval"]intValue];
        _cancellationFees=[[attributes objectForKey:@"cancellationFees"]floatValue];
        
        [_dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        
        _date=[_dateFormatter dateFromString:[attributes objectForKey:@"date"]];
        
        _dateString=@"";
        [_dateFormatter setDateFormat:@"MMMM dd, yyyy"];
        _dateString=[_dateFormatter stringFromDate:_date];
        
        _timeString=@"";
        [_dateFormatter setDateFormat:@"HH:mm"];
        _timeString=[_dateFormatter stringFromDate:_date];
        
        [self disableLocalNotification];
     
        _technicianCancellationFees=0;
       
        if ([attributes.allKeys containsObject:@"technicianCancellationFees"])
        {
            _technicianCancellationFees=[[attributes objectForKey:@"technicianCancellationFees"]floatValue];
        }
        
        _technicianFee=0.0;
        if ([attributes.allKeys containsObject:@"technicianFee"])
        {
            _technicianFee=[[attributes objectForKey:@"technicianFee"]floatValue];
        }
        else
        {
            _technicianFee=_itemPrice;
        }
    
        
        
        int _statusValue=[[attributes objectForKey:@"status"] intValue];
        
        if (_statusValue==0)
        {
            _isJobAvailable=NO;
            _status=JSNoJob;
        }
        else if (_statusValue==1)
        {
            [self enableLocalNotitifcation];
            _status=JSPending;
            [_consumer updateWithAttributes:[attributes objectForKey:@"consumer"]];
        }
        else if (_statusValue==2)
        {
            _isJobAvailable=NO;
            _status=JSNoJob;
            [_consumer updateWithAttributes:[attributes objectForKey:@"consumer"]];
        }
        else if (_statusValue==3)
        {
            _isJobAvailable=NO;
            _status=JSNoJob;
            [_consumer updateWithAttributes:[attributes objectForKey:@"consumer"]];
        }
        else if (_statusValue==4)
        {
            _status=JSStarted;
            [_consumer updateWithAttributes:[attributes objectForKey:@"consumer"]];
        }
        else if (_statusValue==5)
        {
            _status=JSCompleted;
            [_consumer updateWithAttributes:[attributes objectForKey:@"consumer"]];
        }
        else if (_statusValue==6)
        {
            _status=JSCancelledUnpaid;
            [_consumer updateWithAttributes:[attributes objectForKey:@"consumer"]];
        }
        else if (_statusValue==7)
        {
            _status=JSCompleteUnpaid;
            [_consumer updateWithAttributes:[attributes objectForKey:@"consumer"]];
        }
        else if (_statusValue==8)
        {
            _status=JSNeedFeedback;
            [_consumer updateWithAttributes:[attributes objectForKey:@"consumer"]];
        }
        else if (_statusValue==9)
        {
            _isJobAvailable=NO;
            _status=JSNoJob;
        }
    }
    else
    {
        [self disableLocalNotification];
        _isJobAvailable=NO;
        _status=JSNoJob;
    }
    
}


- (void)enableLocalNotitifcation
{
    [self disableLocalNotification];
    
    NSDate *_savedDate=[_date copy];
     _savedDate=[_savedDate dateByAddingTimeInterval:45*60];
 
    NSDate *_currentDate=[NSDate date];
    
    NSTimeInterval _interval = [_savedDate timeIntervalSinceDate:_currentDate];
    
    if (_interval>0)
    {
        UILocalNotification* _localNotification = [[UILocalNotification alloc] init];
        _localNotification.alertBody = [NSString stringWithFormat:@"Just checking in, you should be approaching your next client, if running late be sure to shoot %@ a quick text to let them know!",_consumer.firstName];
        _localNotification.soundName = UILocalNotificationDefaultSoundName;
        _localNotification.applicationIconBadgeNumber = 1;
        [_localNotification setTimeZone:[NSTimeZone defaultTimeZone]];
        _localNotification.fireDate = _savedDate;
        _localNotification.userInfo=[NSDictionary dictionaryWithObject:LOCAL_NOTIFICATION_TAG forKey:@"tag"];
        [[UIApplication sharedApplication] scheduleLocalNotification:_localNotification];
    }
}


- (void)disableLocalNotification
{
    UIApplication *_app = [UIApplication sharedApplication];
    
    NSArray *_scheduledNotificationArray = [_app scheduledLocalNotifications];
   
    for (int i=0; i<[_scheduledNotificationArray count]; i++)
    {
        UILocalNotification* _localNotification = [_scheduledNotificationArray objectAtIndex:i];
        [_app cancelLocalNotification:_localNotification];
    }
}
@end
