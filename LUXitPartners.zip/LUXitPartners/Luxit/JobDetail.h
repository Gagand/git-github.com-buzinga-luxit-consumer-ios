//
//  JobDetail.h
//  Luxit-Partners
//
//  Created by GP on 11/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

/*****
 Searching=>0,
 Accept=>1,
 Cancel by consumer=>2,
 Cancel by technician=>3,
 Working=>4,
 Completed=>5,
 Deleted=>6,
 Feedback =>7
 *****/


typedef enum
{
    JSNoJob,
    JSSearching,
    JSCancelByTechnician,
    JSPending,
    JSStarted,
    JSCompleted,
    JSNeedFeedback,
    JSCancelledUnpaid,
    JSCompleteUnpaid
}
JobStatus;

#import <Foundation/Foundation.h>

#import "ConsumerInfo.h"

@interface JobDetail : NSObject
{
    NSDateFormatter *_dateFormatter;
}

@property (nonatomic, assign) BOOL isJobAvailable;
@property (nonatomic, retain) NSString *jobId;
@property (nonatomic, retain) NSString *location;
@property (nonatomic, retain) NSDate *date;
@property (nonatomic, retain) NSString *dateString;
@property (nonatomic, retain) NSString *timeString;
@property (nonatomic, retain) NSString *itemName;
@property (nonatomic, assign) double itemPrice;
@property (nonatomic, assign) double cancellationFees;
@property (nonatomic, assign) double technicianCancellationFees;
@property (nonatomic, assign) double technicianFee;
@property (nonatomic, assign) int timeInterval;
@property (nonatomic, retain) ConsumerInfo *consumer;
@property (nonatomic, readwrite) JobStatus status;
@property (nonatomic, readwrite) BOOL       changed;
@property (nonatomic, readwrite) BOOL       isPaid;


- (void)updateWithAttributes:(NSDictionary *)attributes;
- (void)enableLocalNotitifcation;
- (void)disableLocalNotification;

@end

