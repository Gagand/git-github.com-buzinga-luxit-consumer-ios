//
//  LAAcceptJobVC.h
//  Luxit-Partners
//
//  Created by GP on 03/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Job.h"

@interface LAAcceptJobVC : UIViewController
{
    UIView      *_containerView;
    UILabel     *_timerCountLabel;
    NSTimer     *_timer;
}

@property (nonatomic, assign)int timeCount;
@property (nonatomic, retain)Job *job;
@property (nonatomic, copy)void(^finishedAcceptingJob)();
@property (nonatomic, copy)void(^finishedCancellingJob)(BOOL);

@end
