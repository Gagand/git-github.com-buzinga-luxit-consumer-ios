//
//  LAAppDelegate.m
//  Luxit-Partners
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//


#import "Constant.h"
#import "LALoginVC.h"
#import "LASplashVC.h"
#import "LAUserHomeVC.h"
#import "LAAppDelegate.h"
#import "LAParentViewController.h"

static NSString *const kTrackingId    = @"UA-68049988-1";
static NSString *const kAllowTracking = @"allowTracking";

@implementation LAAppDelegate

#pragma mark------------------------------------------------------------
#pragma mark WINDOW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    if ([[UIApplication sharedApplication] backgroundRefreshStatus] == UIBackgroundRefreshStatusAvailable) {
        NSLog(@"Background updates are available for the app.");
    }else if([[UIApplication sharedApplication] backgroundRefreshStatus] == UIBackgroundRefreshStatusDenied)
    {
        [ccManager() showAlertWithTitle:nil message:@"The user explicitly disabled background behavior for this app or for the whole system. Please Enable them in Settings > General > Background App Refresh." buttons:@[@"Go to Settings"] completion:^(NSInteger buttonIndex)
         {
             if (buttonIndex == 0)
             {
                 [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
             }}
         ];
        //        NSLog(@"The user explicitly disabled background behavior for this app or for the whole system.");
    }else if([[UIApplication sharedApplication] backgroundRefreshStatus] == UIBackgroundRefreshStatusRestricted)
    {
        [ccManager() showAlertWithTitle:nil message:@"Background updates are unavailable and the user cannot enable them again. For example, this status can occur when parental controls are in effect for the current user." buttons:@[@"Go to Settings"] completion:^(NSInteger buttonIndex)
         {
             if (buttonIndex == 0)
             {
                 [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
             }}
         ];
        
        NSLog(@"Background updates are unavailable and the user cannot enable them again. For example, this status can occur when parental controls are in effect for the current user.");
    }

    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
  
    NSDictionary *appDefaults = @{kAllowTracking: @(YES)};
    [[NSUserDefaults standardUserDefaults] registerDefaults:appDefaults];
    [GAI sharedInstance].optOut =
    ![[NSUserDefaults standardUserDefaults] boolForKey:kAllowTracking];
    
    // GA
    [GAI sharedInstance].trackUncaughtExceptions = YES;
    [[GAI sharedInstance].logger setLogLevel:kGAILogLevelNone];
    [GAI sharedInstance].dispatchInterval = -1;
    [[GAI sharedInstance] trackerWithTrackingId:kTrackingId];
    
    id tracker = [[GAI sharedInstance] defaultTracker];
    [tracker set:kGAIScreenName value:@"LUXit Partners"];
    [tracker send:[[GAIDictionaryBuilder createScreenView] build]];
    
    //LOCATION MANAGER
    _locationManager=[[CLLocationManager alloc]init];
    _locationManager.delegate=self;
    _locationManager.distanceFilter = kCLDistanceFilterNone;
    _locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters;
    [self disableLocationService];
    
    // CREATE A IMAGE FOLDER IN ORDER TO SAVE IMAGES
    NSArray  *_documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *_documentsDir  = [_documentPaths objectAtIndex:0];
    NSString *_NotesFolder   = [_documentsDir stringByAppendingPathComponent:@"Images"];
    
    if (![[NSFileManager defaultManager]fileExistsAtPath:_NotesFolder])
    {
        [[NSFileManager defaultManager]createDirectoryAtPath:_NotesFolder withIntermediateDirectories:NO attributes:nil error:nil];
    }
    
    // USER INFO
    _userInfo=[[UserInfo alloc]init];
    [_userInfo updateWithAttributes:[[NSUserDefaults standardUserDefaults]objectForKey:@"UserInfo"]];
    
    // LAST JOB SAVED STATUS
     _jobDetail=[[JobDetail alloc]init];
    [_jobDetail updateWithAttributes:[[NSUserDefaults standardUserDefaults]objectForKey:@"LastJobDetail"]];
    
    //REMOTE NOTIFICATION

    apnManager();
    
    // UPDATE DATE WHEN APP IS OPEN FROM PUSH NOTIFICATION BANNER VIEW
    NSDictionary *_remoteNotification = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
    
    if (_remoteNotification)
    {
        if(appDelegate().userInfo.isUserAvailable)
        {
            [appDelegate() showUserHomeViewControllerWithAnimation:NO];
            
            if (_receiveRemoteNotification)
            {
                _receiveRemoteNotification(_remoteNotification,NO);
            }
        }
        else
        {
            [self showSplashViewController];
        }
    }
    else
    {
        [self showSplashViewController];
    }
    
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:1];
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
    
    return YES;
}


- (void)applicationWillEnterForeground:(UIApplication *)application{
    
  /*  [API() checkForJobCount:@{
                              @"userId":appDelegate().userInfo.userId,
                              } completion:^(BOOL var1, NSError * err, BOOL var2, NSDictionary * dic) {
                                  if ([dic[@"status"] boolValue]) {
                                      [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%@",dic[@"no_of_jobs"]] forKey:@"jobCount"];
                                      [[NSUserDefaults standardUserDefaults] synchronize];
                                  }
                                  
                                  if ([[appDelegate().navigationController.viewControllers lastObject] isKindOfClass:[LAUserHomeVC class]]) {
                                      LAUserHomeVC *_objLAUserHomeVC = [appDelegate().navigationController.viewControllers lastObject];
                                      [_objLAUserHomeVC methodCallOnExceeding3job];
                                  }
                                  NSLog(@"%@",dic);
                              }];*/
    if (_updateAppStatus){
        _updateAppStatus(ASForeground);
    }
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:1];
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
    
    
    if ([[UIApplication sharedApplication] backgroundRefreshStatus] == UIBackgroundRefreshStatusAvailable) {
        NSLog(@"Background updates are available for the app.");
    }else if([[UIApplication sharedApplication] backgroundRefreshStatus] == UIBackgroundRefreshStatusDenied)
    {
        [ccManager() showAlertWithTitle:nil message:@"The user explicitly disabled background behavior for this app or for the whole system. Please Enable them in Settings > General > Background App Refresh." buttons:@[@"Go to Settings"] completion:^(NSInteger buttonIndex)
         {
             if (buttonIndex == 0)
             {
                 [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
             }}
         ];
//        NSLog(@"The user explicitly disabled background behavior for this app or for the whole system.");
    }else if([[UIApplication sharedApplication] backgroundRefreshStatus] == UIBackgroundRefreshStatusRestricted)
    {
        [ccManager() showAlertWithTitle:nil message:@"Background updates are unavailable and the user cannot enable them again. For example, this status can occur when parental controls are in effect for the current user." buttons:@[@"Go to Settings"] completion:^(NSInteger buttonIndex)
         {
             if (buttonIndex == 0)
             {
                 [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
             }}
         ];

        NSLog(@"Background updates are unavailable and the user cannot enable them again. For example, this status can occur when parental controls are in effect for the current user.");
    }
}


- (void)applicationDidEnterBackground:(UIApplication *)application
{
    if (_updateAppStatus)
    {
        _updateAppStatus(ASBackground);
    }
    [self sendHitsInBackground];
}


- (void)applicationDidBecomeActive:(UIApplication *)application
{
    [GAI sharedInstance].optOut =![[NSUserDefaults standardUserDefaults] boolForKey:kAllowTracking];
}


-(void)application:(UIApplication *)application performFetchWithCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler
{
    [self sendHitsInBackground];
    completionHandler(UIBackgroundFetchResultNewData);
}


- (void)applicationWillTerminate:(UIApplication *)application
{
    if (_userInfo.isUserAvailable)
    {
        NSDictionary *_attributes=nil;
        _attributes=@{
                      @"userId": _userInfo.userId,
                      @"availability":@"1"
                      };
        [API() changeAvailablityWithAttributes:_attributes completion:nil];
    }
    [[NSUserDefaults standardUserDefaults]setObject:@"0" forKey:@"jobCount"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSUserDefaults standardUserDefaults]setBool:NO forKey:@"isLuxingEnabale"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    if (_jobDetail.status==JSNoJob)
    {
         [[UIApplication sharedApplication] unregisterForRemoteNotifications];
    }
}


#pragma mark------------------------------------------------------------
#pragma mark GOOGLE ANALYTICS
#pragma mark------------------------------------------------------------

- (void)sendHitsInBackground
{
    self.okToWait = YES;
    __weak LAAppDelegate *weakSelf = self;
    __block UIBackgroundTaskIdentifier backgroundTaskId =
    [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
        weakSelf.okToWait = NO;
    }];
    
    if (backgroundTaskId == UIBackgroundTaskInvalid)
    {
        return;
    }
    
    self.dispatchHandler = ^(GAIDispatchResult result)
    {
        if (result == kGAIDispatchGood && weakSelf.okToWait )
        {
            NSLog(@"Good");
            [[GAI sharedInstance] dispatchWithCompletionHandler:weakSelf.dispatchHandler];
        }
        else
        {
            NSLog(@"Error");
            [[UIApplication sharedApplication] endBackgroundTask:backgroundTaskId];
        }
    };
    
    [[GAI sharedInstance] dispatchWithCompletionHandler:self.dispatchHandler];
}


#pragma mark------------------------------------------------------------
#pragma mark PUSH NOTIFICATION DELEGATES
#pragma mark------------------------------------------------------------

- (void)enablePushNotification
{
    UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes: (UIRemoteNotificationTypeBadge|UIRemoteNotificationTypeSound|UIRemoteNotificationTypeAlert) categories:nil];
    [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
}


- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
    NSMutableString *_devToken = [NSMutableString stringWithFormat:@"%@",deviceToken];
    [_devToken replaceOccurrencesOfString:@"<" withString:@"" options:0 range:NSMakeRange(0, [_devToken length])];
    [_devToken replaceOccurrencesOfString:@">" withString:@"" options:0 range:NSMakeRange(0, [_devToken length])];
    [_devToken replaceOccurrencesOfString:@" " withString:@"" options:0 range:NSMakeRange(0, [_devToken length])];
    [[NSUserDefaults standardUserDefaults] setObject:_devToken forKey:@"deviceToken"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    if (appDelegate().userInfo.isUserAvailable)
    {
        [API() updateDeviceTokenWithAttributes:nil completion:nil];
    }
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler{

    NSLog(@"bckgrd fetch %@", userInfo);
    
    if (_receiveRemoteNotification)
    {
        _receiveRemoteNotification(userInfo,YES);
    }
//    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:1];
//    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
    
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    
    NSLog(@"pus %@", userInfo);

    if (_receiveRemoteNotification)
    {
        _receiveRemoteNotification(userInfo,YES);
    }
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:1];
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
}


- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:  (UIUserNotificationSettings *)notificationSettings
{
    if (notificationSettings.types==UIUserNotificationTypeNone)
    {
        [self validateRemoteNotification];
    }
    [application registerForRemoteNotifications];
}


- (void)application:(UIApplication *)application handleActionWithIdentifier:(NSString   *)identifier forRemoteNotification:(NSDictionary *)userInfo completionHandler:(void(^)())completionHandler
{
    if (_receiveRemoteNotification)
    {
        _receiveRemoteNotification(userInfo,YES);
    }
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:1];
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
}


- (void)validateRemoteNotification
{
    if ([[UIApplication sharedApplication] isRegisteredForRemoteNotifications])
    {
        [[NSUserDefaults standardUserDefaults]setObject:@"0" forKey:@"AppNotificationShown"];
        [[NSUserDefaults standardUserDefaults]synchronize];
    }
    else
    {
        if ([[NSUserDefaults standardUserDefaults]objectForKey:@"AppNotificationShown"]==NULL) {
            [self showRemoteNotificationAlert];
            return;
        }
        
        if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"AppNotificationShown"] intValue]==3)
        {
            [self showRemoteNotificationAlert];
        }
        else
        {
            [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%i",[[[NSUserDefaults standardUserDefaults]objectForKey:@"AppNotificationShown"] intValue]+1] forKey:@"AppNotificationShown"];
            [[NSUserDefaults standardUserDefaults]synchronize];
        }
    }
}


- (void)showRemoteNotificationAlert
{
    [[NSUserDefaults standardUserDefaults]setObject:@"1" forKey:@"AppNotificationShown"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    NSArray *_buttonsArray=@[@"Close",@"Go to Settings"];
    
    [ccManager() showAlertWithTitle:@"Change your Settings to allow LUXit Partners to Send You Push Notifications" message:@"We need to be able to send you Push Notifications to let you know when a new booking is available around you. Please go to the App Settings, tap on Notifications and then select Allow Notifications." buttons:_buttonsArray completion:^(NSInteger buttonIndex)
    {
        if ([[_buttonsArray objectAtIndex:buttonIndex]isEqualToString:@"Go to Settings"])
        {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
        }
    }];
}


#pragma mark------------------------------------------------------------
#pragma mark VIEW CONTROLLERS
#pragma mark------------------------------------------------------------

- (void)showSplashViewController
{
    _window.rootViewController=[[LASplashVC alloc]init];
}


- (void)showLoginViewController
{
    if (_navigationController)
    {
        _navigationController=nil;
    }
    _navigationController=[[UINavigationController alloc]initWithRootViewController:[[LALoginVC alloc]init]];
    _navigationController.navigationBarHidden=YES;
    
    _window.rootViewController=_navigationController;
    
    [UIView transitionWithView:_window duration:0.25 options:UIViewAnimationOptionTransitionCrossDissolve animations:nil completion:nil];
}


- (void)showUserHomeViewControllerWithAnimation:(BOOL)animation
{
    if (_navigationController)
    {
        _navigationController=nil;
    }
    
     [API() updateDeviceTokenWithAttributes:nil completion:nil];
    
    _navigationController=[[UINavigationController alloc]initWithRootViewController:[[LAUserHomeVC alloc]init]];
    [ccManager() customizeNavigationBarWithAttributes:@{
                                                        kCCTintColor: COLOR_THEME_BROWN,
                                                        kCCBarTintColor:[UIColor whiteColor],
                                                        kCCTextColor:COLOR_THEME_BROWN,
                                                        kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:14.0]
                                                        }
                                 navigationController:_navigationController];
    
    LAParentViewController *_parentVC=[LAParentViewController containerWithCenterViewController:_navigationController];
    
    _window.rootViewController=_parentVC;
    
    if (animation)
    {
         [UIView transitionWithView:_window duration:0.25 options:UIViewAnimationOptionTransitionCrossDissolve animations:nil completion:nil];
    }
}


#pragma mark------------------------------------------------------------
#pragma mark CLLOCATION MANAGER DELEGATE
#pragma mark------------------------------------------------------------

-(void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    _locationEnabled=YES;
    
    [self updateUserLocationInfoForLat:newLocation.coordinate.latitude Lng:newLocation.coordinate.longitude];
}


-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"MyCurrentLocation"]==NULL)
    {
        _locationEnabled=NO;
    }
    else
    {
        _locationEnabled=YES;
    }
}


- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status
{
    _locationServiceStatus=0;
   
    if(status==kCLAuthorizationStatusNotDetermined)
    {
        _locationServiceStatus=0;
    }
    else if (status == kCLAuthorizationStatusAuthorized|| status == 3 || status == 4)
    {
        _locationServiceStatus=1;
        
        if (_updateLocationAuthorization)
        {
            _updateLocationAuthorization(YES);
        }
        
    }
    else if (status == kCLAuthorizationStatusDenied)
    {
        _locationServiceStatus=2;
        
        if (_updateLocationAuthorization)
        {
            _updateLocationAuthorization(NO);
        }
    }
}


- (void)updateUserLocationInfoForLat:(double)lat Lng:(double)lng
{
    BOOL _updateLocation=NO;
    
    if (lat!=0.0||lng!=0.0)
    {
        if ((NSNull *)[[NSUserDefaults standardUserDefaults]objectForKey:@"MyCurrentLocation"]!=[NSNull null])
        {
            CLLocation *_currentLocation = [[CLLocation alloc] initWithLatitude:lat longitude:lng];
            
            CLLocation *_previousLocation = [[CLLocation alloc] initWithLatitude:[[[[NSUserDefaults standardUserDefaults]objectForKey:@"MyCurrentLocation"]objectForKey:@"Lat"]doubleValue] longitude:[[[[NSUserDefaults standardUserDefaults]objectForKey:@"MyCurrentLocation"]objectForKey:@"Lng"]doubleValue]];
            
            CLLocationDistance _distance = [_currentLocation distanceFromLocation:_previousLocation];
            
            if (_distance>200)
            {
                _updateLocation=YES;
            }
            else
            {
                _updateLocation=NO;
            }
        }
        else
        {
            _updateLocation=YES;
        }
    }
    else
    {
        _updateLocation=NO;
    }
    
    if (_updateLocation)
    {
        if (appDelegate().userInfo.isUserAvailable)
        {
            NSDictionary *_attributes=nil;
            _attributes=@{
                          @"userId":_userInfo.userId,
                          @"lat":[[NSNumber numberWithDouble:lat]stringValue],
                          @"lng":[[NSNumber numberWithDouble:lng]stringValue]
                          };
            
            [API() updateUserLocationCoordinateWithAttributes:_attributes completion:^(BOOL success, NSError *error){
                if (success)
                {
                    NSMutableDictionary *_dictionary=[NSMutableDictionary dictionaryWithCapacity:2];
                    [_dictionary setObject:[[NSNumber numberWithDouble:lat]stringValue] forKey:@"Lat"];
                    [_dictionary setObject:[[NSNumber numberWithDouble:lng]stringValue] forKey:@"Lng"];
                   
                    [[NSUserDefaults standardUserDefaults]setObject:_dictionary forKey:@"MyCurrentLocation"];
                    [[NSUserDefaults standardUserDefaults]synchronize];
                }
            }];
        }
    }
}


- (void)enableLocationService
{
    [_locationManager requestAlwaysAuthorization];
    [_locationManager startUpdatingLocation];
}


- (void)disableLocationService
{
    [_locationManager stopUpdatingLocation];
}


#pragma mark------------------------------------------------------------
#pragma mark LOCAL NOTIFICATION
#pragma mark------------------------------------------------------------

- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification
{
    if (appDelegate().userInfo.isUserAvailable)
    {
        [ccManager() showAlertWithTitle:notification.alertBody message:@"" buttons:@[@"Close"] completion:nil];
    }
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:1];
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
}

@end

LAAppDelegate *appDelegate(void)
{
    return (LAAppDelegate *)[UIApplication sharedApplication].delegate;
}