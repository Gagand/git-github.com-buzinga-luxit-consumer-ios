//
//  LALoginVC.m
//  Luxit-Partners
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "LALoginVC.h"

@implementation LALoginVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    // BACKGROUND COLOR
    self.view.backgroundColor=[UIColor whiteColor];
    
    // TAP GESTURE
    [self.view addGestureRecognizer:[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(handleTap)]];
    
    float _yDisplacementFactor=0.0;
    if (IS_IPHONE_6) {
        _yDisplacementFactor=90.0;
    }
    
    // LOGO IMAGEVIEW
    NSDictionary *_attributes=nil;
    _attributes=@{
                  kCCImage: [UIImage imageNamed:@"Start_Logo.png"]
                  };
   
    CGRect _frame=CGRectMake(self.view.frame.size.width/2-145.0/2.0, 81.5+_yDisplacementFactor, 145.0, 145.0);
   
    UIImageView *_logoImageView=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
    [self.view addSubview:_logoImageView];
    
    
    // EMAIL BACKGROUND CONTAINER VIEW
    _attributes=@{
                  kCCBackgroundColor: [UIColor colorWithRed:221.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0]
                  };
    
    _frame=CGRectMake(0.0, self.view.frame.size.height-240, self.view.frame.size.width, 0.55);
  
    UIView *_cotainerView=[ccManager() viewWithAttributes:_attributes frame:_frame];
    [self.view addSubview:_cotainerView];
   
    _attributes=@{
                  kCCBackgroundColor: [UIColor colorWithRed:221.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0]
                  };
    
    _frame=CGRectMake(0.0, _frame.origin.y+43.0, self.view.frame.size.width, 0.55);
    
    _cotainerView=[ccManager() viewWithAttributes:_attributes frame:_frame];
    [self.view addSubview:_cotainerView];
    
    // EMAIL TEXTFIELD
    _attributes=@{
                  kCCTextColor: COLOR_THEME_BROWN,
                  kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:15.0],
                  kCCPlaceHolderColor:[UIColor colorWithRed:221.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0],
                  kCCPlaceHolderText:@"Enter email",
                  kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                  kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeEmailAddress],
                  kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                  };
   
    _frame=CGRectMake(10.0, _frame.origin.y-44.0, self.view.frame.size.width-20.0, 44.0);
   
    _emailTF=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
    [self.view addSubview:_emailTF];
    

    // PASSWORD TEXTFIELD
    _attributes=@{
                  kCCTextColor: COLOR_THEME_BROWN,
                  kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:15.0],
                  kCCPlaceHolderColor:[UIColor colorWithRed:221.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0],
                  kCCPlaceHolderText:@"Enter password",
                  kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyGo],
                  kCCSecureEntery:@"YES",
                  kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                  };
    _frame=CGRectMake(10.0, _frame.origin.y+_frame.size.height, self.view.frame.size.width-20.0, 44.0);
   
    _passwordTF=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
    [self.view addSubview:_passwordTF];
    
    _attributes=@{
                  kCCBackgroundColor: [UIColor colorWithRed:221.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0]
                  };
    
    _frame=CGRectMake(0.0, _frame.origin.y+44.0, self.view.frame.size.width, 0.55);
    
    _cotainerView=[ccManager() viewWithAttributes:_attributes frame:_frame];
    [self.view addSubview:_cotainerView];
    
    
    // LOGIN BUTTON (GRADIENT LAYER, BUTTON)
    NSArray *_colors;
    _colors=@[
              COLOR_THEME_BROWN,
              COLOR_THEME_LIGHTPINK
              ];
   
    _frame=CGRectMake(20.0, _frame.origin.y+_frame.size.height+20.0, self.view.frame.size.width-40.0, 44.0);
   
    CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
    [self.view addSubview:_customLayer];
   
    _attributes=@{
                  kCCBackgroundColor:COLOR_THEME_DARKGRAY
                  };
    
    _frame=CGRectMake(_frame.origin.x+1.5, _frame.origin.y+1.5, _frame.size.width-3.0, _frame.size.height-3.0);
    
    UIButton *_registerButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
        [self validateAndSignin];
    }];
    
    _attributes=@{
                  kASTextColor: COLOR_THEME_BROWN,
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0],
                  kASText:@"LOG IN",
                  kASCharacterSpace:[NSNumber numberWithFloat:1.35]
                  };
    
    NSMutableAttributedString *_attributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
    [_registerButton setAttributedTitle:_attributedString forState:UIControlStateNormal];
    [self.view addSubview:_registerButton];
    
    
    //FORGOT PASSWORD BUTTON
    _attributes=@{
                  kCCTextColor: COLOR_THEME_BROWN,
                  kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:13.0],
                  kCCText:@"Forgot password?"
                  };

    _frame=CGRectMake(10.0, _frame.origin.y+_frame.size.height, self.view.frame.size.width-20.0,45.0);
   
    [self.view addSubview:[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender)
    {
        [self forgotPasswordButtonAction];
    }]];
    
    
    // WEBSITE LINK BUTTON
    _attributes=@{
                  kASTextColor: COLOR_THEME_BROWN,
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0],
                  kASText:@"Join our team at\n",
                  kASCharacterSpace:[NSNumber numberWithFloat:0.48/2.0]
                  };
    _attributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
    
    _attributes=@{
                  kASTextColor: COLOR_THEME_BROWN,
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                  kASText:@"www.luxit.me",
                  kASCharacterSpace:[NSNumber numberWithFloat:0.48/2.0]
                  };
    [_attributedString appendAttributedString:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
 
    _frame=CGRectMake(10.0, _frame.origin.y+_frame.size.height, self.view.frame.size.width-20.0,30.0);
    
    UIButton *_linkButton=[ccManager() buttonWithAttributes:nil frame:_frame completion:^(UIButton *sender){
        [[UIApplication sharedApplication]openURL:[NSURL URLWithString:@"http://luxit.me"]];
    }];
    [_linkButton setAttributedTitle:_attributedString forState:UIControlStateNormal];
    [self.view addSubview:_linkButton];
    
    appDelegate().updateAppStatus=^(AppStatus status)
    {
        if (status==ASBackground)
        {
            [self resetView];
        }
    };
}


#pragma mark------------------------------------------------------------
#pragma mark TEXTFIELD DELEGATE
#pragma mark------------------------------------------------------------

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.25];
    self.view.frame=CGRectMake(0.0, -140.0, self.view.frame.size.width, self.view.frame.size.height);
    [UIView commitAnimations];
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField==_emailTF)
    {
        [_passwordTF becomeFirstResponder];
    }
    else
    {
        [self validateAndSignin];
    }
    return YES;
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONS
#pragma mark------------------------------------------------------------

- (void)forgotPasswordButtonAction
{
    [self resetView];
    LAForgotPasswordVC *_forgotPasswordVC=[[LAForgotPasswordVC alloc]init];
    [self.navigationController pushViewController:_forgotPasswordVC animated:YES];
}


- (void)validateAndSignin
{
    NSString *_email=[_emailTF.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *_password=[_passwordTF.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    
    if (_email.length==0 && _password.length==0)
    {
        [ccManager() showAlertWithTitle:@"Login details not valid" message:@"Please fill in all fields and verify that your email and password are correct" buttons:nil completion:nil];
        return;
    }
    
    if (_email.length==0 && _password.length!=0)
    {
       [ccManager() showAlertWithTitle:@"Email" message:@"Your email is required and must be in a valid email format" buttons:nil completion:nil];
        return;
    }
    
    if (![self isValidEmail:_email])
    {
        [ccManager() showAlertWithTitle:@"Email" message:@"Your email is required and must be in a valid email format" buttons:nil completion:nil];
        return;
    }
    
    if (_email.length!=0 && _password.length==0)
    {
        [ccManager() showAlertWithTitle:@"Password" message:@"Your password is required and must be valid" buttons:nil completion:nil];
        return;
    }

    [self resetView];
   
    NSString *_deviceToken=[[NSUserDefaults standardUserDefaults]objectForKey:@"deviceToken"];
    
    if (_deviceToken==NULL)
    {
        _deviceToken=@"";
    }
    
    NSDictionary *_attributes=@{
                                @"email":_email,
                                @"password":_password,
                                @"deviceToken":_deviceToken,
                                @"deviceType":@"ios",
                                @"userType":@"0"
                                };
    
    [progressHud() showWithTitle:@"Please wait"];
    
    [API() loginWithAttributes:_attributes completion:^(BOOL success, NSError *error)
     {
         if (success)
         {
             [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"MyCurrentLocation"];
             [[NSUserDefaults standardUserDefaults]synchronize];
             
             [progressHud() showWithTitle:@"Success\nYou logged in successfully"];
            
             [self performSelector:@selector(hideProgessHudAfterLogin:) withObject:[NSNumber numberWithBool:success] afterDelay:1.5];
         }
         else
         {
             [progressHud() hide];
            
             [ccManager() showAlertWithTitle:[[error userInfo] objectForKey:@"title"] message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
         }
     }];
}


-(BOOL)isValidEmail:(NSString *)email
{
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z()<>@!#$%&'*+-/=?^_`{}|~.]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}


- (void)hideProgessHudAfterLogin:(NSNumber *)success
{
    if ([success intValue]==1)
    {
        [appDelegate() showUserHomeViewControllerWithAnimation:YES];
    }
    else
    {
        [progressHud() hide];
    }
}


- (void)handleTap
{
    [self resetView];
}


- (void)resetView
{
    [_emailTF resignFirstResponder];
    [_passwordTF resignFirstResponder];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.25];
    self.view.frame=CGRectMake(0.0, 0.0, self.view.frame.size.width, self.view.frame.size.height);
    [UIView commitAnimations];
}
@end
