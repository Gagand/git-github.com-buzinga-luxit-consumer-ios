//
//  LAAboutUsDetailVC.m
//  Luxit-Partners
//
//  Created by GP on 24/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "LAAboutUsDetailVC.h"

@implementation LAAboutUsDetailVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];

    NSDictionary *_attributes;
    _attributes=@{
                  kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                  kASTextColor:COLOR_THEME_BROWN,
                  kASText:@"ABOUT US",
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                  };
  
    CGRect _frame=CGRectMake(0.0, 15.0, 190, 50.0);
   
    UILabel *_headerLabel=[ccManager() labelWithAttributes:nil frame:_frame];
    [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
    
    self.navigationItem.titleView=_headerLabel;
    
    _attributes=@{
                  kCCImage: [UIImage imageNamed:@"Arrow.png"]
                  };
    UIButton *_backButton=[ccManager() buttonWithAttributes:_attributes frame:CGRectMake(0.0, 5.0, 80.0, 50.0) completion:^(UIButton *sender){
        [self.navigationController popViewControllerAnimated:YES];
    }];
    
    UIBarButtonItem *_backButtonItem=[[UIBarButtonItem alloc]initWithCustomView:_backButton];
    
    UIBarButtonItem *_leftSpaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    _leftSpaceItem.width = -31.0;
    
    self.navigationItem.leftBarButtonItems=[NSArray arrayWithObjects:_leftSpaceItem,_backButtonItem, nil];
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_scrollView==nil)
    {
        // DIVIDER (BELOW HEADER)
        NSDictionary *_attributes=nil;
        CGRect _frame;
        _frame=CGRectMake(0.0, 0.0,self.view.frame.size.width , 1.0);
        _attributes=@{
                      kCCImage:[UIImage imageNamed:@"seprator.png"]
                      };
        UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
        [self.view addSubview:_divider];
        
        
        _scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0.0, 0.0, self.view.frame.size.width, self.view.frame.size.height)];
        _scrollView.backgroundColor=[UIColor clearColor];
        _scrollView.showsVerticalScrollIndicator=NO;
        [self.view addSubview:_scrollView];
        
        
        _frame=CGRectMake(_scrollView.frame.size.width/2-145.0/2, 19.0, 145.0, 145.0);

        _attributes=@{
                      kCCImage: [UIImage imageNamed:@"About_Us_Logo.png"],
                      };
        [_scrollView addSubview:[ccManager() imageViewWithAttributes:_attributes frame:_frame]];
        
        
        NSString *_textString=@"Imagine the convenience of working when you want at a press of a button. LUXit is a simple and user-friendly application that connects clients with experts in the beauty, wellness and personal care industry. Understanding that our experts are always looking for more clients, LUXit has created a hassle free, convenient platform which handles all the admin and marketing of your business, so that you can focus on what you do best. Booking is made simply through an on demand model that attempts to get an expert to clients within the hour, and payment is smoothly managed through the app. All creating one seamless, flexible, and easy experience.";
        
        
        CGSize _textSize =  [_textString  sizeWithFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:13.0] constrainedToSize:CGSizeMake(_scrollView.frame.size.width-38.0, CGFLOAT_MAX) lineBreakMode:NSLineBreakByWordWrapping];
        
        _frame=CGRectMake(19.0, _frame.origin.y+_frame.size.height+20.0, _scrollView.frame.size.width-38.0, _textSize.height+100);
        
        UILabel *_textLabel=[ccManager() labelWithAttributes:nil frame:_frame];
        _attributes=@{
                      kASTextColor: COLOR_THEME_BROWN,
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:13.0],
                      kASText:_textString,
                      kASCharacterSpace:[NSNumber numberWithFloat:0.26],
                      kASLineSpace:[NSNumber numberWithFloat:1.0]
                      };
        _textLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
        _textLabel.numberOfLines=1000;
        [_scrollView addSubview:_textLabel];
        
        
        _scrollView.contentSize=CGSizeMake(_scrollView.frame.size.width, _frame.size.height+_frame.origin.y+20.0);
        
    }
}

@end
