//
//  LAAppDelegate.h
//  Luxit-Partners
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

typedef enum
{
    ASBackground,
    ASForeground
}AppStatus;

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

#import "GAI.h"
#import "UserInfo.h"
#import "JobDetail.h"
#import "GAIFields.h"
#import "GAIDictionaryBuilder.h"

@interface LAAppDelegate : UIResponder <UIApplicationDelegate,CLLocationManagerDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UserInfo *userInfo;
@property (strong, nonatomic) JobDetail *jobDetail;
@property (strong, nonatomic) UINavigationController *navigationController;
@property (strong, nonatomic) CLLocationManager *locationManager;
@property (assign, nonatomic) int locationServiceStatus;
@property (assign, nonatomic) BOOL okToWait;
@property (assign, nonatomic) BOOL locationEnabled;

@property (nonatomic, copy) void (^dispatchHandler)(GAIDispatchResult result);
@property (nonatomic, copy) void (^receiveRemoteNotification)(NSDictionary *,BOOL);
@property (nonatomic, copy) void (^updateAppStatus)(AppStatus);
@property (nonatomic, copy) void (^updateLocationAuthorization)(BOOL);
@property(nonatomic, strong) id<GAITracker> tracker;

- (void)enableLocationService;
- (void)disableLocationService;

- (void)showSplashViewController;
- (void)showLoginViewController;
- (void)showUserHomeViewControllerWithAnimation:(BOOL)animation;
- (void)enablePushNotification;
- (void)validateRemoteNotification;

@end

LAAppDelegate *appDelegate(void);

