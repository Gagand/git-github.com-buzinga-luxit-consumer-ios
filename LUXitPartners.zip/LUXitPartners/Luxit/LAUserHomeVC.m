//
//  LAUserHomeVC.m
//  Luxit-Partners
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "LAUserHomeVC.h"
#import "LAUserHomeVC.h"
#import "LAParentViewController.h"

#define kAnimationName @"slideAnimation"

@implementation LAUserHomeVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
//    fetchValidJobsWithAttributes
//    
//    [API() fetchValidJobsWithAttributes:@{
//                                          @"userId":@1652
//                                          
//                                          } completion:nil];

    _ratingStarImageviewsArray=[[NSMutableArray alloc]init];
    
    appDelegate().jobDetail.changed=YES;
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    NSDictionary *_attributes=nil;
    _attributes=@{
                  kCCImage:[UIImage imageNamed:@"Header_Logo.png"],
                  kCCContentMode:[NSNumber numberWithInt:UIViewContentModeCenter]
                  };
   
    self.navigationItem.titleView=[ccManager() imageViewWithAttributes:_attributes frame:CGRectMake(0.0, 0.0, 120.0, 55.0)];
    
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"Menu.png"] style:UIBarButtonItemStylePlain target:self action:@selector(menuButtonAction)];
    
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_tableView==nil)
    {
        _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0.0, 0.0, self.view.frame.size.width, self.view.frame.size.height-50.0) style:UITableViewStylePlain];
        _tableView.delegate=self;
        _tableView.dataSource=self;
        _tableView.backgroundColor=[UIColor clearColor];
        _tableView.separatorColor=[UIColor clearColor];
        [self.view addSubview:_tableView];
        
        NSDictionary *_attributes=nil;
       
        CGRect _frame;

        _frame=CGRectMake(0.0, self.view.frame.size.height-43.5, self.view.frame.size.width, 43.5);
        _attributes=@{
                      kCCBackgroundColor:COLOR_THEME_DARKGRAY
                      };
        _statusButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
            [self statusButtonAction];
        }];
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:1.35],
                      kASTextColor:COLOR_THEME_BROWN,
                      kASText:@"START LUXING",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0]
                      };
        [_statusButton setAttributedTitle:[NSMutableAttributedString attributedStringWithAttributes:_attributes] forState:UIControlStateNormal];
        [self.view addSubview:_statusButton];

        [self checkAndUpdateLuxingButtonStatus];
      
        [self fetchAndGetLastUpdatedJobStatus];

        _isViewVisible=YES;
        _isTimerViewVisible=NO;
        _isCancellationPopoverVisible=NO;

        
        __block typeof(self) _weakSelf=self;
        
        self.menuContainerViewController.finishedUpdatingView=^()
        {
            [_weakSelf updateViewAccordingToTheLastJobStatus];
        };
        
        
        if (appDelegate().locationServiceStatus==0)
        {
            [self showLocationAlert1];
        }
        else
        {
            if ([[UIApplication sharedApplication]currentUserNotificationSettings].types==UIUserNotificationTypeNone)
            {
                [appDelegate() validateRemoteNotification];
            }
        }
    }
     _isViewVisible=YES;

    appDelegate().updateAppStatus=^(AppStatus status){
        if (status==ASForeground)
        {
             [self getUserInfo];
            
            if (appDelegate().locationServiceStatus!=0)
                [appDelegate() enablePushNotification];
        }
    };
    
    apnManager().updateViewOnReceptionOfRemoteNotification=^(BOOL new,NSDictionary *data,BOOL changed)
    {
        if (new)
        {
            [self showJobAcceptViewControllerWithJobInfo:[[Job alloc]initWithAttributes:data]];
        }
        else
        {
            if (changed)
            {
                [self getUserInfo];
            }
            else
            {
                [self updateViewAccordingToTheLastJobStatus];
            }
        }
    };
   
}


- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    _isViewVisible=NO;
}


#pragma mark------------------------------------------------------------
#pragma mark VIEW OPERATIONS
#pragma mark------------------------------------------------------------

- (void)showJobAcceptViewControllerWithJobInfo:(Job *)job
{
    if (_isCancellationPopoverVisible)
    {
        return;
    }
    
    if (_isTimerViewVisible)
    {
        return;
    }
    
    if (!_isClockingON)
    {
        return;
    }
    
    if (appDelegate().jobDetail.status!=JSNoJob)
    {
        return;
    }

    if([self isJobValid:job])
    {
        [self showAcceptJobPopoverWithJobInfo:job];
    }
    else
    {
        [ccManager() showAlertWithTitle:@"Sorry" message:@"The job has been expired." buttons:nil completion:nil];
    }
}


- (BOOL)isJobValid:(Job *)job
{
    NSDateFormatter *_dateFormatter = [[NSDateFormatter alloc] init];
    [_dateFormatter setDateFormat:SERVER_TIMEFORMAT];
    NSDate *_currentTiming = [_dateFormatter dateFromString:[_dateFormatter stringFromDate:[NSDate date]]];

    NSTimeZone *_standardTimeZone = [NSTimeZone timeZoneWithName:SERVER_TIMEZONE];
    [_dateFormatter setTimeZone:_standardTimeZone];
    [_dateFormatter setDateFormat:SERVER_TIMEFORMAT];
    NSDate *_jobTiming = [_dateFormatter dateFromString:job.notificationDateString];
   
    NSTimeInterval _difference = [_currentTiming timeIntervalSinceDate:_jobTiming];
    
    
    NSLog(@"kidddaaaa bft--- > %f",_difference);

    _difference =  fabs(_difference) - 42;
    
    NSLog(@"kidddaaaa --- > %f",_difference);
    
    if(_difference<0)
        _difference =  fabs(_difference) ;
   
    if (_difference > 30.0)
    {
        return NO;
    }
    
    
    _timeDifference=(int)(30.0 -_difference);
   
    
    return YES;
}


- (void)showAcceptJobPopoverWithJobInfo:(Job *)job{
    
    if (_timeDifference>30){
        _timeDifference=30;
    }
    _jobCount=[[[NSUserDefaults standardUserDefaults]objectForKey:@"jobCount"]intValue];
    _jobCount++;
    [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%i",_jobCount] forKey:@"jobCount"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    
    NSLog(@"gjklsrejkllkbjdlkbjhgjg__------_%i",_jobCount);

    
    [self.menuContainerViewController disablePan];
    _isTimerViewVisible=YES;
    _acceptVC=[[LAAcceptJobVC alloc]init];
    _acceptVC.timeCount=_timeDifference;
    _acceptVC.job=job;
    __block typeof(self) _weakSelf         =self;
    _acceptVC.finishedAcceptingJob=^(){
        _jobCount=0;
        [[NSUserDefaults standardUserDefaults]setObject:@"0" forKey:@"jobCount"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        _isTimerViewVisible=NO;
        [_weakSelf performSelector:@selector(updateView) withObject:nil afterDelay:0.1];
        [_weakSelf.menuContainerViewController enablePan];
    };
    _acceptVC.finishedCancellingJob=^(BOOL resetParameter){
        [_weakSelf.menuContainerViewController enablePan];
        if (resetParameter){
            _jobCount=0;
            [[NSUserDefaults standardUserDefaults]setObject:@"0" forKey:@"jobCount"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            _isTimerViewVisible=NO;
            return;
        }
        
        
        if (_jobCount>=3){
            _isTimerViewVisible=NO;
            _jobCount=0;
            [[NSUserDefaults standardUserDefaults]setObject:@"0" forKey:@"jobCount"];
            [[NSUserDefaults standardUserDefaults]setBool:NO forKey:@"isLuxingEnabale"];
            [[NSUserDefaults standardUserDefaults] synchronize];
            NSDictionary *_attributes=nil;
            _attributes=@{
                          @"userId": appDelegate().userInfo.userId,
                          @"availability":@"1"
                          };
            [progressHud() showWithTitle:@"Please wait"];
            [API() changeAvailablityWithAttributes:_attributes completion:^(BOOL var, NSError * error) {
                [progressHud() hide];

            }];
            [_weakSelf checkAndUpdateLuxingButtonStatus];
            [ccManager() showAlertWithTitle:@"Stop LUXing" message:@"You haven't accepted three bookings in a row so we think that you might not be available to work anymore. If this isn't the case, Start LUXing again!" buttons:@[@"Close",@"Start LUXing"] completion:^(NSInteger buttonIndex){
                if (buttonIndex==1){
                    [_weakSelf statusButtonAction];
                }
            }];
        }
        else{
            [_weakSelf getUserInfo];
            _isTimerViewVisible=NO;
        }
    };
    _acceptVC.view.backgroundColor = [UIColor clearColor];
    _acceptVC.providesPresentationContextTransitionStyle = YES;
    [_acceptVC setModalPresentationStyle:UIModalPresentationOverCurrentContext];
    [self.navigationController presentViewController:_acceptVC animated:NO completion:nil];
}

-(void) methodCallOnExceeding3job{
    _jobCount=[[[NSUserDefaults standardUserDefaults]objectForKey:@"jobCount"]intValue];
    if (_jobCount < 3)
        return;
    if (![[NSUserDefaults standardUserDefaults] boolForKey:@"isLuxingEnabale"] || _isTimerViewVisible) {
        return;
    }
    [self checkAndUpdateLuxingButtonStatus];
}


- (void)getUserInfo
{
    [API() getprofileDetailWithCompletion:^(BOOL success, BOOL availablity)
    {
        if (success)
        {
            int i=0;
           
            for (UIImageView *_starImageView in _ratingStarImageviewsArray)
            {
                if (i>=appDelegate().userInfo.rating)
                {
                    _starImageView.image=[UIImage imageNamed:@"Star_No_Fill.png"];
                }
                else
                {
                     _starImageView.image=[UIImage imageNamed:@"Star_Fill.png"];
                }
                i++;
            }
            
            
            if (_isViewVisible)
            {
                if (([[NSUserDefaults standardUserDefaults]boolForKey:@"isLuxingEnabale"]) && appDelegate().jobDetail.status==JSNoJob && !availablity)
                {
                    
                    [_acceptVC dismissViewControllerAnimated:NO completion:nil];
                    
                    [[NSUserDefaults standardUserDefaults]setBool:NO forKey:@"isLuxingEnabale"];
                    [[NSUserDefaults standardUserDefaults]synchronize];
                    
                    [self checkAndUpdateLuxingButtonStatus];
                    
                    [ccManager() showAlertWithTitle:@"Stop LUXing" message:@"You haven't accepted three bookings in a row so we think that you might not be available to work anymore. If this isn't the case, Start LUXing again!" buttons:@[@"Close",@"Start LUXing"] completion:^(NSInteger buttonIndex){
                        if (buttonIndex==1)
                        {
                            [self statusButtonAction];
                        }
                    }];
                }
            }
        }
    }];
}


- (void)showLocationAlert1
{
    appDelegate().updateLocationAuthorization=^(BOOL authorize)
    {
        if (!authorize)
        {
            [self showLocationAlert2];
        }
        else
        {
            [appDelegate() enablePushNotification];
        }
    };
    [appDelegate().locationManager requestAlwaysAuthorization];
    [appDelegate() enableLocationService];
}


- (void)showLocationAlert2
{
    _isCancellationPopoverVisible=YES;
    
    NSArray *_buttonsArray=@[@"Close",@"Go to Settings"];
    
    [ccManager() showAlertWithTitle:@"Change your Settings to allow LUXit Partners to Access to Your Current Location" message:@"We need to know your current location to provide you with bookings around you wherever you are. Please go to the App Settings, tap on Location and then select Always." buttons:_buttonsArray completion:^(NSInteger buttonIndex)
    {
        _isCancellationPopoverVisible=NO;
        if ([[_buttonsArray objectAtIndex:buttonIndex]isEqualToString:@"Go to Settings"])
        {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
        }
        else
        {
            [appDelegate() enablePushNotification];
        }
    }];
}


- (void)fetchAndGetLastUpdatedJobStatus
{
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"LastJobDetail"]!=NULL)
    {
          _isJobStatusFeteched=YES;
        
        [appDelegate().jobDetail updateWithAttributes:[[NSUserDefaults standardUserDefaults]objectForKey:@"LastJobDetail"]];
        
        [self updateViewAccordingToTheLastJobStatus];
    }
    else
    {
          _isJobStatusFeteched=NO;
        
        [progressHud() showWithTitle:@"Please wait"];
    }
    
    
    NSDictionary *_attributes=@{
                                @"userId":appDelegate().userInfo.userId
                               };
    
    [API() fetchLastCreatedJobStatusWithAttributes:_attributes completion:^(BOOL success, NSError *error)
     {
         if (success)
         {
             [progressHud() hide];

             [appDelegate().jobDetail updateWithAttributes:[[NSUserDefaults standardUserDefaults]objectForKey:@"LastJobDetail"]];
             
             [self updateViewAccordingToTheLastJobStatus];
         }
         else
         {
             if (!_isJobStatusFeteched)
             {
                 [progressHud() hide];
                 
                 [ccManager() showAlertWithTitle:@"Error" message:@"Fail to fetch data. Please retry to fetch again" buttons:@[@"Retry"] completion:^(NSInteger buttonIndex)
                  {
                      [progressHud() showWithTitle:@"Please wait"];
                      
                      [self fetchAndGetLastUpdatedJobStatus];
                  }];
             }
             else
             {
                [progressHud() hide];
             }
         }
     }];
}


- (void)checkAndUpdateLuxingButtonStatus
{
    if ([[NSUserDefaults standardUserDefaults]boolForKey:@"isLuxingEnabale"])
    {
        _jobCount=[[[NSUserDefaults standardUserDefaults]objectForKey:@"jobCount"]intValue];
        if (_jobCount>=3)
        {
            _jobCount=0;
            _isClockingON=NO;
            [[NSUserDefaults standardUserDefaults]setBool:NO forKey:@"isLuxingEnabale"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            NSDictionary *_attributes=nil;
            _attributes=@{
                          @"userId": appDelegate().userInfo.userId,
                          @"availability":@"1"
                          };
            [progressHud() showWithTitle:@"Please wait"];
            
            [API() changeAvailablityWithAttributes:_attributes completion:^(BOOL var, NSError * varr) {
                [[NSUserDefaults standardUserDefaults]setObject:@"0" forKey:@"jobCount"];
                [[NSUserDefaults standardUserDefaults]synchronize];
                [progressHud() hide];
            }];
            [self checkAndUpdateLuxingButtonStatus];
            [ccManager() showAlertWithTitle:@"Stop LUXing" message:@"You haven't accepted three bookings in a row so we think that you might not be available to work anymore. If this isn't the case, Start LUXing again!" buttons:@[@"Close",@"Start LUXing"] completion:^(NSInteger buttonIndex)
            {
                if (buttonIndex==1)
                {
                    [self statusButtonAction];
                }
            }];
            return;
        }
        _isCancellationPopoverVisible=NO;
        _isTimerViewVisible=NO;
        _isClockingON=YES;
        NSDictionary *_attributes;
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:1.35],
                      kASTextColor:[UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                      kASText:@"STOP LUXING",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0]
                      };
        [_statusButton setAttributedTitle:[NSMutableAttributedString attributedStringWithAttributes:_attributes] forState:UIControlStateNormal];
        _statusButton.backgroundColor=COLOR_THEME_BROWN;
        _statusButton.selected=YES;
        _isClockingON=YES;
        [_tableView reloadData];
        [_maskLayer addAnimation:_maskAnimation forKey:kAnimationName];
        [appDelegate() enablePushNotification];
    }
    else
    {
        _jobCount=0;
        [[NSUserDefaults standardUserDefaults]setObject:@"0" forKey:@"jobCount"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        _isClockingON=NO;
        NSDictionary *_attributes;
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:1.35],
                      kASTextColor:COLOR_THEME_BROWN,
                      kASText:@"START LUXING",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0]
                      };
        _statusButton.backgroundColor=COLOR_THEME_DARKGRAY;
        [_statusButton setAttributedTitle:[NSMutableAttributedString attributedStringWithAttributes:_attributes] forState:UIControlStateNormal];
        _statusButton.selected=NO;
        _isClockingON=NO;
        [_tableView reloadData];
        [_maskLayer removeAnimationForKey:kAnimationName];
        [[UIApplication sharedApplication] unregisterForRemoteNotifications];
    }
}


#pragma mark------------------------------------------------------------
#pragma mark TABLEVIEW DELEGATE/DATASOURCE
#pragma mark------------------------------------------------------------

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0)
    {
        return tableView.frame.size.height-70;
    }
    else if (indexPath.row==1)
    {
        if(_isClockingON)
            return 0.0;
        else
            return 70.0;
    }
    else
    {
        if(_isClockingON)
            return 70.0;
        else
            return 0.0;
    }
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=[NSString stringWithFormat:@"Cell_%i",(int)indexPath.row];
    
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
    
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        _cell.clipsToBounds=YES;
        
        if (indexPath.row==0)
        {
            CGFloat _height=[self tableView:tableView heightForRowAtIndexPath:indexPath];
            
            CGRect _frame=CGRectMake(_tableView.frame.size.width/2-66.0, _height/2-120.0, 132.0, 132.0);
            
            NSDictionary *_attributes=nil;
            _attributes=@{
                          kCCCornerRadius:[NSNumber numberWithFloat:_frame.size.width/2.0],
                          kCCImage:[UIImage imageNamed:@"Loading_Image.png"]
                          };
            
            _profileImageView=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
            [_cell.contentView addSubview:_profileImageView];
           
            [self getAndSetprofileImageForTechnician];
            
            _frame=CGRectMake(10.0, _frame.origin.y+_frame.size.height+8.5, _tableView.frame.size.width-20.0, 17.0);
           
            UILabel *_techinicianNameLabel=[ccManager() labelWithAttributes:nil frame:_frame];
          
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:4.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:[appDelegate().userInfo.firstName uppercaseString],
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:16.0]
                          };
           
            _techinicianNameLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            
            [_cell.contentView addSubview:_techinicianNameLabel];
            
            [_ratingStarImageviewsArray removeAllObjects];
            
            CGFloat _yOffset=_frame.origin.y+_frame.size.height+11.5;
            
            CGFloat _xOffset=tableView.frame.size.width/2-(15*5)/2;
            
            for (int i=0; i<5; i++)
            {
                if (i>=appDelegate().userInfo.rating)
                {
                    _attributes =@{
                                   kCCImage:[UIImage imageNamed:@"Star_No_Fill.png"]
                                   };
                }
                else
                {
                    _attributes =@{
                                   kCCImage:[UIImage imageNamed:@"Star_Fill.png"]
                                   };
                }
                _frame=CGRectMake(_xOffset, _yOffset, 13.0, 13.0);
              
                UIImageView *_starImageView=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
                [_cell.contentView addSubview:_starImageView];
               
                _xOffset+=15.0;
                
                [_ratingStarImageviewsArray addObject:_starImageView];
            }
                
            _frame=CGRectMake(10.0, _yOffset+13.0+11.5, _tableView.frame.size.width-20.0, 20.0);
            
            UILabel *_techinicianPhoneNumberLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.48/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:appDelegate().userInfo.mobile,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0]
                          };
            NSMutableAttributedString *_mobileNumberAttributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            
            _techinicianPhoneNumberLabel.attributedText=_mobileNumberAttributedString;
            
            [_cell.contentView addSubview:_techinicianPhoneNumberLabel];
            
        }
        
        else if (indexPath.row==1)
        {
            NSDictionary *_attributes=nil;
            _attributes=@{
                          kASText: @"Welcome to LUXit!\n\nLUXing will make you available for work in your current area. Start LUXing now!",
                          kASTextColor:COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0],
                          kASCharacterSpace:[NSNumber numberWithFloat:0.48/2.0]
                          };
            
            CGRect _frame=CGRectMake(10.0, 0.0, tableView.frame.size.width-20.0, 70.0);
           
            UILabel *_textLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _textLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_textLabel];

        }
        else{

           
            NSDictionary *_attributes=nil;
            _attributes=@{
                          kASText: @"Searching for bookings in and around your current location.",
                          kASTextColor:COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0],
                          kASCharacterSpace:[NSNumber numberWithFloat:0.48/2.0]
                          };
           
            CGRect _frame=CGRectMake(10.0, 0.0, tableView.frame.size.width-20.0, 60.0);
           
            UILabel *_textLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _textLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_textLabel];
            
            NSArray *_colors=@[COLOR_THEME_BROWN,COLOR_THEME_LIGHTPINK];
            _frame=CGRectMake(10.0, 60.0, tableView.frame.size.width-20.0, 1.5);
            
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_customLayer];
            
            _maskLayer = [CALayer layer];

            _maskLayer.backgroundColor = [[UIColor colorWithRed:0.0f green:0.0f blue:0.0f alpha:0.75f] CGColor];
            _maskLayer.contents = (id)[[UIImage imageNamed:@"Mask.png"] CGImage];

            _maskLayer.contentsGravity = kCAGravityCenter;
            _maskLayer.frame = CGRectMake(-_frame.size.width, 0.0f, _frame.size.width * 2, 1.5);
            
           _maskAnimation = [CABasicAnimation animationWithKeyPath:@"position.x"];
            _maskAnimation.byValue = [NSNumber numberWithFloat:_frame.size.width];
            _maskAnimation.repeatCount = HUGE_VALF;
            _maskAnimation.duration = 1.0f;
           [_maskLayer addAnimation:_maskAnimation forKey:kAnimationName];
            
            _customLayer.layer.mask = _maskLayer;
        }
    }
    
    return _cell;
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONS
#pragma mark------------------------------------------------------------

- (void)statusButtonAction
{
    if (_statusButton.selected)
    {
        _isCancellationPopoverVisible=YES;
       
        [ccManager() showAlertWithTitle:@"Do you wish to\nstop LUXing?" message:@"" buttons:@[@"Cancel",@"Stop"] completion:^(NSInteger index){
            if (index==1)
            {
                _isCancellationPopoverVisible=NO;
                
                NSDictionary *_attributes=nil;
                _attributes=@{
                              @"userId": appDelegate().userInfo.userId,
                              @"availability":@"1"
                              };
                

                [progressHud() showWithTitle:@"Please wait"];
                
                [API() changeAvailablityWithAttributes:_attributes completion:^(BOOL var, NSError * varr) {
                    [progressHud() hide];
                    
                }];
                [[NSUserDefaults standardUserDefaults]setBool:NO forKey:@"isLuxingEnabale"];
                [[NSUserDefaults standardUserDefaults]synchronize];
                
                [self checkAndUpdateLuxingButtonStatus];
            }
            else
            {
                _isCancellationPopoverVisible=NO;
            }
        }];
    }
    else
    {
        if (![CLLocationManager locationServicesEnabled])
        {
            [self showLocationAlert2];
        }
        else
        {
            if (appDelegate().locationServiceStatus==2)
            {
                [self showLocationAlert2];
            }
            else
            {
                NSDictionary *_attributes=nil;
                _attributes=@{
                              @"userId": appDelegate().userInfo.userId,
                              @"availability":@"0"
                              };
                
                [progressHud() showWithTitle:@"Please wait"];

                [API() changeAvailablityWithAttributes:_attributes completion:^(BOOL var, NSError * varr) {
                    [progressHud() hide];

                }];
                
                [[NSUserDefaults standardUserDefaults]setBool:YES forKey:@"isLuxingEnabale"];
                [[NSUserDefaults standardUserDefaults]synchronize];
                
                [self checkAndUpdateLuxingButtonStatus];
            }
        }
    }
}


- (void)menuButtonAction
{
    [self.menuContainerViewController openSideMenu];
}


- (void)updateView
{
    [self updateViewAccordingToTheLastJobStatus];
}


- (void)resetLuxitClock
{
    _isClockingON=NO;
   
    NSDictionary *_attributes=nil;
    _attributes=@{
                  @"userId": appDelegate().userInfo.userId,
                  @"availability":@"0"
                  };
    [progressHud() showWithTitle:@"Please wait"];
    
    [API() changeAvailablityWithAttributes:_attributes completion:^(BOOL var, NSError * varr) {
        [progressHud() hide];
    }];
    [[NSUserDefaults standardUserDefaults]setBool:NO forKey:@"isLuxingEnabale"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [self checkAndUpdateLuxingButtonStatus];
}


- (void)getAndSetprofileImageForTechnician
{
    _profileImageView.contentMode=UIViewContentModeScaleAspectFill;
    if (appDelegate().userInfo.imagePath.length==0)
    {
        _profileImageView.image=[UIImage imageNamed:@"Loading_Image.png"];
        return;
    }
    NSString *_imagePath=[NSString stringWithFormat:IMAGEURL,appDelegate().userInfo.imagePath];
 
    NSString *_documentImageFileName=_imagePath;
    _documentImageFileName = [_documentImageFileName stringByReplacingOccurrencesOfString:@".jpg" withString:@""];
    _documentImageFileName = [_documentImageFileName stringByReplacingOccurrencesOfString:@".png" withString:@""];
    
    NSArray *_componentsArray=[_documentImageFileName componentsSeparatedByString:@"/"];
    if (_componentsArray.count>0)
        _documentImageFileName=[_componentsArray lastObject];
    
    
    UIImage *_image=[UIImage imageWithContentsOfFile:[[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:[NSString stringWithFormat:@"Images/%@.png",_documentImageFileName]]];
    
    if (_image)
    {
        _profileImageView.image=_image;
    }
    else
    {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^(void)
        {
            NSData *_imgData = [NSData dataWithContentsOfURL:[NSURL URLWithString:_imagePath]];
            
            UIImage *__image = [UIImage imageWithData:_imgData];
            
            NSString *_fileName=[[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:[NSString stringWithFormat:@"Images/%@.png",_documentImageFileName]];
            
            [_imgData writeToFile:_fileName atomically:YES];
            
            dispatch_sync(dispatch_get_main_queue(), ^(void)
            {
                if (__image!=nil)
                {
                    _profileImageView.image=__image;
                }
            });
        });
    }
}


- (void)updateViewAccordingToTheLastJobStatus
{
    JobStatus _jobStatus=appDelegate().jobDetail.status;
    
    if (!appDelegate().jobDetail.changed)
    {
        return;
    }

    appDelegate().jobDetail.changed=NO;
    
    if (_jobStatus==JSNoJob)
    {
        [self getUserInfo];
        [self.navigationController popToRootViewControllerAnimated:NO];
    }
    else if (_jobStatus==JSPending||_jobStatus==JSStarted)
    {
        LAJobDetailVC *_jobDetailVC=[[LAJobDetailVC alloc]init];
        [self.navigationController pushViewController:_jobDetailVC animated:NO];
    }
    else if (_jobStatus==JSCompleted)
    {
        LAReceiptVC *_completionReceiptVC=[[LAReceiptVC alloc]init];
        [self.navigationController pushViewController:_completionReceiptVC animated:NO];
    }
    else if (_jobStatus==JSNeedFeedback)
    {
        LAFeedbackVC *_feedbackVC=[[LAFeedbackVC alloc]init];
        [self.navigationController pushViewController:_feedbackVC animated:NO];
    }
    
    [UIView transitionWithView:appDelegate().window duration:0.25 options:UIViewAnimationOptionTransitionCrossDissolve animations:nil completion:nil];
}
@end
