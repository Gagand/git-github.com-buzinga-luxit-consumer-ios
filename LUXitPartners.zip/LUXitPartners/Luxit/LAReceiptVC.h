//
//  LAReceiptVC.h
//  Luxit-Partners
//
//  Created by GP on 03/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LAFeedbackVC.h"
#import "LAUserHomeVC.h"

@interface LAReceiptVC : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    UITableView             *_tableView;
}

@end
