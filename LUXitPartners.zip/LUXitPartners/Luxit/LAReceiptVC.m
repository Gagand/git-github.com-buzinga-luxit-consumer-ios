//
//  LAReceiptVC.m
//  Luxit-Partners
//
//  Created by GP on 03/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "LAReceiptVC.h"
#import "LAUserHomeVC.h"
#import "LAParentViewController.h"

@implementation LAReceiptVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    self.navigationItem.hidesBackButton=YES;
    
    
    CGRect _frame=CGRectMake(0.0, 15.0, 190, 50.0);
    NSDictionary *_attributes;
    _attributes=@{
                  kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                  };
    UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
    
    
    _attributes=@{
                  kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                  kASTextColor:COLOR_THEME_BROWN,
                  kASText:@"RECEIPT",
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                  };
    [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
    
    self.navigationItem.titleView=_headerLabel;
    
    
    [self.menuContainerViewController disablePan];
    
    _attributes=@{
                  kCCBackgroundColor: [UIColor colorWithWhite:0.0 alpha:0.2]
                  };
    
    _frame=CGRectMake(0.0, 0.0, self.view.frame.size.width, 0.5);
    
    [self.view addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];
 
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_tableView==nil)
    {
        // DIVIDER (BELOW HEADER)
        NSDictionary *_attributes=nil;
        CGRect _frame;
        _frame=CGRectMake(0.0, 0.0,self.view.frame.size.width , 1.0);
        _attributes=@{
                      kCCImage:[UIImage imageNamed:@"seprator.png"]
                      };
        UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
        [self.view addSubview:_divider];
        
        _tableView=[[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.delegate=self;
        _tableView.dataSource=self;
        _tableView.showsVerticalScrollIndicator=NO;
        _tableView.backgroundColor=[UIColor clearColor];
        _tableView.separatorColor=[UIColor clearColor];
        [self.view addSubview:_tableView];
    }
}


#pragma mark------------------------------------------------------------
#pragma mark TABLEVIEW DELEGATE/ DATASOURCE
#pragma mark------------------------------------------------------------

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0)
    {
        return 87.50;
    }
    else if (indexPath.row==1)
    {
        return 264.0;
    }
    else if (indexPath.row==2)
    {
        return 35.0;
    }
    else if (indexPath.row==3)
    {
        return 54.0;
    }
    else
    {
        return 44.0;
    }
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=[NSString stringWithFormat:@"Cell_%i",(int)indexPath.row];
    
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
    
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        if (indexPath.row==0)
        {
            NSDictionary *_attributes=nil;
            
            CGRect _frame=CGRectMake(10.0, 13.5, tableView.frame.size.width-20, 15.0);
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0],
                          kASText:[appDelegate().jobDetail.itemName uppercaseString],
                          kASCharacterSpace:[NSNumber numberWithFloat:3.5]
                          };
            UILabel *_itemNameLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _itemNameLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_itemNameLabel];
            
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_LIGHTPINK
                      ];
            
            _frame=CGRectMake(tableView.frame.size.width/2-12.0, _frame.origin.y+_frame.size.height+14.5, 24.0, 0.5);
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            _customLayer.alpha=0.8;
            [_cell.contentView addSubview:_customLayer];
            
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"Booking Details",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:13.0]
                          };
            _frame=CGRectMake(10.0, _frame.origin.y+_frame.size.height+15.0, tableView.frame.size.width-20, 14.0);
            UILabel *_staticCancellationLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticCancellationLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_staticCancellationLabel];
            
        }
        
        else if (indexPath.row==1)
        {
            int numberOfRows=6;
            
            NSDictionary *_attributes=nil;
            
            CGRect _frame=CGRectMake(8.0, 0.0, tableView.frame.size.width-16.0, 264.0);
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_BROWN
                      ];
            
            CustomLayer*_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMVertical];
            [_cell.contentView addSubview:_customLayer];
            
            
            _attributes=@{
                          kCCBackgroundColor: [UIColor whiteColor]
                          };
            
            _frame=CGRectMake(_frame.origin.x+0.5, _frame.origin.y+0.5,_frame.size.width-1.0, _frame.size.height-1.0);
           
            UIView *_containerView=[ccManager() viewWithAttributes:_attributes frame:_frame];
            [_cell.contentView addSubview:_containerView];
            
            
            [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, _containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.6)]];
            
            [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, 2*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.5)]];
            
            [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, 3*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.6)]];
            
             [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, 4*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.6)]];
            
             [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, 5*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.5)]];
            
            
            _frame=CGRectMake(16.0, 0.0, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"TYPE",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticTypeLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTypeLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticTypeLabel];
            
            
            
            _attributes=@{
                          kCCText: appDelegate().jobDetail.itemName,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            
            _frame=CGRectMake(16.0, _containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"PAY",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticPayLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticPayLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticPayLabel];
            
            _attributes=@{
                          kCCText: [NSString stringWithFormat:@"$%i",(int)appDelegate().jobDetail.technicianFee],
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            
            _frame=CGRectMake(16.0, 2*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"DATE",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticDateLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticDateLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticDateLabel];
            
            _attributes=@{
                          kCCText: appDelegate().jobDetail.dateString,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            
            _frame=CGRectMake(16.0, 3*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"TIME",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticTimeLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTimeLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticTimeLabel];
            
            _attributes=@{
                          kCCText: appDelegate().jobDetail.timeString,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            _frame=CGRectMake(16.0, 4*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"CUSTOMER",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticCutomerLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticCutomerLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticCutomerLabel];
            
            _attributes=@{
                          kCCText:appDelegate().jobDetail.consumer.firstName,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            _frame=CGRectMake(16.0, 5*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"ADDRESS",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticAddressLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticAddressLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticAddressLabel];
            
             _frame=CGRectMake(90.0, 5*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-105.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kCCText: appDelegate().jobDetail.location,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
        }
        
        else if (indexPath.row==2)
        {
            NSDictionary *_attributes;
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.52/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"Rate your customer to continue",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:13.0]
                          };
            CGRect _frame=CGRectMake(0.0, 0.0, tableView.frame.size.width, 35.0);
            UILabel *_staticAddressLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticAddressLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_staticAddressLabel];

            
        }
        else if (indexPath.row==3)
        {
            NSDictionary *_attributes=nil;
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_BROWN,
                      COLOR_THEME_LIGHTPINK
                      ];
            CGRect _frame=CGRectMake(16.0, 0.0, self.view.frame.size.width-32.0, 44.0);
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_customLayer];
            
            
            _frame=CGRectMake(_frame.origin.x+1.5, _frame.origin.y+1.5, _frame.size.width-3.0, _frame.size.height-3.0);
            
            _attributes=@{
                          kCCBackgroundColor:COLOR_THEME_DARKGRAY
                          };
            UIButton *_sendButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender)
            {
                [self positiveFeedbackButtonAction];
            }];
            
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0],
                          kASText:@"POSITIVE",
                          kASCharacterSpace:[NSNumber numberWithFloat:1.35]
                          };
            
            NSMutableAttributedString *_attributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_sendButton setAttributedTitle:_attributedString forState:UIControlStateNormal];
            [_cell.contentView addSubview:_sendButton];

        }
        else if (indexPath.row==4)
        {
            NSDictionary *_attributes=nil;
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_BROWN,
                      COLOR_THEME_LIGHTPINK
                      ];
            CGRect _frame=CGRectMake(16.0, 0.0, self.view.frame.size.width-32.0, 44.0);
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_customLayer];
            
            
            _frame=CGRectMake(_frame.origin.x+1.5, _frame.origin.y+1.5, _frame.size.width-3.0, _frame.size.height-3.0);
            
            _attributes=@{
                          kCCBackgroundColor:COLOR_THEME_DARKGRAY
                          };
            UIButton *_sendButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
                [self negativeFeedbackButtonAction];
            }];
            
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0],
                          kASText:@"NEGATIVE",
                          kASCharacterSpace:[NSNumber numberWithFloat:1.35]
                          };
            
            NSMutableAttributedString *_attributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_sendButton setAttributedTitle:_attributedString forState:UIControlStateNormal];
            [_cell.contentView addSubview:_sendButton];
            
        }
    }
    return _cell;
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONS
#pragma mark------------------------------------------------------------

- (void)submitButtonAction
{
    [self.navigationController popToRootViewControllerAnimated:NO];
    [UIView transitionWithView:appDelegate().window duration:0.20 options:UIViewAnimationOptionTransitionCrossDissolve animations:nil completion:nil];
}


- (void)negativeFeedbackButtonAction
{
    LAFeedbackVC *_feedbackVC=[[LAFeedbackVC alloc]init];
    [self.navigationController pushViewController:_feedbackVC animated:YES];
}

- (void)positiveFeedbackButtonAction
{
   
    [progressHud() showWithTitle:@"Please wait"];

    NSDictionary *_attributes=@{
                                @"userId":appDelegate().userInfo.userId,
                                @"status":@"1",
                                @"jobId":appDelegate().jobDetail.jobId,
                                @"comment":@""
                                };
    
    [API() sendFeedbackForJobWithAttributes:_attributes completion:^(BOOL success, NSError *error)
     {
         [progressHud() hide];
         
         if (success)
         {
             NSMutableDictionary *_jobDetail=[NSMutableDictionary dictionaryWithCapacity:0];
             [[NSUserDefaults standardUserDefaults]setObject:_jobDetail forKey:@"LastJobDetail"];
             [[NSUserDefaults standardUserDefaults]synchronize];
             
             [appDelegate().jobDetail updateWithAttributes:_jobDetail];
              appDelegate().jobDetail.changed=YES;
             
             if ([[NSUserDefaults standardUserDefaults]boolForKey:@"isLuxingEnabale"])
             {
                 [ccManager() showAlertWithTitle:@" Would you like to keep LUXing and find more work?" message:@"" buttons:@[@"No",@"Yes"] completion:^(NSInteger buttonIndex)
                 {
                     if (buttonIndex==0)
                     {
                         LAUserHomeVC *_userHomeVC=(LAUserHomeVC *)[self.navigationController.viewControllers objectAtIndex:0];
                         [_userHomeVC resetLuxitClock];
                     }
                     
                     [self.menuContainerViewController switchView];
                 }];
             }
             else
             {
                 [self.menuContainerViewController switchView];
             }
         }
         else
         {
             [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
             
         }
     }];

}
@end
