//
//  LAMapVC.h
//  Luxit-Partners
//
//  Created by GP on 11/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>


@interface LAMapVC : UIViewController<MKMapViewDelegate>
{
     MKMapView       *_mapView;
}

@end
