//
//  LAJobDetailVC.m
//  Luxit-Partners
//
//  Created by GP on 03/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "LAUserHomeVC.h"
#import "LAJobDetailVC.h"
#import "LAParentViewController.h"

@implementation LAJobDetailVC

- (void)viewDidLoad
{
    [super viewDidLoad];
  
    _ratingStarImageviewsArray=[[NSMutableArray alloc]init];
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"Menu.png"] style:UIBarButtonItemStylePlain target:self action:@selector(menuButtonAction)];
    
    CGRect _frame=CGRectMake(0.0, 15.0, 190, 50.0);
    NSDictionary *_attributes;
    _attributes=@{
                  kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                  };
    UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
    
    _attributes=@{
                  kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                  kASTextColor:COLOR_THEME_BROWN,
                  kASText:@"BOOKING DETAILS",
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                  };
    [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
    
    self.navigationItem.titleView=_headerLabel;
    
    
    _attributes=@{
                  kASTextColor: COLOR_THEME_BROWN,
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0],
                  kASText:@"Cancel",
                  kASCharacterSpace:[NSNumber numberWithFloat:1.2],
                  kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                  };
    _frame=CGRectMake(0.0, 0.0, 80.0, 50.0);
   
    UIButton *_cancelButton=[ccManager() buttonWithAttributes:nil frame:_frame completion:^(UIButton *sender){
        [self cancelButtonAction];
    }];
    [_cancelButton setAttributedTitle:[NSMutableAttributedString attributedStringWithAttributes:_attributes] forState:UIControlStateNormal];
    
    UIBarButtonItem *_sendButtonItem=[[UIBarButtonItem alloc]initWithCustomView:_cancelButton];
   
    UIBarButtonItem *_leftSpaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    _leftSpaceItem.width = -24.0;
  
    self.navigationItem.rightBarButtonItems=[NSArray arrayWithObjects:_leftSpaceItem,_sendButtonItem, nil];
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    if (_tableView==nil)
    {
        CGRect _frame;
        
        // DIVIDER (BELOW HEADER)
        NSDictionary *_attributes=nil;
        _frame=CGRectMake(0.0, 0.0,self.view.frame.size.width , 1.0);
        _attributes=@{
                      kCCImage:[UIImage imageNamed:@"seprator.png"]
                      };
        UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
        [self.view addSubview:_divider];
        

        _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0.0, 0.0, self.view.frame.size.width, self.view.frame.size.height-43.5) style:UITableViewStylePlain];
        _tableView.delegate=self;
        _tableView.dataSource=self;
        _tableView.showsVerticalScrollIndicator=NO;
        _tableView.backgroundColor=[UIColor clearColor];
        _tableView.separatorColor=[UIColor clearColor];
        [self.view addSubview:_tableView];
        
        
        _frame=CGRectMake(0.0, self.view.frame.size.height-43.5, self.view.frame.size.width, 43.5);
       _statusButton=[ccManager() buttonWithAttributes:nil frame:_frame completion:^(UIButton *sender){
            [self statusButtonAction];
        }];
        [self.view addSubview:_statusButton];
        
        [self updateStatusButtonAttributes];
        _forcefullyReloadData=NO;
        
        if (appDelegate().jobDetail.consumer.firstName.length==0)
        {
            _forcefullyReloadData=YES;
            [progressHud() showWithTitle:@"Please wait"];
        }
        
        [progressHud() showWithTitle:@"Please wait"];
       [self performSelector:@selector(checkJobStatus) withObject:nil afterDelay:5.0];
    }
    else
    {
        [self checkJobStatus];
        [self performSelector:@selector(checkJobStatus) withObject:nil afterDelay:60.0];
    }
    
    appDelegate().updateAppStatus=^(AppStatus status){
        if (status==ASForeground)
        {
            [progressHud() showWithTitle:@"Please wait"];
            [self checkJobStatus];
        }
    };
}



- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(checkJobStatus) object:nil];
}


- (void)checkJobStatus
{
    NSDictionary *_attributes=@{
                                @"userId":appDelegate().userInfo.userId
                                };
    [API() fetchLastCreatedJobStatusWithAttributes:_attributes completion:^(BOOL success,NSError *error){
        [progressHud() hide];
        if (success)
        {
            if (_forcefullyReloadData)
            {
                appDelegate().jobDetail.changed=YES;
               
                [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(checkJobStatus) object:nil];
                [self.menuContainerViewController switchView];
               
                return ;
            }
            
            if (appDelegate().jobDetail.changed)
            {
                [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(checkJobStatus) object:nil];
                [self.menuContainerViewController switchView];
            }
            
            else
            {
                [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(checkJobStatus) object:nil];
                [self performSelector:@selector(checkJobStatus) withObject:nil afterDelay:60.0];
                [_tableView reloadData];
            }
        }
        else
        {
            [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(checkJobStatus) object:nil];
            [self performSelector:@selector(checkJobStatus) withObject:nil afterDelay:60.0];
            // [_tableView reloadData];
        }
        
    }];
}
#pragma mark------------------------------------------------------------
#pragma mark TABLEVIEW DELEGATE/ DATASOURCE
#pragma mark------------------------------------------------------------

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0)
    {
        return 320.0;
    }
    else
    {
        return 240.0;
    }
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=[NSString stringWithFormat:@"Cell_%i",(int)indexPath.row];
    
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
    
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        if (indexPath.row==0)
        {
            NSDictionary *_attributes=nil;
            
            CGRect _frame;
            _frame=CGRectMake(0.0, 0.0, tableView.frame.size.width, 56.5);
            _attributes=@{
                          kCCBackgroundColor:[UIColor colorWithRed:221.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0]
                          };
            [_cell.contentView addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];
            
            CGRect _titleLabelFrame=CGRectMake(10.0, 10.5, tableView.frame.size.width-20.0, 14);
           
            
            NSString *_titleString=@"Job confirmed!";
            NSString *_description=@"Please arrive at your destination within the hour";
            
            if (appDelegate().jobDetail.status==JSStarted)
            {
                _titleString=@"Job Started!";
                _description=@"Remember to mark the job as complete to receive your payment!";
            }
            
            _titleLabel=[ccManager() labelWithAttributes:nil frame:_titleLabelFrame];
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.52/2.0],
                          kASTextColor:[UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kASText:_titleString,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:13.0]
                          };
            _titleLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_titleLabel];
            
             CGRect _subtitleLabelFrame=CGRectMake(10.0, _titleLabelFrame.size.height+7.0+_titleLabelFrame.origin.y, tableView.frame.size.width-20.0, 13.0);
           
            if (appDelegate().jobDetail.status==JSStarted)
            {
                _subtitleLabelFrame=CGRectMake(10.0,  _titleLabelFrame.size.height+_titleLabelFrame.origin.y-6.0, _tableView.frame.size.width-20.0, 35.0);
            }
            
            _subtitleLabel=[ccManager() labelWithAttributes:nil frame:_subtitleLabelFrame];
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.52/2.0],
                          kASTextColor:[UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kASText:_description,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_MEDIUM size:12.0],
                          kASLineSpace:[NSNumber numberWithFloat:-6.0]
                          };
             _subtitleLabel.numberOfLines=2;
            _subtitleLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_subtitleLabel];
            
            _frame=CGRectMake(tableView.frame.size.width/2-136.0/2.0, _frame.origin.y+_frame.size.height+20.0, 136.0, 136.0);
            _attributes=@{
                          kCCContentMode:[NSNumber numberWithInt:UIViewContentModeScaleAspectFill],
                          kCCImage:[UIImage imageNamed:@"Loading_Image.png"],
                          kCCCornerRadius:[NSNumber numberWithFloat:_frame.size.width/2.0]
                          };
            _profileImageView=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
            [_cell.contentView addSubview:_profileImageView];
            [self getAndSetprofileImageForConsumer];
            
            
            
            _frame=CGRectMake(10.0, _frame.origin.y+_frame.size.height+11.5, _tableView.frame.size.width-20.0, 17.0);
            UILabel *_techinicianNameLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:4.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:[appDelegate().jobDetail.consumer.firstName uppercaseString],
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:16.0]
                          };
            _techinicianNameLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            
            [_cell.contentView addSubview:_techinicianNameLabel];
            
            CGFloat _yOffset=_frame.origin.y+_frame.size.height+11.5;
            CGFloat _xOffset=tableView.frame.size.width/2-(15*5)/2;
            
            [_ratingStarImageviewsArray removeAllObjects];
            for (int i=0; i<5; i++)
            {
                if (i>=appDelegate().jobDetail.consumer.rating)
                {
                    _attributes =@{
                                   kCCImage:[UIImage imageNamed:@"Star_No_Fill.png"]
                                   };
                }
                else
                {
                    _attributes =@{
                                   kCCImage:[UIImage imageNamed:@"Star_Fill.png"]
                                   };
                }
               
                _frame=CGRectMake(_xOffset, _yOffset, 13.0, 13.0);
              
                UIImageView *_starImageView=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
                [_cell.contentView addSubview:_starImageView];
              
                _xOffset+=15.0;
              
                [_ratingStarImageviewsArray addObject:_starImageView];
            }
            
            
            _frame=CGRectMake(10.0, _yOffset+13.0+11.5, _tableView.frame.size.width-20.0, 20.0);
            
            UILabel *_techinicianPhoneNumberLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.48/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:appDelegate().jobDetail.consumer.mobile,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_MEDIUM size:12.0],
                          kASIsUnderLine:@"YES"
                          };
            NSMutableAttributedString *_mobileNumberAttributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            
            _techinicianPhoneNumberLabel.attributedText=_mobileNumberAttributedString;
            
            [_cell.contentView addSubview:_techinicianPhoneNumberLabel];
            
            [_cell.contentView addSubview:[ccManager() buttonWithAttributes:nil frame:_frame completion:^(UIButton *sender){
                [self phoneNumberButtonAction];
            }]];
            
        }
        
        else if (indexPath.row==1)
        {
            int numberOfRows=5;
            
            NSDictionary *_attributes=nil;
            
            CGRect _frame=CGRectMake(8.0, 0.0, tableView.frame.size.width-16.0, 220.0);
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_BROWN
                      ];
            
            CustomLayer*_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMVertical];
            [_cell.contentView addSubview:_customLayer];
            
            
            _attributes=@{
                          kCCBackgroundColor: [UIColor whiteColor]
                          };
            
            _frame=CGRectMake(_frame.origin.x+0.5, _frame.origin.y+0.5,_frame.size.width-1.0, _frame.size.height-1.0);
            UIView *_containerView=[ccManager() viewWithAttributes:_attributes frame:_frame];
            [_cell.contentView addSubview:_containerView];
            
            
            
            [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, _containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.5)]];
            
            [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, 2*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.5)]];
            
            [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, 3*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.5)]];
            
            
            _frame=CGRectMake(16.0, 0.0, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"TYPE OF BOOKING",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticTypeOfBookingLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTypeOfBookingLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticTypeOfBookingLabel];
            
            
            
            _attributes=@{
                          kCCText: appDelegate().jobDetail.itemName,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            
            _frame=CGRectMake(16.0, _containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"PAY",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticPayLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticPayLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticPayLabel];
            
            
            _attributes=@{
                          kCCText: [NSString stringWithFormat:@"$%i",(int)appDelegate().jobDetail.technicianFee],
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            
            _frame=CGRectMake(16.0, 2*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"TIME OF BOOKING",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticTimeOfBookingLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTimeOfBookingLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticTimeOfBookingLabel];
            
            _attributes=@{
                          kCCText: appDelegate().jobDetail.timeString,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            _timeLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
            [_containerView addSubview:_timeLabel];
            
            _frame=CGRectMake(16.0, 3*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"LOCATION",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticLocationLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticLocationLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticLocationLabel];
            
              _frame=CGRectMake(90.0, 3*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-105.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kCCText: appDelegate().jobDetail.location,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
           
            _frame=CGRectMake(_containerView.frame.size.width-16.0-12.0, 4*_containerView.frame.size.height/numberOfRows, 24.0, 0.5);;
       

            _colors=@[
                      COLOR_THEME_BROWN,
                      COLOR_THEME_LIGHTPINK
                     ];
            _customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_customLayer];
            
            
            
            _frame=CGRectMake(16.0, 4*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.6/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"Show Map",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            UILabel *_staticShowMapLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticShowMapLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticShowMapLabel];
            
            [_containerView addSubview:[ccManager() buttonWithAttributes:nil frame:_frame completion:^(UIButton *sender)
            {
                [self showMapView];
            }]];
            
        }
    }
    
    if (indexPath.row==0)
    {
        [self getAndSetprofileImageForConsumer];
        
        int i=0;
        for (UIImageView *_starImageView in _ratingStarImageviewsArray)
        {
            if (i>=appDelegate().jobDetail.consumer.rating)
            {
                _starImageView.image=[UIImage imageNamed:@"Star_No_Fill.png"];
            }
            else
            {
                _starImageView.image=[UIImage imageNamed:@"Star_Fill.png"];
            }
            i++;
        }
        
    }
    if (indexPath.row==1)
    {
        _timeLabel.text=appDelegate().jobDetail.timeString;
    }

    return _cell;
}


- (void)showMapView
{
    NSString* _consumerLocationAddress = appDelegate().jobDetail.location;
   
    NSString* _currentLocation = @"Current Location";
   
    NSString* url = [NSString stringWithFormat: @"http://maps.apple.com/maps?saddr=%@&daddr=%@",[_currentLocation stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding],[_consumerLocationAddress stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
   
    [[UIApplication sharedApplication] openURL: [NSURL URLWithString: url]];
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONS
#pragma mark------------------------------------------------------------

- (void)menuButtonAction
{
    [self.menuContainerViewController openSideMenu];
}


- (void)phoneNumberButtonAction
{
    UIActionSheet *_actionSheet=[[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"SMS",@"Call", nil];
    [_actionSheet showInView:self.view];
}


- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex==0)
    {
        [self showMessageController];
    }
    else if (buttonIndex==1)
    {
        [self call];
    }
}


- (void)showMessageController
{
    if(![MFMessageComposeViewController canSendText])
    {
        [ccManager() showAlertWithTitle:@"Error" message:@"Your device doesn't support SMS!" buttons:nil completion:nil];
        return;
    }
    
    NSArray *_recipents = @[appDelegate().jobDetail.consumer.mobile];
    
    MFMessageComposeViewController *_messageController = [[MFMessageComposeViewController alloc] init];
    _messageController.messageComposeDelegate = self;
    [_messageController setRecipients:_recipents];
    [self presentViewController:_messageController animated:YES completion:nil];
}


- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult) result
{
    switch (result) {
        case MessageComposeResultCancelled:
            break;
            
        case MessageComposeResultFailed:
        {
            [ccManager() showAlertWithTitle:@"Error" message:@"Failed to send SMS!" buttons:nil completion:nil];
            break;
        }
            
        case MessageComposeResultSent:
            break;
            
        default:
            break;
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (void)call
{
    NSURL *_phoneUrl = [NSURL URLWithString:[NSString  stringWithFormat:@"telprompt://%@",appDelegate().jobDetail.consumer.mobile]];
    [[UIApplication sharedApplication] openURL:_phoneUrl];
}


- (void)cancelButtonAction
{
    NSString *_messageString=[NSString stringWithFormat:@"Cancelling a job will give you a 0 star rating and incur a $%i fee",(int)appDelegate().jobDetail.technicianCancellationFees];
    [ccManager() showAlertWithTitle:@"Do you wish to cancel the job?" message:_messageString buttons:@[@"Yes",@"No"] completion:^(NSInteger buttonIndex){
        
        if (buttonIndex==0)
        {
            LACancelBookingVC *_cancelBookingVC=[[LACancelBookingVC alloc]init];
            [self.navigationController pushViewController:_cancelBookingVC animated:YES];
        }
    }];
}


- (void)statusButtonAction
{
    if (appDelegate().jobDetail.status==JSPending)
    {
        [ccManager() showAlertWithTitle:@"Arrived at Location" message:@"Confirm you have arrived" buttons:@[@"No",@"Yes"] completion:^(NSInteger buttonIndex){
            
            if (buttonIndex==1)
            {
                [progressHud() showWithTitle:@"Please wait"];
                
                NSDictionary *_attributes=@{
                                            @"userId":appDelegate().userInfo.userId,
                                            @"status":@"4",
                                            @"jobId":appDelegate().jobDetail.jobId
                                            };
                
                [API() markJobsAsArrivedWithAttributes:_attributes completion:^(BOOL success, NSError *error,BOOL invalid)
                 {

                     if (success)
                     {
                        [progressHud() hide];
                        
                         NSMutableDictionary *_jobDetail=[NSMutableDictionary dictionaryWithDictionary:[[NSUserDefaults standardUserDefaults]objectForKey:@"LastJobDetail"]];
                         [_jobDetail setObject:@"4" forKey:@"status"];
                         [[NSUserDefaults standardUserDefaults]setObject:_jobDetail forKey:@"LastJobDetail"];
                         [[NSUserDefaults standardUserDefaults]synchronize];
                         
                         [appDelegate().jobDetail updateWithAttributes:_jobDetail];
                         
                         [self updateStatusButtonAttributes];
                         
                         
                         NSDictionary *_attributes;
                         _attributes=@{
                                       kASCharacterSpace:[NSNumber numberWithFloat:0.52/2.0],
                                       kASTextColor:[UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                                       kASText:@"Job Started!",
                                       kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:13.0]
                                       };
                         _titleLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
                       
                         _attributes=@{
                                       kASCharacterSpace:[NSNumber numberWithFloat:0.52/2.0],
                                       kASTextColor:[UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                                       kASText:@"Remember to mark the job as complete to receive your payment!",
                                       kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_MEDIUM size:12.0],
                                       kASLineSpace:[NSNumber numberWithFloat:-6.0]
                                       };
                         _subtitleLabel.numberOfLines=2;
                         _subtitleLabel.frame=CGRectMake(10.0, _subtitleLabel.frame.origin.y-10.0, _tableView.frame.size.width-20.0, 35.0);
                         _subtitleLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
     
                     }
                     else
                     {
                         if (invalid)
                         {
                             [progressHud() showWithTitle:@"Please wait"];
                             
                             NSDictionary *_attributes=@{
                                                         @"userId":appDelegate().userInfo.userId
                                                         };
                             [API() fetchLastCreatedJobStatusWithAttributes:_attributes completion:^(BOOL success,NSError *error1)
                              {
                                 [progressHud() hide];
                                
                                  if (success)
                                  {
                                      [self.menuContainerViewController switchView];
                                  }
                                  else
                                  {
                                      [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
                                  }
                              }];
                             return;
                         }
                         
                         [progressHud() hide];
                        
                         [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
                     }
                 }];
            }
        }];
    }
    else
    {
        [ccManager() showAlertWithTitle:@"Completed Booking" message:@"Confirm you have completed the job" buttons:@[@"No",@"Yes"] completion:^(NSInteger buttonIndex)
        {
            if (buttonIndex==1)
            {
                [progressHud() showWithTitle:@"Please wait"];
                
                NSDictionary *_attributes=@{
                                            @"userId":appDelegate().userInfo.userId,
                                            @"status":@"5",
                                            @"jobId":appDelegate().jobDetail.jobId
                                            };
                
                [API() markJobsAsArrivedWithAttributes:_attributes completion:^(BOOL success, NSError *error,BOOL invalid)
                 {
                     if (success)
                     {
                          [progressHud() hide];
                       
                         NSMutableDictionary *_jobDetail=[NSMutableDictionary dictionaryWithDictionary:[[NSUserDefaults standardUserDefaults]objectForKey:@"LastJobDetail"]];
                         [_jobDetail setObject:@"5" forKey:@"status"];
                         [[NSUserDefaults standardUserDefaults]setObject:_jobDetail forKey:@"LastJobDetail"];
                         [[NSUserDefaults standardUserDefaults]synchronize];
                         
                         [appDelegate().jobDetail updateWithAttributes:_jobDetail];
                         appDelegate().jobDetail.changed=YES;
                        
                         [self.menuContainerViewController switchView];
                     }
                     else
                     {
                         if (invalid)
                         {
                             [progressHud() showWithTitle:@"Please wait"];
                             
                             NSDictionary *_attributes=@{
                                                         @"userId":appDelegate().userInfo.userId
                                                         };
                             [API() fetchLastCreatedJobStatusWithAttributes:_attributes completion:^(BOOL success,NSError *error1)
                              {
                                  [progressHud() hide];
                                 
                                  if (success)
                                  {
                                      [self.menuContainerViewController switchView];
                                  }
                                  else
                                  {
                                      [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
                                  }
                              }];
                             return;
                         }
                          [progressHud() hide];
                         [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
                     }
                 }];
            }
        }];
        
    }
}


- (void)updateStatusButtonAttributes
{
     NSDictionary *_attributes=nil;
    if (appDelegate().jobDetail.status==JSPending)
    {
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:1.35],
                      kASTextColor:COLOR_THEME_BROWN,
                      kASText:@"ARRIVED AT LOCATION",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0]
                      };
        [_statusButton setAttributedTitle:[NSMutableAttributedString attributedStringWithAttributes:_attributes] forState:UIControlStateNormal];
        _statusButton.backgroundColor=COLOR_THEME_DARKGRAY;
    }
    else
    {
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:1.35],
                      kASTextColor:[UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                      kASText:@"COMPLETED BOOKING",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0]
                      };
        [_statusButton setAttributedTitle:[NSMutableAttributedString attributedStringWithAttributes:_attributes] forState:UIControlStateNormal];
         _statusButton.backgroundColor=COLOR_THEME_BROWN;
        
        self.navigationItem.rightBarButtonItem=nil;
        self.navigationItem.rightBarButtonItems=nil;
    }
}


- (void)getAndSetprofileImageForConsumer
{
      _profileImageView.contentMode=UIViewContentModeScaleAspectFill;
    if (appDelegate().jobDetail.consumer.imagePath.length==0)
    {
        _profileImageView.image=[UIImage imageNamed:@"Loading_Image.png"];
        return;
    }
    
    NSString *_imagePath=[NSString stringWithFormat:IMAGEURL,appDelegate().jobDetail.consumer.imagePath];

    NSString *_documentImageFileName=_imagePath;
    _documentImageFileName = [_documentImageFileName stringByReplacingOccurrencesOfString:@".jpg" withString:@""];
    _documentImageFileName = [_documentImageFileName stringByReplacingOccurrencesOfString:@".png" withString:@""];
    
    NSArray *_componentsArray=[_documentImageFileName componentsSeparatedByString:@"/"];
    if (_componentsArray.count>0)
        _documentImageFileName=[_componentsArray lastObject];
    
    
    UIImage *_image=[UIImage imageWithContentsOfFile:[[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:[NSString stringWithFormat:@"Images/%@.png",_documentImageFileName]]];
    
    if (_image)
    {
        _profileImageView.image=_image;
    }
    else
    {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^(void)
        {
            NSData *_imgData = [NSData dataWithContentsOfURL:[NSURL URLWithString:_imagePath]];
          
            UIImage *__image = [UIImage imageWithData:_imgData];
           
            NSString *_fileName=[[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:[NSString stringWithFormat:@"Images/%@.png",_documentImageFileName]];
            [_imgData writeToFile:_fileName atomically:YES];
           
            dispatch_sync(dispatch_get_main_queue(), ^(void)
            {
                if (__image!=nil)
                {
                    _profileImageView.image=__image;
                }
            });
        });
    }
}

@end
