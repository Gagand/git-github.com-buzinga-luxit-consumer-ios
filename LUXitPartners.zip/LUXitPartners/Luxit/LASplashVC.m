//
//  LASplashVC.m
//  Luxit-Partners
//
//  Created by GP on 02/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "LASplashVC.h"

@implementation LASplashVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor=COLOR_THEME_DARKGRAY;
    
    // BG GRADIENT LAYER
    NSArray *_colors=nil;
    _colors=@[
              COLOR_THEME_LIGHTPINK,
              COLOR_THEME_BROWN
              ];
   
    CustomLayer  *_customLayer=[[CustomLayer alloc]initWithFrame:self.view.bounds withColors:_colors gradientMode:GMVertical];
    [self.view addSubview:_customLayer];
    
    // DARK GRAY CONTAINER VIEW
    NSDictionary *_attributes=nil;
    _attributes=@{
                  kCCBackgroundColor: COLOR_THEME_DARKGRAY
                  };
   
    CGRect _frame=CGRectMake(3.0, 3.0, self.view.frame.size.width-6.0, self.view.frame.size.height-6.0);
    
    [self.view addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];
    
    // LOGO IMAGEVIEW
    UIImageView *_logoImageView=[[UIImageView alloc]initWithFrame:CGRectMake(0.0, 0.0, 145.0, 145.0)];
    _logoImageView.image=[UIImage imageNamed:@"Splash_Logo.png"];
    _logoImageView.center=CGPointMake(self.view.frame.size.width/2.0, self.view.frame.size.height/2.0);
    [self.view addSubview:_logoImageView];
    
    [self performSelector:@selector(showLoginViewController) withObject:nil afterDelay:2.5];
}


- (void)showLoginViewController
{
    if(appDelegate().userInfo.isUserAvailable)
    {
        [appDelegate() showUserHomeViewControllerWithAnimation:YES];
    }
    else
    {
        [appDelegate() showLoginViewController];
    }
}

@end
