//
//  JobInfo.m
//  Luxit-Partners
//
//  Created by GP on 15/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "JobInfo.h"

@implementation JobInfo

- (id)initWithAttributes:(NSDictionary *)attributes
{
    self=[super init];
    
    if (self)
    {
        NSDictionary *_jobDesciption=[attributes objectForKey:@"jobDescription"];
        
        _jobId=[_jobDesciption objectForKey:@"id"];
        _itemName=[_jobDesciption objectForKey:@"itemName"];
        _itemPrice=[_jobDesciption objectForKey:@"itemPrice"];
        
        _location=[_jobDesciption objectForKey:@"location"];
        
        NSDateFormatter *_dateFormatter=[[NSDateFormatter alloc]init];
        [_dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        
        _date=[_dateFormatter dateFromString:[_jobDesciption objectForKey:@"date"]];
       
        _compareDateString=[_jobDesciption objectForKey:@"date"];
        
        
        [_dateFormatter setDateFormat:@"dd"];
        _dayString=[_dateFormatter stringFromDate:_date];
        
        [_dateFormatter setDateFormat:@"MMMM"];
        _monthString=[_dateFormatter stringFromDate:_date];
        
        
        [_dateFormatter setDateFormat:@"hh:mm a"];
        _timeString=[_dateFormatter stringFromDate:_date];
        
        _dateString=@"";
        [_dateFormatter setDateFormat:@"d MMMM, yyyy"];
        _dateString=[_dateFormatter stringFromDate:_date];
        
        if ([[_jobDesciption objectForKey:@"jobStatus"]isEqualToString:@"Completed"])
        {
            _statusString=@"Completed";
        }
        else
        {
            _statusString=@"Cancelled";
        }
        
        _technicianFee=0.0;
        if ([_jobDesciption.allKeys containsObject:@"technician_fee"] && (NSNull *)[_jobDesciption objectForKey:@"technician_fee"]!=[NSNull null])
        {
            _technicianFee=[[_jobDesciption objectForKey:@"technician_fee"]floatValue];
        }
        
        
        _consumer=[[ConsumerInfo alloc]init];
        [_consumer updateWithAttributes:[attributes objectForKey:@"consumerInfo"]];
    }
    return self;
}
@end
