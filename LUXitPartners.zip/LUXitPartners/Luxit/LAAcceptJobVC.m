//
//  LAAcceptJobVC.m
//  Luxit-Partners
//
//  Created by GP on 03/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "LAAcceptJobVC.h"

@implementation LAAcceptJobVC

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSDictionary *_attributes=nil;
    _attributes=@{
                  kCCBackgroundColor:[UIColor colorWithRed:22.0/255.0 green:22.0/255.0 blue:22.0/255.0 alpha:0.8]
                  };
    
    _containerView=[ccManager() viewWithAttributes:_attributes frame:self.view.bounds];
    [self.view addSubview:_containerView];
    _containerView.alpha=0.0;
    
    CGRect _frame=CGRectMake(10.0, self.view.frame.size.height/2-135.0, self.view.frame.size.width-20.0, 19.0);
    
    UILabel *_headerLabel=[ccManager() labelWithAttributes:nil frame:_frame];
    [_containerView addSubview:_headerLabel];
    
    _attributes=@{
                  kASCharacterSpace: [NSNumber numberWithFloat:0.9/2.0],
                  kASTextColor:[UIColor whiteColor],
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0],
                  kASText:@"Job available"
                  };
    
    _headerLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
    
    _frame=CGRectMake(self.view.frame.size.width/2.0-145.0/2.0, _frame.origin.y+_frame.size.height+27.5, 145.0, 145.0);
    
    _attributes=@{
                  kCCImage: [UIImage imageNamed:@"Countdown_Frame.png"]
                  };
    [_containerView addSubview:[ccManager() imageViewWithAttributes:_attributes frame:_frame]];
    
    _timerCountLabel=[ccManager() labelWithAttributes:nil frame:_frame];
    [_containerView addSubview:_timerCountLabel];
    
    
    _frame=CGRectMake(self.view.frame.size.width/2-12.0, _frame.origin.y+_frame.size.height+28.0, 24, 0.5);
    
    _attributes=@{
                  kCCBackgroundColor: [UIColor colorWithRed:253.0/255.0 green:215.0/255.0 blue:187.0/255.0 alpha:1.0]
                  };
    [_containerView addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];
   
    
    _frame=CGRectMake(10.0, _frame.origin.y+_frame.size.height+20.0, self.view.frame.size.width-20.0, 19.0);
   
    UILabel *_bottomLabel=[ccManager() labelWithAttributes:nil frame:_frame];
    [_containerView addSubview:_bottomLabel];
    _attributes=@{
                  kASCharacterSpace: [NSNumber numberWithFloat:0.7/2.0],
                  kASTextColor:[UIColor whiteColor],
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0],
                  kASText:@"Tap screen to accept booking"
                  };
    
    _bottomLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
    
    [_containerView addGestureRecognizer:[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(handleTap)]];
    
  //  _timeCount=30;
    [self updateTimerLabel];
   
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self showContainerView];
}


- (void)showContainerView
{
    
    if([[UIApplication sharedApplication] applicationState] == UIApplicationStateActive){

    [UIView animateWithDuration:0.5 animations:^()
    {
        _containerView.alpha=1.0;
    }
    completion:^(BOOL finishded)
    {
        if (finishded)
        {
            [self performSelector:@selector(addTimer) onThread:[NSThread mainThread] withObject:nil waitUntilDone:NO];
       
        }
    }];
    }
    else{
        _containerView.alpha=1.0;
        [self performSelector:@selector(addTimer) onThread:[NSThread mainThread] withObject:nil waitUntilDone:NO];

    
    }
}


- (void)addTimer
{
    [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:nil];
    _timer= [NSTimer timerWithTimeInterval:1.0
                                    target:self
                                  selector:@selector(updateCounter)
                                  userInfo:nil
                                   repeats:YES];;
    
    [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];

}


- (void)hideContainerView
{
    
    if([[UIApplication sharedApplication] applicationState] == UIApplicationStateActive){
        [UIView animateWithDuration:0.2 animations:^()
         {
             _containerView.alpha=0.0;
         } completion:^(BOOL finishded)
         {
             if (finishded)
             {
                 [self dismissViewControllerAnimated:NO completion:nil];
             }
         }];

     }
    else{
        _containerView.alpha=0.0;
        
        [self dismissViewControllerAnimated:NO completion:nil];
    }

}


- (void)updateCounter
{
    
    NSLog(@"yoyoyoyo %d",_timeCount);
    
    if (_timeCount>0)
    {
        _timeCount--;
        [self updateTimerLabel];
    }
    else
    {
        if (_timer)
        {
            [_timer invalidate];
            _timer=nil;
        }
        
        if (_finishedCancellingJob)
        {
            _finishedCancellingJob(NO);
        }
        
        [self hideContainerView];
    }
}


- (void)updateTimerLabel
{
    int minutes = floor(_timeCount/60);
    int seconds = round(_timeCount - minutes * 60);
  
    NSString *_formattedString = [NSString stringWithFormat:@"%i:%02i",minutes,seconds] ;
    
    NSDictionary *_attributes;
    _attributes=@{
                  kASCharacterSpace: [NSNumber numberWithFloat:7.2/2.0],
                  kASTextColor:[UIColor whiteColor],
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:36.0],
                  kASText:_formattedString
                  };
    _timerCountLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
}


- (void)handleTap
{
    if (_timer)
    {
        [_timer invalidate];
        _timer=nil;
    }
   
    NSDictionary *_attributes=@{
                                @"userId":appDelegate().userInfo.userId,
                                @"status":@"1",
                                @"jobId":_job.jobId
                                };
    
    [progressHud() showWithTitle:@"Please wait"];
    
    [API() acceptJobsWithAttributes:_attributes completion:^(BOOL success, NSError *error)
     {
         [progressHud() hide];
         
         if (success)
         {
             NSMutableDictionary *_jobDetail=[NSMutableDictionary dictionaryWithCapacity:10];
             [_jobDetail setObject:_job.jobId forKey:@"id"];
             [_jobDetail setObject:_job.itemName forKey:@"itemName"];
             [_jobDetail setObject:[NSString stringWithFormat:@"%f",_job.itemPrice] forKey:@"itemPrice"];
             [_jobDetail setObject:[NSString stringWithFormat:@"%i",_job.timeInterval] forKey:@"timeInterval"];
             [_jobDetail setObject:_job.location forKey:@"location"];
             [_jobDetail setObject:[NSString stringWithFormat:@"%f",_job.cancellationFees]forKey:@"cancellationFees"];
              [_jobDetail setObject:[NSString stringWithFormat:@"%f",_job.technicianCancellationFees]forKey:@"technicianCancellationFees"];
             [_jobDetail setObject:_job.saveDateString forKey:@"date"];
             [_jobDetail setObject:@"1" forKey:@"status"];
             [_jobDetail setObject:[NSString stringWithFormat:@"%f",_job.technicianFee] forKey:@"technicianFee"];
             
             
             NSMutableDictionary *_consumerInfo=[NSMutableDictionary dictionaryWithCapacity:5];
             [_consumerInfo setObject:_job.consumer.mobile    forKey:@"mobileNo"];
             [_consumerInfo setObject:_job.consumer.imagePath forKey:@"image"];
             [_consumerInfo setObject:_job.consumer.firstName forKey:@"first_name"];
             [_consumerInfo setObject:_job.consumer.lastName  forKey:@"last_name"];
             [_consumerInfo setObject:_job.consumer.name      forKey:@"name"];
             [_consumerInfo setObject:[NSString stringWithFormat:@"%i",_job.consumer.rating*2]      forKey:@"rating"];
             
             [_jobDetail setObject:_consumerInfo forKey:@"consumer"];
             
             [[NSUserDefaults standardUserDefaults]setObject:_jobDetail forKey:@"LastJobDetail"];
             [[NSUserDefaults standardUserDefaults]synchronize];
             
             [appDelegate().jobDetail updateWithAttributes:_jobDetail];
             appDelegate().jobDetail.changed=YES;
             appDelegate().jobDetail.status=JSPending;
 
             if (_finishedAcceptingJob)
             {
                  _finishedAcceptingJob();
              }
             
              [self dismissViewControllerAnimated:NO completion:nil];
         }
         else
         {
             [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo]objectForKey:@"description"] buttons:nil completion:^(NSInteger buttonIndex)
             {
                 if (_finishedCancellingJob)
                 {
                     _finishedCancellingJob(YES);
                 }
                 
                 [self hideContainerView];
             }];
         }
     }];
}

@end
