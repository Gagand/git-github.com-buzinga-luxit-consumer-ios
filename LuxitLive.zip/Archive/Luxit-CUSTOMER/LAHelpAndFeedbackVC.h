//
//  LAHelpAndFeedbackVC.h
//  Luxit
//
//  Created by GP on 24/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>

@interface LAHelpAndFeedbackVC : UIViewController<MFMailComposeViewControllerDelegate>
{
    UIScrollView *_scrollView;
}
@end
