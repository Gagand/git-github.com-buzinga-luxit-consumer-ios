//
//  LAUserHomeVC.h
//  Luxit
//
//  Created by GP on 21/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LAPlaceOrderVC.h"
#import "LALocationPickerVC.h"
#import "LATechnicianSearchVC.h"
#import "MenuItem.h"
#import "LAAddPaymentTypeVC.h"
#import "LABookedTechinicanDetailVC.h"
#import "LACompletionReceiptVC.h"
#import "LAFeedbackVC.h"

@interface LAUserHomeVC : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    UITableView     *_tableView;
    NSMutableArray  *_menuItems;
    UILabel         *_locationLabel;
    BOOL             _isJobStatusFeteched;
    BOOL             _isCategoriesFeteched;
    UIButton        *_locatioButton;
}

@end
