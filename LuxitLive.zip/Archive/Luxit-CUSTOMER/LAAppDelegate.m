//
//  LAAppDelegate.m
//  Luxit
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "LASplashVC.h"
#import "LAAppHomeVC.h"
#import "LAUserHomeVC.h"
#import "LAAppDelegate.h"
#import "LACompletionReceiptVC.h"
#import "LAParentViewController.h"
#import "LACreateProfileVC.h"

static NSString *const kTrackingId    = @"UA-70502629-1";
static NSString *const kAllowTracking = @"allowTracking";

@implementation LAAppDelegate

#pragma mark------------------------------------------------------------
#pragma mark WINDOW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    // GA
    [GAI sharedInstance].trackUncaughtExceptions = YES;
    [[GAI sharedInstance].logger setLogLevel:kGAILogLevelNone];
    [GAI sharedInstance].dispatchInterval = 5;
    [[GAI sharedInstance] trackerWithTrackingId:kTrackingId];
    
    id tracker = [[GAI sharedInstance] defaultTracker];
    [tracker set:kGAIScreenName value:@"LUXit"];
    [tracker send:[[GAIDictionaryBuilder createScreenView] build]];
    
    
    // CREATE A IMAGE FOLDER IN ORDER TO SAVE IMAGES
    NSArray  *_documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *_documentsDir  = [_documentPaths objectAtIndex:0];
    NSString *_imagesFolder   = [_documentsDir stringByAppendingPathComponent:@"Images"];
    
    if (![[NSFileManager defaultManager]fileExistsAtPath:_imagesFolder])
    {
        [[NSFileManager defaultManager]createDirectoryAtPath:_imagesFolder withIntermediateDirectories:NO attributes:nil error:nil];
    }
    
    _userInfo=[[UserInfo alloc]init];
    [_userInfo updateWithAttributes:[[NSUserDefaults standardUserDefaults]objectForKey:@"UserInfo"]];
    
    _jobDetail=[[JobDetail alloc]init];
    [_jobDetail updateWithAttributes:[[NSUserDefaults standardUserDefaults]objectForKey:@"LastJobDetail"]];
    

    // REMOTE NOTIFICATION
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:1];
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];

    // UPDATE DATE WHEN APP IS OPEN FROM PUSH NOTIFICATION BANNER VIEW
    NSDictionary *_remoteNotification = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
   
    if (_remoteNotification)
    {
        if (_receiveRemoteNotification)
        {
            _receiveRemoteNotification(_remoteNotification);
        }
    }

    //LOCATION MANAGER
    _locationManager=[[CLLocationManager alloc]init];
    _locationManager.delegate=self;
    _locationManager.distanceFilter = kCLDistanceFilterNone;
    _locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters;
    [self disableLocationService];
    
    [self showSplashViewController];
    
    return YES;
}


- (void)applicationWillEnterForeground:(UIApplication *)application
{
    [FBSession.activeSession handleDidBecomeActive];
    
    if (_updateAppStatus)
    {
        _updateAppStatus(ASForeground);
    }
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:1];
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
}


- (void)applicationDidEnterBackground:(UIApplication *)application
{
    if (_updateAppStatus)
    {
        _updateAppStatus(ASBackground);
    }
    [self sendHitsInBackground];
}


- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
   if ([[url scheme] isEqualToString:@"fb1664159603826329"])
   {
       BOOL _isSession=[self.session handleOpenURL:url];
       return _isSession;
   }
    return YES;
}


-(void)application:(UIApplication *)application performFetchWithCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler
{
    [self sendHitsInBackground];
    completionHandler(UIBackgroundFetchResultNewData);
}


- (void)applicationDidBecomeActive:(UIApplication *)application
{
    [GAI sharedInstance].optOut = ![[NSUserDefaults standardUserDefaults] boolForKey:kAllowTracking];
}


#pragma mark------------------------------------------------------------
#pragma mark GOOGLE ANALYTICS
#pragma mark------------------------------------------------------------

- (void)sendHitsInBackground
{
    self.okToWait = YES;
    __weak LAAppDelegate *weakSelf = self;
    __block UIBackgroundTaskIdentifier backgroundTaskId =
   
    [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
        weakSelf.okToWait = NO;
    }];
    
    if (backgroundTaskId == UIBackgroundTaskInvalid)
        return;
    
    self.dispatchHandler = ^(GAIDispatchResult result)
    {
        if (result == kGAIDispatchGood && weakSelf.okToWait )
            [[GAI sharedInstance] dispatchWithCompletionHandler:weakSelf.dispatchHandler];
        else
            [[UIApplication sharedApplication] endBackgroundTask:backgroundTaskId];
    };
    
    [[GAI sharedInstance] dispatchWithCompletionHandler:self.dispatchHandler];
}


#pragma mark------------------------------------------------------------
#pragma mark VIEW CONTROLLERs
#pragma mark------------------------------------------------------------

- (void)showSplashViewController
{
    _window.rootViewController=[[LASplashVC alloc]init];
}


- (void)showAppHomeViewController
{
    if (_navigationController)
    {
        _navigationController=nil;
    }
    
    _navigationController=[[UINavigationController alloc]initWithRootViewController:[[LAAppHomeVC alloc]init]];
    _navigationController.navigationBarHidden=YES;

    _window.rootViewController=_navigationController;
    
    [UIView transitionWithView:_window duration:0.25 options:UIViewAnimationOptionTransitionCrossDissolve animations:nil completion:nil];
}


- (void)showUserHomeViewController
{
    if (_navigationController)
    {
        _navigationController=nil;
    }
    
    if (_userInfo.mobile.length>0)
    {
        [API() updateDeviceTokenWithAttributes:nil completion:nil];
        
        _navigationController=[[UINavigationController alloc]initWithRootViewController:[[LAUserHomeVC alloc]init]];
        
        NSDictionary *_attributes=nil;
        _attributes=@{
                      kCCTintColor: COLOR_THEME_BROWN,
                      kCCBarTintColor:[UIColor whiteColor],
                      kCCTextColor:COLOR_THEME_BROWN,
                      kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                      };
        
        [ccManager() customizeNavigationBarWithAttributes:_attributes navigationController:_navigationController];
        
        LAParentViewController *_parentVC=[LAParentViewController containerWithCenterViewController:_navigationController];
        
        _window.rootViewController=_parentVC;
    }
    else
    {
        _navigationController=[[UINavigationController alloc]initWithRootViewController:[[LACreateProfileVC alloc]init]];
        _navigationController.navigationBarHidden=YES;
        
        _window.rootViewController=_navigationController;
    }
    
    [UIView transitionWithView:_window duration:0.25 options:UIViewAnimationOptionTransitionCrossDissolve animations:nil completion:nil];
}


#pragma mark------------------------------------------------------------
#pragma mark PUSH NOTIFICATION DELEGATES
#pragma mark------------------------------------------------------------

- (void)enablePushNotification
{
    UIUserNotificationSettings *_settings = [UIUserNotificationSettings settingsForTypes: (UIRemoteNotificationTypeBadge|UIRemoteNotificationTypeSound|UIRemoteNotificationTypeAlert) categories:nil];
    [[UIApplication sharedApplication] registerUserNotificationSettings:_settings];
}


- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
    NSMutableString *_devToken = [NSMutableString stringWithFormat:@"%@",deviceToken];
    [_devToken replaceOccurrencesOfString:@"<" withString:@"" options:0 range:NSMakeRange(0, [_devToken length])];
    [_devToken replaceOccurrencesOfString:@">" withString:@"" options:0 range:NSMakeRange(0, [_devToken length])];
    [_devToken replaceOccurrencesOfString:@" " withString:@"" options:0 range:NSMakeRange(0, [_devToken length])];
    [[NSUserDefaults standardUserDefaults] setObject:_devToken forKey:@"deviceToken"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    if (appDelegate().userInfo.isUserAvailable)
    {
        [API() updateDeviceTokenWithAttributes:nil completion:nil];
    }
}


- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    if (_receiveRemoteNotification)
    {
        _receiveRemoteNotification(userInfo);
    }
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:1];
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
}


- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:  (UIUserNotificationSettings *)notificationSettings
{
    if (notificationSettings.types==UIUserNotificationTypeNone)
    {
        [self validateRemoteNotification];
    }
    [application registerForRemoteNotifications];
}

// CHECK COUNT TO SHOW PUSH NOTIFCATION REMINDER
- (void)validateRemoteNotification
{
    if ([[UIApplication sharedApplication] isRegisteredForRemoteNotifications])
    {
        [[NSUserDefaults standardUserDefaults]setObject:@"0" forKey:@"AppNotificationShown"];
        [[NSUserDefaults standardUserDefaults]synchronize];
    }
    else
    {
        if ([[NSUserDefaults standardUserDefaults]objectForKey:@"AppNotificationShown"]==NULL) {
            [self showRemoteNotificationAlert];
            return;
        }
        
        if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"AppNotificationShown"] intValue]==3)
        {
            [self showRemoteNotificationAlert];
        }
        else
        {
            [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%i",[[[NSUserDefaults standardUserDefaults]objectForKey:@"AppNotificationShown"] intValue]+1] forKey:@"AppNotificationShown"];
            [[NSUserDefaults standardUserDefaults]synchronize];
        }
    }
}


- (void)showRemoteNotificationAlert
{
    [[NSUserDefaults standardUserDefaults]setObject:@"1" forKey:@"AppNotificationShown"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    NSArray *_buttonsArray=@[@"Close",@"Go to Settings"];

    [ccManager() showAlertWithTitle:@"Change your Settings to allow LUXit to Send You Push Notifications" message:@"We need to be able to send you Push Notifications to let you know when a technician accepts your booking.Please go to the App Settings, tap on Notifications and then select Allow Notifications." buttons:_buttonsArray completion:^(NSInteger buttonIndex)
    {
        if ([[_buttonsArray objectAtIndex:buttonIndex]isEqualToString:@"Go to Settings"])
        {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
        }
    }];
}


#pragma mark------------------------------------------------------------
#pragma mark CLLOCATION MANAGER DELEGATE
#pragma mark------------------------------------------------------------

-(void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    _locationEnabled=YES;

    [self updateUserLocationInfoForLat:newLocation.coordinate.latitude Lng:newLocation.coordinate.longitude];
}


-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"MyCurrentLocation"]==NULL)
    {
        _locationEnabled=NO;
    }
    else
    {
        _locationEnabled=YES;
    }
}


- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status
{
    _locationServiceStatus=0;
   
    if(status==kCLAuthorizationStatusNotDetermined)
    {
        _locationServiceStatus=0;
    }
    else if (status == kCLAuthorizationStatusAuthorized|| status == 3 || status == 4)
    {
         _locationServiceStatus=1;
        if (_updateLocationAuthorization)
        {
            _updateLocationAuthorization(YES);
        }
    }
    else if (status == kCLAuthorizationStatusDenied)
    {
         _locationServiceStatus=2;
        
        if (_updateLocationAuthorization)
        {
            _updateLocationAuthorization(NO);
        }
    }
}


- (void)enableLocationService
{
    [_locationManager requestAlwaysAuthorization];
    [_locationManager startUpdatingLocation];
}


- (void)disableLocationService
{
    [_locationManager stopUpdatingLocation];
}


- (void)updateUserLocationInfoForLat:(double)lat Lng:(double)lng
{
    BOOL _updateLocation=NO;
   
    if (lat!=0.0||lng!=0.0)
    {
        if ((NSNull *)[[NSUserDefaults standardUserDefaults]objectForKey:@"MyCurrentLocation"]!=[NSNull null])
        {
            CLLocation *_currentLocation = [[CLLocation alloc] initWithLatitude:lat longitude:lng];
            
            CLLocation *_previousLocation = [[CLLocation alloc] initWithLatitude:[[[[NSUserDefaults standardUserDefaults]objectForKey:@"MyCurrentLocation"]objectForKey:@"Lat"]doubleValue] longitude:[[[[NSUserDefaults standardUserDefaults]objectForKey:@"MyCurrentLocation"]objectForKey:@"Lng"]doubleValue]];
            
            CLLocationDistance _distance = [_currentLocation distanceFromLocation:_previousLocation];
           
            if (_distance>200)
            {
                _updateLocation=YES;
            }
            else
            {
                _updateLocation=NO;
            }
        }
        else
        {
            _updateLocation=YES;
        }
    }
    else
    {
        _updateLocation=NO;
    }

    if (_updateLocation)
    {
        [API() fetchPlaceNameForLat:[[NSNumber numberWithDouble:lat]stringValue] lng:[[NSNumber numberWithDouble:lng]stringValue] completion:^(NSString *location,BOOL success)
         {
             if (success)
             {
                 NSMutableDictionary *_dict=[NSMutableDictionary dictionaryWithCapacity:3];
                 [_dict setObject:location forKey:@"Address"];
                 [_dict setObject:[[NSNumber numberWithDouble:lat]stringValue] forKey:@"Lat"];
                 [_dict setObject:[[NSNumber numberWithDouble:lng]stringValue] forKey:@"Lng"];
                
                 [[NSUserDefaults standardUserDefaults]setObject:_dict forKey:@"MyCurrentLocation"];
                 [[NSUserDefaults standardUserDefaults]synchronize];
             }
        }];
    }
}


#pragma mark------------------------------------------------------------
#pragma mark LOCAL NOTIFICATION
#pragma mark------------------------------------------------------------

- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification
{
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:1];
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
}

@end

LAAppDelegate *appDelegate(void)
{
    return (LAAppDelegate *)[UIApplication sharedApplication].delegate;
}
