//
//  LAPaymentMethodsVC.h
//  Luxit
//
//  Created by GP on 26/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LAAddPaymentTypeVC.h"

@interface LAPaymentMethodsVC : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *_tableView;
    UILabel     *_errorLabel;
}

@end
