//
//  LATimeExtendVC.h
//  LUXit
//
//  Created by GP on 09/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

typedef enum
{
    ETSimple,
    ETUponCancellation
}
ExtendTimeType;

#import <UIKit/UIKit.h>

@interface LATimeExtendVC : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *_tableView;
    UIView  *_blackOpaqueLayerView;
    UIView *_containerView;
    
    UIButton *_15mins;
    UIButton *_30mins;
    UIButton *_45mins;
    int      _timeInterval;
    UIScrollView *_timePickerScrollView;
    UIButton     *_selectedButton;
    
}

@property(nonatomic, copy)void(^finishedUpdatingJob)(void);
@property(nonatomic, copy)void(^finishedCancellingJob)(void);
@property(nonatomic, readwrite)ExtendTimeType type;

@end
