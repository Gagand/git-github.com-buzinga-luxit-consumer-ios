//
//  LAPaymentMethodsVC.m
//  Luxit
//
//  Created by GP on 26/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "LAPaymentMethodsVC.h"
#import "Constant.h"

@implementation LAPaymentMethodsVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];

    CGRect _frame=CGRectMake(0.0, 15.0, 190, 50.0);
  
    NSDictionary *_attributes;
    _attributes=@{
                  kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                  };
    UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];

    _attributes=@{
                  kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                  kASTextColor:COLOR_THEME_BROWN,
                  kASText:@"PAYMENT DETAILS",
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                  };
    [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
    
    self.navigationItem.titleView=_headerLabel;
   
    _attributes=@{
                  kCCImage: [UIImage imageNamed:@"Arrow.png"]
                  };
   
    UIButton *_cancelButton=[ccManager() buttonWithAttributes:_attributes frame:CGRectMake(0.0, 5.0, 80.0, 50.0) completion:^(UIButton *sender){
        [self.navigationController popViewControllerAnimated:YES];
    }];
    
    UIBarButtonItem *_cancelButtonItem=[[UIBarButtonItem alloc]initWithCustomView:_cancelButton];
    
    UIBarButtonItem *_leftSpaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    _leftSpaceItem.width = -31.0;
    
    self.navigationItem.leftBarButtonItems=[NSArray arrayWithObjects:_leftSpaceItem,_cancelButtonItem, nil];
    
    _attributes=@{
                  kCCText: @"Edit",
                  kCCTextColor:COLOR_THEME_BROWN,
                  kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight],
                  kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0]
                  };
  
    UIButton *_editButton=[ccManager() buttonWithAttributes:_attributes frame:CGRectMake(0.0, 0.0, 80.0, 50.0) completion:^(UIButton *sender){
        [self editButtonAction];
    }];

    UIBarButtonItem *__editButtonItem=[[UIBarButtonItem alloc]initWithCustomView:_editButton];
   
    _leftSpaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    _leftSpaceItem.width = -30.0;
  
    self.navigationItem.rightBarButtonItems=[NSArray arrayWithObjects:_leftSpaceItem,__editButtonItem, nil];
    
    _frame=CGRectMake(0.0, 0.0,self.view.frame.size.width , 1.0);
    _attributes=@{
                  kCCImage:[UIImage imageNamed:@"seprator.png"]
                  };
    UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
    [self.view addSubview:_divider];
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_tableView==nil)
    {
        _errorLabel=[ccManager() labelWithAttributes:nil frame:self.view.bounds];
       
        NSDictionary *_attributes=nil;
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:1.2],
                      kASTextColor:COLOR_THEME_BROWN,
                      kASText:@"No Payment method\nFound",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0]
                      };
        _errorLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
        [self.view addSubview:_errorLabel];
        
        _tableView=[[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.delegate=self;
        _tableView.dataSource=self;
        _tableView.backgroundColor=[UIColor clearColor];
        _tableView.separatorColor=[UIColor clearColor];
        [self.view addSubview:_tableView];
    }
    
    if (appDelegate().userInfo.paymentMode.isPaymentModeAvailable)
    {
        [_errorLabel setHidden:YES];
        [_tableView setHidden:NO];
        [_tableView reloadData];
    }
    else
    {
        [_errorLabel setHidden:NO];
        [_tableView setHidden:YES];
    }
}


#pragma mark------------------------------------------------------------
#pragma mark TABLEVIEW DELEGATE/ DATASOURCE
#pragma mark------------------------------------------------------------

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 45.0;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=@"Cell";
   
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
  
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        [_cell.contentView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: [UIColor colorWithWhite:0.0 alpha:0.2]} frame:CGRectMake(0.0, 44.5, tableView.frame.size.width, 0.5)]];
        
        
        NSDictionary *_attributes=nil;
        _attributes=@{
                      kCCTag:[NSNumber numberWithInt:100]
                      };
        CGRect _frame=CGRectMake(16.0, 14.0, 25.0, 17.0);
        [_cell.contentView addSubview:[ccManager() imageViewWithAttributes:_attributes frame:_frame]];
        
        _attributes=@{
                      kCCTextColor:COLOR_THEME_BROWN,
                      kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_MEDIUM size:13.0],
                      kCCTag:[NSNumber numberWithInt:101]
                      };
        _frame=CGRectMake(49.0, 0.0, tableView.frame.size.width-60.0, 45.0);
        [_cell.contentView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
    }
    
    UIImageView *_iconImageView=(UIImageView *)[_cell viewWithTag:100];
    UILabel *_label=(UILabel *)[_cell viewWithTag:101];

    if (appDelegate().userInfo.paymentMode.type==PTCreditCard)
    {
        _iconImageView.image=[UIImage imageNamed:@"Card_Gold.png"];
        
        _label.text=[NSString stringWithFormat:@"Ending in ****%@",[appDelegate().userInfo.paymentMode.cardNumber substringWithRange:NSMakeRange(appDelegate().userInfo.paymentMode.cardNumber.length-4, 4)]];
    }
    else
    {
        UIImage *_paypalIcon = [UIImage imageWithIcon:@"fa-cc-paypal" backgroundColor:[UIColor clearColor] iconColor:COLOR_THEME_BROWN fontSize:16];
        _iconImageView.image=_paypalIcon;
        
        _label.text=appDelegate().userInfo.paymentMode.email;
    }

    return _cell;
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 30.0;
}


-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *_headerView=[[UIView alloc]initWithFrame:CGRectMake(0.0, 0.0, tableView.frame.size.width, 30.0)];
 
    _headerView.backgroundColor=COLOR_THEME_BROWN;
    
    [_headerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN,kCCAlpha:@"0.6"} frame:CGRectMake(0.0, 0.0, tableView.frame.size.width, 1.0)]];
    
    NSDictionary *_attributes=nil;
    _attributes=@{
                  kASCharacterSpace:[NSNumber numberWithFloat:1.2],
                  kASTextColor:[UIColor whiteColor],
                  kASText:@"Your Payment Options",
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                  kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                  };

     CGRect _frame=CGRectMake(16.0, 0.0, _headerView.frame.size.width-20.0, _headerView.frame.size.height);
  
    UILabel *_headerLabel=[ccManager() labelWithAttributes:nil frame:_frame];
    _headerLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
    [_headerView addSubview:_headerLabel];
 
    return _headerView;
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONS
#pragma mark------------------------------------------------------------

- (void)editButtonAction
{
    LAAddPaymentTypeVC *_addPaymentVC=[[LAAddPaymentTypeVC alloc]init];
     _addPaymentVC.typeMode=PTEdit;
    UINavigationController *_navigationController=[[UINavigationController alloc]initWithRootViewController:_addPaymentVC];
    [ccManager() customizeNavigationBarWithAttributes:@{
                                                        kCCTintColor: COLOR_THEME_BROWN,
                                                        kCCBarTintColor:[UIColor whiteColor],
                                                        kCCTextColor:COLOR_THEME_BROWN,
                                                        kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                                                        }
                                 navigationController:_navigationController];
    [self presentViewController:_navigationController animated:YES completion:nil];
}

@end
