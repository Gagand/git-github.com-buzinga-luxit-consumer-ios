//
//  LATimeExtendVC.m
//  LUXit
//
//  Created by GP on 09/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "LATimeExtendVC.h"
#import "Constant.h"

@implementation LATimeExtendVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    [progressHud() hide];
    
    _blackOpaqueLayerView=[[UIView alloc]initWithFrame:self.view.bounds];
    _blackOpaqueLayerView.backgroundColor=[UIColor colorWithWhite:0.0 alpha:0.6];
    [self.view addSubview:_blackOpaqueLayerView];
    _blackOpaqueLayerView.alpha=0.0;
    
    
    CGRect _frame=_frame=CGRectMake(15.0, self.view.frame.size.height, self.view.frame.size.width-30.0, self.view.frame.size.height-200.0);
    if (_type==ETUponCancellation)
        _frame=CGRectMake(15.0, self.view.frame.size.height, self.view.frame.size.width-30.0, self.view.frame.size.height-160.0);
    _containerView=[[UIView alloc]initWithFrame:_frame];
    _containerView.backgroundColor=[UIColor whiteColor];
    _containerView.clipsToBounds=YES;
    [self.view addSubview:_containerView];
    
    _tableView=[[UITableView alloc]initWithFrame:_containerView.bounds style:UITableViewStylePlain];
    _tableView.delegate=self;
    _tableView.showsVerticalScrollIndicator=NO;
    _tableView.dataSource=self;
    _tableView.separatorColor=[UIColor clearColor];
    _tableView.backgroundColor=[UIColor clearColor];
    [_containerView addSubview:_tableView];
    
    _timeInterval=30;

}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self showContainerView];
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 6;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0)
    {
        return 70.0;
    }
    else if (indexPath.row==1)
    {
        if (_type==ETUponCancellation)
            return 110.0;
        else
            return 64.0;
    }
    else if (indexPath.row==2)
    {
        return 60.0;
    }
    else if (indexPath.row==3)
    {
        return 44.0;
    }
    else if (indexPath.row==4||indexPath.row==5)
    {
        return 60.0;
    }
    else
        return 0.0;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=[NSString stringWithFormat:@"%i_Row",(int)indexPath.row];
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.clipsToBounds=YES;
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        if (indexPath.row==0)
        {
           NSString *_titleString=@"LOOKING FOR A TECHNICIAN";
            if (_type==ETUponCancellation)
            {
                _titleString=[NSString stringWithFormat:@"%@ NO LONGER AVAILABLE",[appDelegate().jobDetail.technician.firstName uppercaseString]];
            }
            CGRect _frame=CGRectMake(10.0, 15.0, tableView.frame.size.width-20.0, 50.0);
            NSDictionary *_attributes;
            UILabel *_headerLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:3.5],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:_titleString,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0]
                          };
            [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
            
           [_cell.contentView addSubview:_headerLabel];
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_LIGHTPINK
                      ];
            
            _frame=CGRectMake(tableView.frame.size.width/2-12.0, 69.5, 24.0, 0.5);
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            _customLayer.alpha=0.8;
            [_cell.contentView addSubview:_customLayer];
        }
        else if (indexPath.row==1)
        {
            NSString *_textString=@"We’re currently looking for a technician, you have been placed in our VIP queue and will be notified ASAP.";
            if (_type==ETUponCancellation)
            {
               _textString=[NSString stringWithFormat:@"You have been credited $%i on your booking, as we're currently looking for a new technician for you, as %@ is no longer able to make your appointment. You have been placed in our VIP queue and will be notified ASAP.",(int)appDelegate().jobDetail.technicianCancellationFees,appDelegate().jobDetail.technician.firstName];
            }
            
    
            NSDictionary *_attributes=nil;
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_MEDIUM size:12.0],
                          kASText:_textString,
                          kASCharacterSpace:[NSNumber numberWithFloat:0.24]
                          };
            float _height=64.0;
            if (_type==ETUponCancellation)
                _height= 110.0;
 
            CGRect _frame=CGRectMake(15.0, 10.0, tableView.frame.size.width-30.0,_height);
            
            UILabel *_staticTextLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTextLabel.alpha=0.7;
            _staticTextLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_staticTextLabel];
        }
        
        else if (indexPath.row==2)
        {
            NSDictionary *_attributes=nil;
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_MEDIUM size:12.0],
                          kASText:@"How long would you like us to keep\nsearching for?",
                          kASCharacterSpace:[NSNumber numberWithFloat:0.24]
                          };
            
            CGRect _frame=CGRectMake(10.0, 0.0, tableView.frame.size.width-20.0,60.0);
            
            UILabel *_staticTextLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTextLabel.alpha=0.7;
            _staticTextLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_staticTextLabel];
        }
        else if (indexPath.row==3)
        {
            _cell.backgroundColor=COLOR_THEME_BROWN;
          
            _timePickerScrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0.0, 0.0, tableView.frame.size.width, 44.0)];
            _timePickerScrollView.showsHorizontalScrollIndicator=NO;
            _timePickerScrollView.showsVerticalScrollIndicator=NO;
            [_cell.contentView addSubview:_timePickerScrollView];
            
            NSArray *_itemsArray=@[
                                   @"15 mins",
                                   @"30 mins",
                                   @"45 mins",
                                   @"1 hr",
                                   @"1 hr 15 mins",
                                   @"1 hr 30 mins",
                                   @"1 hr 45 mins",
                                   @"2 hrs"
                                   ];
            float _width=_tableView.frame.size.width/3.0;
            for (int i=0; i<_itemsArray.count; i++)
            {
                NSDictionary *_attributes=nil;
                CGRect _frame;
                _attributes=@{
                              kCCBackgroundColor: COLOR_THEME_BROWN
                              };
                
                
                _attributes=@{
                              kCCTextColor: [UIColor whiteColor],
                              kCCText:[_itemsArray objectAtIndex:i],
                              kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_MEDIUM size:16.0],
                              kCCTag:[NSNumber numberWithInt:i+1]
                              };
                _frame=CGRectMake(i*_width, 0.0,_width,44.0);
                UIButton *_minsButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
                    [_selectedButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                    [sender setTitleColor:[UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0] forState:UIControlStateNormal];
                    _selectedButton=sender;
                    _timeInterval=(int)sender.tag*15;
                }];
                [_timePickerScrollView addSubview:_minsButton];
                if (i==1)
                {
                    _selectedButton=_minsButton;
                    [_minsButton setTitleColor:[UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0] forState:UIControlStateNormal];
                }
                
            }
            _timePickerScrollView.contentSize=CGSizeMake(_width *_itemsArray.count, _timePickerScrollView.frame.size.height);
            

           
        }
        else if (indexPath.row==4)
        {
            NSDictionary *_attributes=nil;
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_BROWN,
                      COLOR_THEME_LIGHTPINK
                      ];
            CGRect _frame=CGRectMake(16.0, 15, tableView.frame.size.width-32.0, 44.0);
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_customLayer];
            
            
            _frame=CGRectMake(_frame.origin.x+1.5, _frame.origin.y+1.5, _frame.size.width-3.0, _frame.size.height-3.0);
            
            _attributes=@{
                          kCCBackgroundColor:COLOR_THEME_DARKGRAY
                          };
            UIButton *_keepSearchingButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
                [self keepSerachingButtonAction];
            }];
            
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0],
                          kASText:@"KEEP SEARCHING",
                          kASCharacterSpace:[NSNumber numberWithFloat:1.35]
                          };
            
            NSMutableAttributedString *_attributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            
            [_keepSearchingButton setAttributedTitle:_attributedString forState:UIControlStateNormal];
            [_cell.contentView addSubview:_keepSearchingButton];
   
        }
        else  if (indexPath.row==5)
        {
            NSDictionary *_attributes=nil;
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_BROWN,
                      COLOR_THEME_LIGHTPINK
                      ];
            CGRect _frame=CGRectMake(16.0, 7.5, tableView.frame.size.width-32.0, 44.0);
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_customLayer];
            
            
            _frame=CGRectMake(_frame.origin.x+1.5, _frame.origin.y+1.5, _frame.size.width-3.0, _frame.size.height-3.0);
            
            _attributes=@{
                          kCCBackgroundColor:COLOR_THEME_DARKGRAY
                          };
            UIButton *_keepSearchingButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
                [self cancelJob];
            }];
            
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0],
                          kASText:@"CANCEL BOOKING",
                          kASCharacterSpace:[NSNumber numberWithFloat:1.35]
                          };
            
            NSMutableAttributedString *_attributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            
            [_keepSearchingButton setAttributedTitle:_attributedString forState:UIControlStateNormal];
            [_cell.contentView addSubview:_keepSearchingButton];
            
        }
    }
    return _cell;
}

- (void)showContainerView
{
    [UIView animateWithDuration:0.1 animations:^()
     {
         _blackOpaqueLayerView.alpha=1.0;
     }
                     completion:^(BOOL finished)
     {
         if (finished)
         {
             float _yoffset=(self.view.frame.size.height-_containerView.frame.size.height)/2.0;
             [UIView animateWithDuration:0.2 animations:^()
              {
                  _containerView.frame=CGRectMake(16.0, _yoffset, self.view.frame.size.width-32.0, _containerView.frame.size.height);
              } completion:nil];
         }
         
     }];
    
}

- (void)hideContainerView
{
    [UIView animateWithDuration:0.2 animations:^()
     {
         _containerView.frame=CGRectMake(16.0, self.view.frame.size.height, self.view.frame.size.width-32.0, _containerView.frame.size.height);
         
     }
                     completion:^(BOOL finished)
     {
         if (finished)
         {
             [UIView animateWithDuration:0.1 animations:^()
              {
                  _blackOpaqueLayerView.alpha=0.0;
              }
                              completion:^(BOOL finishded)
              {
                  if (finishded)
                  {
                      [self dismissViewControllerAnimated:NO completion:nil];
                  }
              }];
             
         }}];
}

- (void)keepSerachingButtonAction
{
    [progressHud() showWithTitle:@"Please wait"];
   
    NSDictionary *_attributes=nil;
    _attributes=@{
                  @"userId":appDelegate().userInfo.userId,
                  @"jobId":appDelegate().jobDetail.jobId,
                  @"duration":[NSString stringWithFormat:@"%i",_timeInterval]
                  };
    
    [API() extendJobTimeWithAttributes:_attributes completion:^(BOOL success,NSError *error)
    {
        [progressHud() hide];
       
        if (success)
        {
            NSDateFormatter *_dateFormatter=[[NSDateFormatter alloc]init];
            [_dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            
            NSMutableDictionary *_jobDetail=[NSMutableDictionary dictionaryWithDictionary:[[NSUserDefaults standardUserDefaults]objectForKey:@"LastJobDetail"]];
            [_jobDetail setObject:[NSString stringWithFormat:@"%i",_timeInterval] forKey:@"timeInterval"];
            [_jobDetail setObject:[_dateFormatter stringFromDate:[NSDate date]]  forKey:@"date"];
           
            [[NSUserDefaults standardUserDefaults]setObject:_jobDetail forKey:@"LastJobDetail"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            [appDelegate().jobDetail updateWithAttributes:_jobDetail];
            
            if (_finishedUpdatingJob)
            {
                _finishedUpdatingJob();
            }
            
            [self hideContainerView];
        }
        else
        {
            [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
        }
    }];
}


- (void)cancelJob
{
    [progressHud() showWithTitle:@"Please wait"];
    
    NSDictionary *_attributes=@{
                                @"userId":appDelegate().userInfo.userId,
                                @"jobId":appDelegate().jobDetail.jobId,
                                @"status":@"2",
                                @"comment":@""
                                };
    [API() cancelJobWithAttributes:_attributes completion:^(BOOL success,NSError *error, BOOL invalid){
        
        if (success)
        {
            if (!appDelegate().jobDetail.isPaidByPaypal)
            {
                [progressHud() hide];
            }
           
            [appDelegate().jobDetail resetJobDetails];
         
            if (_finishedCancellingJob)
            {
                _finishedCancellingJob();
            }
            
            [self hideContainerView];
        }
        else
        {
            if (invalid)
            {
                [progressHud() showWithTitle:@"Please wait"];
                
                NSDictionary *_attributes=@{
                                            @"userId":appDelegate().userInfo.userId
                                            };
                
                [API() fetchLastCreatedJobStatusWithAttributes:_attributes completion:^(BOOL success,NSError *error1)
                 {
                     [progressHud() hide];
                     
                     if (success)
                     {
                         if (_finishedUpdatingJob)
                         {
                             _finishedUpdatingJob();
                         }
                         
                         [self hideContainerView];
                     }
                     else
                     {
                         [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
                     }
                 }];
                return;
            }
          
            [progressHud() hide];
          
            [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
        }
    }];
}

@end
