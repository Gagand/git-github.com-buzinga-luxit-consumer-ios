//
//  LABookedTechinicanDetailVC.m
//  Luxit
//
//  Created by GP on 27/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//


#import "LABookedTechinicanDetailVC.h"
#import "LAUserHomeVC.h"
#import "LAParentViewController.h"
#import "Constant.h"

@implementation LABookedTechinicanDetailVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
  
    [progressHud() hide];
    
    _ratingStarImageviewsArray=[[NSMutableArray alloc]init];
   
    self.view.backgroundColor=[UIColor clearColor];
    
    self.navigationItem.hidesBackButton=YES;
    
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"Menu.png"] style:UIBarButtonItemStylePlain target:self action:@selector(menuButtonAction)];
    
    CGRect _frame=CGRectMake(0.0, 15.0, 190, 50.0);
    NSDictionary *_attributes;
    _attributes=@{
                  kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                  };
    UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
    
    
    _attributes=@{
                  kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                  kASTextColor:COLOR_THEME_BROWN,
                  kASText:[[appDelegate().jobDetail.itemName stringByReplacingOccurrencesOfString:@"\n" withString:@" "] uppercaseString],
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                  };
    [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
    
    self.navigationItem.titleView=_headerLabel;
    
    _frame=CGRectMake(0.0, 0.0,self.view.frame.size.width , 1.0);
    _attributes=@{
                  kCCImage:[UIImage imageNamed:@"seprator.png"]
                  };
    UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
    [self.view addSubview:_divider];
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_tableView==nil)
    {
        NSDictionary *_attributes=nil;
        _attributes=@{
                      kCCBackgroundColor:COLOR_THEME_BROWN
                      };
        CGRect _frame=CGRectMake(0.0, 0.0, self.view.frame.size.width, 22.0);
       
        UILabel *_staticEnRouteLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
        
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:0.52/2.0],
                      kASTextColor:[UIColor whiteColor],
                      kASText:@"En Route",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_BOLD size:13.0]
                      };
        
        _staticEnRouteLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
        
        [self.view addSubview:_staticEnRouteLabel];
        
        _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0.0, 22.0, self.view.frame.size.width, self.view.frame.size.height-43.5-22.0) style:UITableViewStylePlain];
        _tableView.delegate=self;
        _tableView.dataSource=self;
        _tableView.showsVerticalScrollIndicator=NO;
        _tableView.backgroundColor=[UIColor clearColor];
        _tableView.separatorColor=[UIColor clearColor];
        [self.view addSubview:_tableView];
        
        
        _frame=CGRectMake(0.0, self.view.frame.size.height-43.5, self.view.frame.size.width, 43.5);
        _attributes=@{
                      kCCBackgroundColor:COLOR_THEME_DARKGRAY
                      };
        UIButton *_continueButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
            [self cancelBookingButtonAction];
        }];
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:1.35],
                      kASTextColor:COLOR_THEME_BROWN,
                      kASText:@"CANCEL BOOKING",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0]
                      };
        [_continueButton setAttributedTitle:[NSMutableAttributedString attributedStringWithAttributes:_attributes] forState:UIControlStateNormal];
        [self.view addSubview:_continueButton];
        
        [self checkJobStatus];
    }
    else
    {
        [self checkJobStatus];
        [self performSelector:@selector(checkJobStatus) withObject:nil afterDelay:60.0];
    }
    
    appDelegate().updateAppStatus=^(AppStatus status){
        if (status==ASForeground)
        {
            [progressHud() showWithTitle:@"Please wait"];
            [self checkJobStatus];
        }
    };
}


- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(checkJobStatus) object:nil];
}


- (void)checkJobStatus
{
    NSDictionary *_attributes=@{
                                @"userId":appDelegate().userInfo.userId
                                };
    [API() fetchLastCreatedJobStatusWithAttributes:_attributes completion:^(BOOL success,NSError *error){
        [progressHud() hide];
        if (success)
        {
            if (appDelegate().jobDetail.changed)
            {
                [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(checkJobStatus) object:nil];
                [self.menuContainerViewController switchView];
            }
            
            else
            {
              [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(checkJobStatus) object:nil];
              [self performSelector:@selector(checkJobStatus) withObject:nil afterDelay:90.0];
               
                [_tableView reloadData];
            }
        }
        else
        {
            [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(checkJobStatus) object:nil];
            [self performSelector:@selector(checkJobStatus) withObject:nil afterDelay:90.0];
            
            [_tableView reloadData];
        }
       
    }];
}



#pragma mark------------------------------------------------------------
#pragma mark TABLEVIEW DELEGATE/ DATASOURCE
#pragma mark------------------------------------------------------------

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0)
    {
        return 320.0;
    }
    else
    {
        return 156.0;
    }
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=[NSString stringWithFormat:@"Cell_%i",(int)indexPath.row];
    
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
    
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        if (indexPath.row==0)
        {
            NSDictionary *_attributes=nil;
            
            CGRect _frame;
            _frame=CGRectMake(0.0, 9.5, tableView.frame.size.width, 13.0);

            UILabel *_staticSearchInfoLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.48/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"Your technician will be there within the hour",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0]
                          };
            _staticSearchInfoLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            _staticSearchInfoLabel.numberOfLines=2;
            [_cell.contentView addSubview:_staticSearchInfoLabel];
     
            
            _frame=CGRectMake(tableView.frame.size.width/2-12.0, _frame.origin.y+_frame.size.height+7.5, 24.0, 0.5);
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_LIGHTPINK
                      ];
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            _customLayer.alpha=0.8;
            [_cell.contentView addSubview:_customLayer];
            
            
            
            _frame=CGRectMake(tableView.frame.size.width/2-136.0/2.0, _frame.origin.y+_frame.size.height+24.0, 136.0, 136.0);
            _attributes=@{
                          kCCContentMode:[NSNumber numberWithInt:UIViewContentModeScaleAspectFill],
                          kCCImage:[UIImage imageNamed:@"Loading_Image.png"],
                          kCCCornerRadius:[NSNumber numberWithFloat:_frame.size.width/2.0]
                          };
            _profileImageView=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
            [_cell.contentView addSubview:_profileImageView];
            
            
  
            _frame=CGRectMake(10.0, _frame.origin.y+_frame.size.height+8.5, _tableView.frame.size.width-20.0, 17.0);
            UILabel *_techinicianNameLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:4.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:[appDelegate().jobDetail.technician.firstName uppercaseString],
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:16.0]
                          };
            _techinicianNameLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            
            [_cell.contentView addSubview:_techinicianNameLabel];

            CGFloat _yOffset=_frame.origin.y+_frame.size.height+11.5;
            CGFloat _xOffset=tableView.frame.size.width/2-(15*5)/2;
            
            [_ratingStarImageviewsArray removeAllObjects];
            for (int i=0; i<5; i++)
            {
                if (i>=appDelegate().jobDetail.technician.rating)
                {
                    _attributes =@{
                                   kCCImage:[UIImage imageNamed:@"Star_No_Fill.png"]
                                   };
                }
                else
                {
                    _attributes =@{
                                   kCCImage:[UIImage imageNamed:@"Star_Fill.png"]
                                   };
                }
                _frame=CGRectMake(_xOffset, _yOffset, 13.0, 13.0);
                UIImageView *_starImageView=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
                [_cell.contentView addSubview:_starImageView];
                _xOffset+=15.0;
                [_ratingStarImageviewsArray addObject:_starImageView];
            }
            
   
            _frame=CGRectMake(10.0, _yOffset+13.0+11.5, _tableView.frame.size.width-20.0, 20.0);
          
            UILabel *_techinicianPhoneNumberLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.48/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:appDelegate().jobDetail.technician.mobile,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_MEDIUM size:12.0],
                          kASIsUnderLine:@"YES"
                          };
            NSMutableAttributedString *_mobileNumberAttributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
  
            _techinicianPhoneNumberLabel.attributedText=_mobileNumberAttributedString;
            
            [_cell.contentView addSubview:_techinicianPhoneNumberLabel];
            
            [_cell.contentView addSubview:[ccManager() buttonWithAttributes:nil frame:_frame completion:^(UIButton *sender){
                [self phoneNumberButtonAction];
            }]];
        }
        
        else if (indexPath.row==1)
        {
            int numberOfRows=3;
            
            NSDictionary *_attributes=nil;
            
            CGRect _frame=CGRectMake(8.0, 0.0, tableView.frame.size.width-16.0, 132.0);
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_BROWN
                      ];
            
            CustomLayer*_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMVertical];
            [_cell.contentView addSubview:_customLayer];
            
            
            _attributes=@{
                          kCCBackgroundColor: [UIColor whiteColor]
                          };
            
            _frame=CGRectMake(_frame.origin.x+0.5, _frame.origin.y+0.5,_frame.size.width-1.0, _frame.size.height-1.0);
            UIView *_containerView=[ccManager() viewWithAttributes:_attributes frame:_frame];
            [_cell.contentView addSubview:_containerView];
            
            
            
            [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, _containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.5)]];
            
            [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, 2*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.5)]];
            
            
            _frame=CGRectMake(16.0, 0.0, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"DATE",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticDateLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticDateLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticDateLabel];
            
            
            
            _attributes=@{
                          kCCText: appDelegate().jobDetail.dateString,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            
            _frame=CGRectMake(16.0, _containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"TIME",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticTimeLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTimeLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticTimeLabel];
            
            
            _attributes=@{
                          kCCText: appDelegate().jobDetail.timeString,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            _timeLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
            [_containerView addSubview:_timeLabel];
            
            
            _frame=CGRectMake(16.0, 2*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"ADDRESS",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticAddressLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticAddressLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticAddressLabel];
            
            _frame=CGRectMake(90.0, 2*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-105.0, _containerView.frame.size.height/numberOfRows);
            
            _attributes=@{
                          kCCText: appDelegate().jobDetail.location,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
        }
    }

    if (indexPath.row==0)
    {
       [self getAndSetprofileImageForTechnician];
      
        int i=0;
        for (UIImageView *_starImageView in _ratingStarImageviewsArray)
        {
            if (i>=appDelegate().jobDetail.technician.rating)
            {
                _starImageView.image=[UIImage imageNamed:@"Star_No_Fill.png"];
            }
            else
            {
                _starImageView.image=[UIImage imageNamed:@"Star_Fill.png"];
            }
            i++;
        }
  
    }
    
    if (indexPath.row==1)
    {
        _timeLabel.text=appDelegate().jobDetail.timeString;
    }
    return _cell;
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONS
#pragma mark------------------------------------------------------------

- (void)menuButtonAction
{
    [self.menuContainerViewController openSideMenu];
}


- (void)cancelBookingButtonAction
{
    LACancelBookingPopoverVC *_cancelBookingPopoverVC=[[LACancelBookingPopoverVC alloc]init];
    _cancelBookingPopoverVC.finishedCancellingBooking=^()
    {
        LACancellationReceiptVC *_cancellationReceiptVC=[[LACancellationReceiptVC alloc]init];
        [self.navigationController pushViewController:_cancellationReceiptVC animated:NO];
        [UIView transitionWithView:appDelegate().window duration:0.25 options:UIViewAnimationOptionTransitionCrossDissolve animations:nil completion:nil];
    };
    _cancelBookingPopoverVC.view.backgroundColor = [UIColor clearColor];
    _cancelBookingPopoverVC.providesPresentationContextTransitionStyle = YES;
    [_cancelBookingPopoverVC setModalPresentationStyle:UIModalPresentationOverCurrentContext];
    [self.navigationController presentViewController:_cancelBookingPopoverVC animated:NO completion:nil];
}


- (void)phoneNumberButtonAction
{
    UIActionSheet *_actionSheet=[[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"SMS",@"Call", nil];
    [_actionSheet showInView:self.view];
}


- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex==0)
    {
        [self showMessageController];
    }
    else if (buttonIndex==1)
    {
        [self call];
    }
}


- (void)showMessageController
{
    if(![MFMessageComposeViewController canSendText])
    {
        [ccManager() showAlertWithTitle:@"Error" message:@"Your device doesn't support SMS!" buttons:nil completion:nil];
        return;
    }
    
    NSArray *_recipents = @[appDelegate().jobDetail.technician.mobile];

    MFMessageComposeViewController *_messageController = [[MFMessageComposeViewController alloc] init];
    _messageController.messageComposeDelegate = self;
    [_messageController setRecipients:_recipents];
    [self presentViewController:_messageController animated:YES completion:nil];
}


- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult) result
{
    switch (result)
    {
        case MessageComposeResultCancelled:
        {
            break;
        }
        case MessageComposeResultFailed:
        {
           [ccManager() showAlertWithTitle:@"Error" message:@"Failed to send SMS!" buttons:nil completion:nil];
            break;
        }
        case MessageComposeResultSent:
        {
            break;
        }
        default:
        {
            break;
        }
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (void)call
{
    NSURL *_phoneUrl = [NSURL URLWithString:[NSString  stringWithFormat:@"telprompt://%@",appDelegate().jobDetail.technician.mobile]];
    [[UIApplication sharedApplication] openURL:_phoneUrl];
}


- (void)getAndSetprofileImageForTechnician
{
    _profileImageView.contentMode=UIViewContentModeScaleAspectFill;
    
    if (appDelegate().jobDetail.technician.imagePath.length==0)
    {
        _profileImageView.image=[UIImage imageNamed:@"Loading_Image.png"];
        return;
    }
   
    NSString *_imagePath=[NSString stringWithFormat:IMAGEURL,appDelegate().jobDetail.technician.imagePath];
    NSString *_documentImageFileName=_imagePath;
    _documentImageFileName = [_documentImageFileName stringByReplacingOccurrencesOfString:@".jpg" withString:@""];
    _documentImageFileName = [_documentImageFileName stringByReplacingOccurrencesOfString:@".png" withString:@""];
    
    NSArray *_componentsArray=[_documentImageFileName componentsSeparatedByString:@"/"];
  
    if (_componentsArray.count>0)
    {
        _documentImageFileName=[_componentsArray lastObject];
    }
    
    UIImage *_image=[UIImage imageWithContentsOfFile:[[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:[NSString stringWithFormat:@"Images/%@.png",_documentImageFileName]]];
    
    if (_image)
    {
        _profileImageView.image=_image;
    }
    else
    {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^(void)
        {
            NSData *_imgData = [NSData dataWithContentsOfURL:[NSURL URLWithString:_imagePath]];
           
            UIImage *__image = [UIImage imageWithData:_imgData];
          
            NSString *_fileName=[[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:[NSString stringWithFormat:@"Images/%@.png",_documentImageFileName]];
           
            [_imgData writeToFile:_fileName atomically:YES];
           
            dispatch_sync(dispatch_get_main_queue(), ^(void)
            {
                if (__image!=nil)
                {
                     _profileImageView.image=__image;
                }
            });
        });
    }
    
    
}
@end
