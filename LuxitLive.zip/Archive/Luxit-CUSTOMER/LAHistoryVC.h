//
//  LAHistoryVC.h
//  Luxit
//
//  Created by GP on 24/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Job.h"

@interface LAHistoryVC :  UIViewController<UITableViewDataSource,UITableViewDelegate,UIPickerViewDataSource,UIPickerViewDelegate>
{
    UITableView             *_tableView;
    NSMutableArray          *_monthsArray;
    NSMutableArray          *_yearsArray;
    NSMutableArray          *_itemsArray;
    
    UIPickerView            *_pickerView;
    BOOL                     _isPickerVisible;
    UILabel                 *_dateLabel;
    UIImageView             *_arrowImageView;
    UILabel                 *_errorLabel;
    NSDateFormatter         *_dateFormatter;
   
    NSString                *_lastSavedMonthString;
    NSString                *_lastSavedYearString;
}

@end
