//
//  LAMyDetailsVC.m
//  Luxit
//
//  Created by GP on 24/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "LAMyDetailsVC.h"
#import "Constant.h"
#import "LAParentViewController.h"

@implementation LAMyDetailsVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    [self.menuContainerViewController disablePan];
    
    CGRect _frame=CGRectMake(0.0, 15.0, 190, 50.0);
    NSDictionary *_attributes;
    _attributes=@{
                  kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                  };
    UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];

    _attributes=@{
                  kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                  kASTextColor:COLOR_THEME_BROWN,
                  kASText:@"MY DETAILS",
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                  };
    [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
    
    self.navigationItem.titleView=_headerLabel;
   
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"Home.png"] style:UIBarButtonItemStylePlain target:self action:@selector(homeButtonAction)];
    
    _frame=CGRectMake(0.0, 0.0,self.view.frame.size.width , 1.0);
    _attributes=@{
                  kCCImage:[UIImage imageNamed:@"seprator.png"]
                  };
    UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
    [self.view addSubview:_divider];
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_tableView==nil)
    {
        _tableView=[[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.delegate=self;
        _tableView.dataSource=self;
        _tableView.backgroundColor=[UIColor clearColor];
        _tableView.separatorColor=[UIColor clearColor];
        [self.view addSubview:_tableView];
    }
}


#pragma mark------------------------------------------------------------
#pragma mark UITABLEVIEW DELEGATE/ DATASOURCE
#pragma mark------------------------------------------------------------

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 58.0;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=[NSString stringWithFormat:@"Cell_%i",(int)indexPath.row];
    
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
    
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        _cell.clipsToBounds=YES;
        
        NSString *_textString=@"";
        if (indexPath.row==0)
        {
            _textString=@"PAYMENT METHOD";
        }
        else if (indexPath.row==1)
        {
            _textString=@"CHANGE PASSWORD";
        }
        else if (indexPath.row==2)
        {
            _textString=@"HISTORY";
        }
        
        NSDictionary *_attributes;
        _attributes=@{
                      kASTextColor: COLOR_THEME_BROWN,
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0],
                      kASText:_textString,
                      kASCharacterSpace:[NSNumber numberWithFloat:3.5],
                      kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                      };
        
        NSMutableAttributedString *_attributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
        _cell.textLabel.attributedText=_attributedString;
        
        
        if (indexPath.row==0||indexPath.row==1)
        {
            NSArray *_colors=nil;
            _colors=@[COLOR_THEME_BROWN,
                      COLOR_THEME_LIGHTPINK
                      ];
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:CGRectMake(16.0, 57.5, 24.0, 0.5) withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_customLayer];
        }
    }
    
    return _cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0) {
        LAPaymentMethodsVC *_paymentMethodsVC=[[LAPaymentMethodsVC alloc]init];
        self.navigationItem.backBarButtonItem=[[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
        [self.navigationController pushViewController:_paymentMethodsVC animated:YES];
    }
    else if (indexPath.row==1)
    {
        if (appDelegate().userInfo.isFacebookUser)
        {
            [ccManager() showAlertWithTitle:@"Facebook" message:@"You are logged in with your Facebook account. Please go to the Facebook website to change your password." buttons:@[@"OK"] completion:nil];
            return;
        }
        
        LAChangePasswordVC *_changePasswordVC=[[LAChangePasswordVC alloc]init];
        self.navigationItem.backBarButtonItem=[[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
        [self.navigationController pushViewController:_changePasswordVC animated:YES];
    }
    else if (indexPath.row==2)
    {
        LAHistoryVC *_historyVC=[[LAHistoryVC alloc]init];
        self.navigationItem.backBarButtonItem=[[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
        [self.navigationController pushViewController:_historyVC animated:YES];
    }
}


- (void)homeButtonAction
{
    [self.menuContainerViewController enablePan];
   
    [self.navigationController popViewControllerAnimated:YES];
}
@end
