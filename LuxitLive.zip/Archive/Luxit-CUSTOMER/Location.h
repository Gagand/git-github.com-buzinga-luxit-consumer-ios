//
//  Location.h
//  Luxit
//
//  Created by GP on 07/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Location : NSObject

@property (nonatomic, assign) BOOL isLocatioAvailable;
@property (nonatomic, retain) NSString *address;
@property (nonatomic, assign) double lat;
@property (nonatomic, assign) double lng;
@property (nonatomic, retain) NSString *postalCode;

- (void)updateWithAttributes:(NSDictionary *)attributes;
- (void)updatePostalCode:(NSString *)postalCode;

@end
