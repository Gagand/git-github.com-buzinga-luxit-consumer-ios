//
//  LAPlaceOrderVC.m
//  Luxit
//
//  Created by GP on 27/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "LAPlaceOrderVC.h"
#import "Constant.h"

@implementation LAPlaceOrderVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [appDelegate() enablePushNotification];
    
    _dateFormatter=[[NSDateFormatter alloc]init];
    
    _blackOpaqueLayerView=[[UIView alloc]initWithFrame:self.view.bounds];
    _blackOpaqueLayerView.backgroundColor=[UIColor colorWithWhite:0.0 alpha:0.6];
    [self.view addSubview:_blackOpaqueLayerView];
    _blackOpaqueLayerView.alpha=0.0;
    
    _containerView=[[UIView alloc]initWithFrame:CGRectMake(16.0, self.view.frame.size.height, self.view.frame.size.width-32.0, self.view.frame.size.height-90.0)];
    _containerView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:_containerView];
    
    _tableView=[[UITableView alloc]initWithFrame:_containerView.bounds style:UITableViewStylePlain];
    _tableView.backgroundColor=[UIColor clearColor];
    _tableView.separatorColor=[UIColor clearColor];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    _tableView.showsVerticalScrollIndicator=NO;
    [_containerView addSubview:_tableView];

    NSDictionary *_attributes=nil;
    _attributes=@{
                  kCCImage: [UIImage imageNamed:@"Close.png"]
                  };
  
    CGRect _frame=CGRectMake(0.0, 0.0, 40.0, 40.0);
   
    [_containerView addSubview:[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
        [self closeButtonAction];
    }]];
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
   
    [self showContainerView];
}


- (void)showContainerView
{
    [UIView animateWithDuration:0.1 animations:^()
    {
        _blackOpaqueLayerView.alpha=1.0;
    }
    completion:^(BOOL finished)
    {
        if (finished)
        {
            [UIView animateWithDuration:0.2 animations:^()
             {
                _containerView.frame=CGRectMake(16.0, 56.0, self.view.frame.size.width-32.0, self.view.frame.size.height-90);
             } completion:nil];
        }
    }];
}


#pragma mark------------------------------------------------------------
#pragma mark TABLEVIEW DELEGATE/ DATASOURCE
#pragma mark------------------------------------------------------------

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 6;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0)
    {
        return 174.5;
    }
    else if (indexPath.row==1)
    {
        return 132.0;
    }
    else if (indexPath.row==2)
    {
        return 40.0;
    }
    else if (indexPath.row==3)
    {
        return 30.0;
    }
    else if (indexPath.row==4)
    {
        return 55.0;
    }
    else
    {
        return 50.0;
    }
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=[NSString stringWithFormat:@"%i",(int)indexPath.row];
   
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
   
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        _cell.clipsToBounds=YES;
        
        if (indexPath.row==0)
        {
            
            CGRect _frame=CGRectMake(tableView.frame.size.width/2-85.0/2.0, 31.0, 85.0, 85.0);
            
            NSDictionary *_attributes=nil;
            _attributes=@{
                          kCCImage:[UIImage imageNamed:@"Cost_Frame.png"]
                          };
            [_cell.contentView addSubview:[ccManager() imageViewWithAttributes:_attributes frame:_frame]];
            
            
            _attributes=@{
                          kCCText: [NSString stringWithFormat:@"$%i",(int)_menuItem.amount],
                          kCCTextColor:COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:16.0],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                          };
            [_cell.contentView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            

            _frame=CGRectMake(10.0, _frame.origin.y+_frame.size.height+14.5, tableView.frame.size.width-20.0, 14.0);

            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0],
                          kASText:[[_menuItem.name stringByReplacingOccurrencesOfString:@"\n" withString:@" "] uppercaseString],
                          kASCharacterSpace:[NSNumber numberWithFloat:3.5]
                          };
            UILabel *_itemNameLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _itemNameLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_itemNameLabel];
            
            _frame=CGRectMake(tableView.frame.size.width/2-12.0, _frame.origin.y+_frame.size.height+15, 24.0, 0.5);
            
            NSArray *_colors=nil;
            _colors=@[
                     COLOR_THEME_LIGHTPINK,
                     COLOR_THEME_LIGHTPINK
                      ];
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            _customLayer.alpha=0.8;
            [_cell.contentView addSubview:_customLayer];
            
        }
        
        else if (indexPath.row==1)
        {
            int numberOfRows=3;
            
            NSDictionary *_attributes=nil;
           
            CGRect _frame=CGRectMake(8.0, 0.0, tableView.frame.size.width-16.0, 132.0);
          
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_BROWN
                      ];
            
            CustomLayer*_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMVertical];
            [_cell.contentView addSubview:_customLayer];
            
 
            _attributes=@{
                          kCCBackgroundColor: [UIColor whiteColor]
                          };
            
            _frame=CGRectMake(_frame.origin.x+0.5, _frame.origin.y+0.5,_frame.size.width-1.0, _frame.size.height-1.0);
            UIView *_cellContainerView=[ccManager() viewWithAttributes:_attributes frame:_frame];
            [_cell.contentView addSubview:_cellContainerView];
            
            [_cellContainerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, _cellContainerView.frame.size.height/numberOfRows, _cellContainerView.frame.size.width, 0.5)]];
            
            [_cellContainerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, 2*_cellContainerView.frame.size.height/numberOfRows, _cellContainerView.frame.size.width, 0.5)]];
            
            
            _attributes=@{
                          kCCText: @"DATE",
                          kCCTextColor:COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                          };
            _frame=CGRectMake(10.0, 0.0, tableView.frame.size.width-16.0, _cellContainerView.frame.size.height/numberOfRows);
            [_cellContainerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            _attributes=@{
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            _frame=CGRectMake(120.0, 0.0, _cellContainerView.frame.size.width-120.0, _cellContainerView.frame.size.height/numberOfRows);
          
            [_dateFormatter setDateFormat:@"MMMM dd, yyyy"];
            
            _dateTF=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
            [_cell.contentView addSubview:_dateTF];
            _dateTF.text=[_dateFormatter stringFromDate:[NSDate date]];
            _dateTF.enabled=NO;

            _attributes=@{
                          kCCText: @"TIME",
                          kCCTextColor:COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                          };
            _frame=CGRectMake(10.0, _cellContainerView.frame.size.height/numberOfRows, tableView.frame.size.width-20.0, _cellContainerView.frame.size.height/numberOfRows);
            [_cellContainerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            
            _attributes=@{
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            _frame=CGRectMake(120.0, _cellContainerView.frame.size.height/numberOfRows, _cellContainerView.frame.size.width-120.0, _cellContainerView.frame.size.height/numberOfRows);
           
            [_dateFormatter setDateFormat:@"HH:mm"];
            
            _timeTF=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
            [_cell.contentView addSubview:_timeTF];
            _timeTF.text=[_dateFormatter stringFromDate:[NSDate date]];
            _timeTF.enabled=NO;
            
            _attributes=@{
                          kCCText: @"ADDRESS",
                          kCCTextColor:COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                          };
            _frame=CGRectMake(10.0, 2*_cellContainerView.frame.size.height/numberOfRows, tableView.frame.size.width-20.0, _cellContainerView.frame.size.height/numberOfRows);
            [_cellContainerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            _attributes=@{
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            _frame=CGRectMake(120.0, 2*_cellContainerView.frame.size.height/numberOfRows, _cellContainerView.frame.size.width-120.0, _cellContainerView.frame.size.height/numberOfRows);
            _addressTF=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
            [_cell.contentView addSubview:_addressTF];
            _addressTF.enabled=NO;
            _addressTF.text=appDelegate().userInfo.location.address;
   
        }
        
        else if (indexPath.row==2)
        {
            NSDictionary *_attributes=nil;

            CGRect _frame=CGRectMake(10.0, 0.0, tableView.frame.size.width-20.0,40.0);
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0],
                          kASText:@"PAYING BY",
                          kASCharacterSpace:[NSNumber numberWithFloat:1.4],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticTextLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTextLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_staticTextLabel];
            
            NSString *_paymentMethodName=@"";
            
            if (appDelegate().userInfo.paymentMode.type==PTCreditCard)
            {
                _paymentMethodName=[NSString stringWithFormat:@"xxxx %@",[appDelegate().userInfo.paymentMode.cardNumber substringWithRange:NSMakeRange(appDelegate().userInfo.paymentMode.cardNumber.length-4, 4)]];
            }
            else
            {
                if (appDelegate().userInfo.paymentMode.email.length>16)
                {
                    _paymentMethodName=[NSString stringWithFormat:@"%@...",[appDelegate().userInfo.paymentMode.email substringToIndex:14]];
                }
                else
                {
                    _paymentMethodName=appDelegate().userInfo.paymentMode.email;
                }
            }
            
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:14.0],
                          kASText:_paymentMethodName,
                          kASCharacterSpace:[NSNumber numberWithFloat:0.354],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
             _frame=CGRectMake(100.0, 9.0, tableView.frame.size.width-110.0,20.0);
            UILabel *_paymentMethodInfoLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _paymentMethodInfoLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_paymentMethodInfoLabel];
        }
        
        else if (indexPath.row==3)
        {
            NSDictionary *_attributes=nil;
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0],
                          kASText:@"Please allow up to an hour for your technician\nto arrive",
                          kASCharacterSpace:[NSNumber numberWithFloat:0.24]
                          };

            CGRect _frame=CGRectMake(10.0, -5.0, tableView.frame.size.width-20.0,35.0);
          
            UILabel *_staticTextLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTextLabel.alpha=0.8;
            _staticTextLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_staticTextLabel];

        }
        
        else if (indexPath.row==4)
        {
            NSDictionary *_attributes=nil;
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_BROWN,
                      COLOR_THEME_LIGHTPINK
                      ];
            CGRect _frame=CGRectMake(16.0, 7.5, tableView.frame.size.width-32.0, 44.0);
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_customLayer];
            
            
            _frame=CGRectMake(_frame.origin.x+1.5, _frame.origin.y+1.5, _frame.size.width-3.0, _frame.size.height-3.0);
            
            _attributes=@{
                          kCCBackgroundColor:COLOR_THEME_DARKGRAY
                          };
            UIButton *_registerButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
                [self confirmBookingButtonAction];
            }];
            
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0],
                          kASText:@"CONFIRM BOOKING",
                          kASCharacterSpace:[NSNumber numberWithFloat:1.35]
                          };
            
            NSMutableAttributedString *_attributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            
            [_registerButton setAttributedTitle:_attributedString forState:UIControlStateNormal];
            [[_registerButton titleLabel] setNumberOfLines:0];
            [[_registerButton titleLabel] setLineBreakMode:NSLineBreakByWordWrapping];
            [_cell.contentView addSubview:_registerButton];
        }
        
        else if (indexPath.row==5)
        {
            NSDictionary *_attributes;
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:11.5],
                          kASText:@"By confirming your booking you agree to the\n",
                          kASCharacterSpace:[NSNumber numberWithFloat:0.24]
                          };
            NSMutableAttributedString *_attributedSting = [[NSMutableAttributedString alloc] init];
            
            [_attributedSting appendAttributedString:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
            
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_BOLD size:11.5],
                          kASText:@"Terms and Conditions ",
                          kASCharacterSpace:[NSNumber numberWithFloat:0.24]
                          };
            
            [_attributedSting appendAttributedString:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
            
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:11.5],
                          kASText:@"and ",
                          kASCharacterSpace:[NSNumber numberWithFloat:0.24]
                          };
            [_attributedSting appendAttributedString:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
            
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_BOLD size:11.5],
                          kASText:@"Privacy Policy.",
                          kASCharacterSpace:[NSNumber numberWithFloat:0.24]
                          };
            
            [_attributedSting appendAttributedString:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
            
            CGRect _frame=CGRectMake(8.0, 0.0, tableView.frame.size.width-16.0,35.0);
            UILabel *_label=[ccManager() labelWithAttributes:nil frame:_frame];
            [_label setAttributedText:_attributedSting];
            [_cell.contentView addSubview:_label];
            
            _frame=CGRectMake(0.0, 0.0, self.view.frame.size.width/2.0,35.0);
            [_cell.contentView addSubview:[ccManager() buttonWithAttributes:nil frame:_frame completion:^(UIButton *sender){
                
                LATermsAndConditionsVC *_termsAndConditionVC=[[LATermsAndConditionsVC alloc]init];
                
                UINavigationController *_navigationController=[[UINavigationController alloc]initWithRootViewController:_termsAndConditionVC];
                
                NSDictionary *_attributes=nil;
                _attributes=@{
                              kCCTintColor: COLOR_THEME_BROWN,
                              kCCBarTintColor:[UIColor whiteColor],
                              kCCTextColor:COLOR_THEME_BROWN,
                              kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                              };
                
                [ccManager() customizeNavigationBarWithAttributes:_attributes navigationController:_navigationController];
                
                
                [self presentViewController:_navigationController animated:YES completion:nil];
            }]];
            
            _frame=CGRectMake(self.view.frame.size.width/2.0, 0.0, self.view.frame.size.width/2.0,35.0);
            [_cell.contentView addSubview:[ccManager() buttonWithAttributes:nil frame:_frame completion:^(UIButton *sender){
                LAPrivacyPolicyVC *_termsAndConditionVC=[[LAPrivacyPolicyVC alloc]init];
                UINavigationController *_navigationController=[[UINavigationController alloc]initWithRootViewController:_termsAndConditionVC];
                
                NSDictionary *_attributes=nil;
                _attributes=@{
                              kCCTintColor: COLOR_THEME_BROWN,
                              kCCBarTintColor:[UIColor whiteColor],
                              kCCTextColor:COLOR_THEME_BROWN,
                              kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                              };
                
                [ccManager() customizeNavigationBarWithAttributes:_attributes navigationController:_navigationController];
                
                
                [self presentViewController:_navigationController animated:YES completion:nil];
            }]];
        }
    }
    
    return _cell;
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONS
#pragma mark------------------------------------------------------------

- (void)confirmBookingButtonAction
{
    if (appDelegate().userInfo.location.postalCode.length==0)
    {
        [progressHud() showWithTitle:@"Please wait"];
        [API() fetchPostalCodeForAddress:appDelegate().userInfo.location.address completion:^(BOOL success, NSString *postalCode)
        {
            if (success)
            {
                [appDelegate().userInfo.location updatePostalCode:postalCode];
                [self confirmBookingButtonAction];
            }
            else
            {
                [progressHud() showWithTitle:[NSString stringWithFormat:@"Error\nFail to create booking at this time. Please try again later."]];
                
                [self performSelector:@selector(hideProgessHud:) withObject:[NSNumber numberWithBool:success] afterDelay:2.0];
            }
        }];
        
        return;
    }

    
    NSDictionary *_attributes=@{
                                @"userId":appDelegate().userInfo.userId,
                                @"menuId":_menuItem.ID,
                                @"location":appDelegate().userInfo.location.address,
                                @"postalCode":appDelegate().userInfo.location.postalCode
                                };
    
    [progressHud() showWithTitle:@"Please wait"];
    
    [API() createJobWithAttributes:_attributes completion:^(BOOL success, NSError *error,NSString *jobId,NSString *customerPayableAmount)
     {
         if (success)
         {
             [progressHud() hide];
            
             [_dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
             
             NSMutableDictionary *_jobDetail=[NSMutableDictionary dictionaryWithCapacity:10];
             [_jobDetail setObject:jobId forKey:@"id"];
             [_jobDetail setObject:_menuItem.name forKey:@"itemName"];
             [_jobDetail setObject:[NSString stringWithFormat:@"%f",_menuItem.amount] forKey:@"itemPrice"];
             [_jobDetail setObject:@"0" forKey:@"isPaid"];
             [_jobDetail setObject:customerPayableAmount forKey:@"customerPayablePrice"];
             
             if (appDelegate().userInfo.paymentMode.type==PTPaypal)
             {
                 [_jobDetail setObject:@"1" forKey:@"transationType"];
                 [_jobDetail setObject:@"" forKey:@"transactionId"];
                 [_jobDetail setObject:@"10" forKey:@"status"];
             }
             else
             {
                 [_jobDetail setObject:@"0" forKey:@"transationType"];
                 [_jobDetail setObject:@"" forKey:@"transactionId"];
                 [_jobDetail setObject:@"0" forKey:@"status"];
             }
           
             [_jobDetail setObject:@"5" forKey:@"timeInterval"];
             [_jobDetail setObject:appDelegate().userInfo.location.address forKey:@"location"];
             [_jobDetail setObject:[NSMutableDictionary dictionaryWithCapacity:0]  forKey:@"technician"];
             [_jobDetail setObject:[_dateFormatter stringFromDate:[NSDate date]]  forKey:@"date"];
             [_jobDetail setObject:@"No"  forKey:@"paid"];
             [_jobDetail setObject:@"0" forKey:@"cancellationFees"];
             [_jobDetail setObject:@"0" forKey:@"technicianCancellationFees"];
             
             [[NSUserDefaults standardUserDefaults]setObject:_jobDetail forKey:@"LastJobDetail"];
             [[NSUserDefaults standardUserDefaults]synchronize];
             
             [appDelegate().jobDetail updateWithAttributes:_jobDetail];
            
             appDelegate().jobDetail.changed=YES;
             
             if (_finishedConfirmingBooking)
             {
                 _finishedConfirmingBooking();
             }
             
             
             if (appDelegate().userInfo.paymentMode.type==PTCreditCard && appDelegate().jobDetail.isDicounted)
             {
                 NSString *_titleString=@"Congratulation";
                 NSString *_messageString=[NSString stringWithFormat:@"You are getting $%i discount on your service. Now you have to pay $%i.",(int)appDelegate().jobDetail.discountedValue,(int)appDelegate().jobDetail.customerPayablePrice];
                 
                 if (appDelegate().jobDetail.isFree)
                 {
                     _messageString=[NSString stringWithFormat:@"This is a free service from LUXit"];
                 }
                 
                 [ccManager() showAlertWithTitle:_titleString message:_messageString buttons:nil completion:nil];
             }
             
             
             [self dismissViewControllerAnimated:NO completion:nil];
         }
         else
         {

            [progressHud() showWithTitle:[NSString stringWithFormat:@"%@\n%@",[[error userInfo] objectForKey:@"title"],[[error userInfo] objectForKey:@"description"]]];
           
             [self performSelector:@selector(hideProgessHud:) withObject:[NSNumber numberWithBool:success] afterDelay:2.0];
         }
     }];
}


- (void)closeButtonAction
{
    [UIView animateWithDuration:0.2 animations:^()
     {
         _containerView.frame=CGRectMake(16.0, self.view.frame.size.height, self.view.frame.size.width-32.0, self.view.frame.size.height-104.0);
     }
     completion:^(BOOL finished)
     {
         if (finished)
         {
             [UIView animateWithDuration:0.1 animations:^()
              {
                   _blackOpaqueLayerView.alpha=0.0;
              }
              completion:^(BOOL finishded)
              {
                  if (finishded)
                  {
                      [self dismissViewControllerAnimated:NO completion:nil];
                  }
              }];
         }}];
}


- (void)hideProgessHud:(NSNumber *)success
{
    [progressHud() hide];
}

@end
