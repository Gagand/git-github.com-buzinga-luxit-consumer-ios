//
//  PaypalManager.m
//  LUXit
//
//  Created by GP on 16/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "PaypalManager.h"

#import <QuartzCore/QuartzCore.h>

#define kPayPalEnvironment  PayPalEnvironmentProduction
#define kProductionClientId @"AXLjPvGdfLzYLWxdXkNqHwrRWV-C7bKH5LbjyQmNPRnx1UJb1d04ASa0HKkir9xsw1G_nwNp4kMekcDx"
#define kSandBoxClientId    @"AdT76LU-UpnWMZ9WwYV2pkC4PKavLtNfqw3UMudpjdgQxUsLRbeqt_hzQy_WDm8t4wComG8MlORoOOPa"

#define kAPIUsername        @"info_api1.luxit.me"
#define kAPIPassword        @"9R8YN8DSWATR4GNK"
#define kAPISignature       @"AxryNv.Kng-cPfTOaYoJaaXbBJcoAn-UsBO9picQwmwxWOdP1IDo4ED8"


#define kPaypalClientId     @"AXLjPvGdfLzYLWxdXkNqHwrRWV-C7bKH5LbjyQmNPRnx1UJb1d04ASa0HKkir9xsw1G_nwNp4kMekcDx"
#define kPaypalSecretKey    @"ENCN3yQN5wWSEDvlvR475A5aqt4Jzw7S2sp5vVE_2XVjW7C3KMM2v9ba6pMEljkYBhZoCpfbxwcTc3CV"

#define kCurrencyCode       @"AUD"

//luxit@paypal.com
//admin@123

@implementation PaypalManager

#pragma mark- Singleton

static PaypalManager * _sharedManager = nil;

+(PaypalManager *)singleton
{
    @synchronized([PaypalManager class])
    {
		if (!_sharedManager)
        {
            _sharedManager=[[self alloc] init];
        }
		return _sharedManager;
	}
	return nil;
}


+(id)alloc
{
	@synchronized([PaypalManager class])
    {
		_sharedManager = [super alloc];
		
        return _sharedManager;
	}
	return nil;
}


-(id)init
{
	self = [super init];
	if (self != nil)
    {
        [PayPalMobile initializeWithClientIdsForEnvironments:@{
                                                               PayPalEnvironmentProduction : kProductionClientId,
                                                               PayPalEnvironmentSandbox    : kSandBoxClientId
                                                               }];
        
        // Set up payPalConfig
        _payPalConfig = [[PayPalConfiguration alloc] init];
        _payPalConfig.acceptCreditCards = YES;
        _payPalConfig.languageOrLocale  = @"en";
        _payPalConfig.merchantName      = @"LUXit";
        _payPalConfig.merchantPrivacyPolicyURL = [NSURL URLWithString:@"https://www.paypal.com/webapps/mpp/ua/privacy-full"];
        _payPalConfig.merchantUserAgreementURL = [NSURL URLWithString:@"https://www.paypal.com/webapps/mpp/ua/useragreement-full"];
        _payPalConfig.languageOrLocale = [NSLocale preferredLanguages][0];
        _payPalConfig.payPalShippingAddressOption = PayPalShippingAddressOptionPayPal;
         self.environment = kPayPalEnvironment;
        [PayPalMobile preconnectWithEnvironment:self.environment];
	}
	return self;
}


- (void)payForJobDetail:(JobDetail*)jobDetail
{
    _jobDetail=jobDetail;
    
    NSDictionary *_paymentInfo=[[NSUserDefaults standardUserDefaults]objectForKey:@"PaypalInfo"];
    
    if (_paymentInfo==NULL)
    {
        [self callPaypalController];
    }
    else
    {
        if ([[_paymentInfo objectForKey:@"isTransactionIdfetched"]boolValue])
        {
            if (_finishedPayingByPaypal)
            {
                _finishedPayingByPaypal([_paymentInfo objectForKey:@"transactionId"],TSPaid);
            }
        }
        else
        {
            [self fetchTransactionIdForOrderId:[_paymentInfo objectForKey:@"orderId"] appId:[_paymentInfo objectForKey:@"appId"]];
        }
    }
}


- (void)callPaypalController
{
    double _itemPrice=0.0;
    
    JobStatus _jobStatus=_jobDetail.status;
   
    if (_jobStatus==JSCancelledUnpaid)
    {
        _itemPrice=_jobDetail.cancellationFees;
    }
    else
    {
        _itemPrice=_jobDetail.customerPayablePrice;
    }

    PayPalItem *item1 = [PayPalItem
                         itemWithName:[_jobDetail.itemName stringByReplacingOccurrencesOfString:@"\n" withString:@" "]
                         withQuantity:1
                         withPrice:[NSDecimalNumber decimalNumberWithString:[[NSNumber numberWithDouble:_itemPrice]stringValue]]
                         withCurrency:kCurrencyCode
                         withSku:@"Hip-00037"];
    
    NSArray *items = @[item1];
    NSDecimalNumber *subtotal = [PayPalItem totalPriceForItems:items];

    NSDecimalNumber *shipping   = [[NSDecimalNumber alloc] initWithString:@"0.0"];
    NSDecimalNumber *tax        = [[NSDecimalNumber alloc] initWithString:@"0.0"];
    PayPalPaymentDetails *paymentDetails = [PayPalPaymentDetails paymentDetailsWithSubtotal:subtotal
                                                                               withShipping:shipping
                                                                                    withTax:tax];
    
    NSDecimalNumber *total = [[subtotal decimalNumberByAdding:shipping] decimalNumberByAdding:tax];
    
    PayPalPayment *payment = [[PayPalPayment alloc] init];
    payment.amount = total;
    payment.currencyCode     = kCurrencyCode;
    payment.shortDescription = @"LUXit";
    payment.items = items;
    payment.paymentDetails = paymentDetails;

    self.payPalConfig.acceptCreditCards = YES;
    
    _paymentViewController = [[PayPalPaymentViewController alloc] initWithPayment:payment
                                                                                                configuration:self.payPalConfig
                                                                                                     delegate:self];
    [appDelegate().window.rootViewController presentViewController:_paymentViewController animated:YES completion:nil];
}


- (void)makePaymentWithAmount:(float)amount completion:(void(^)(NSString *,TransactionStatus))completion
{
    _finishedPayingByPaypal=[completion copy];
    
    PayPalItem *item1 = [PayPalItem
                         itemWithName:[_jobDetail.itemName stringByReplacingOccurrencesOfString:@"\n" withString:@" "]
                         withQuantity:1
                         withPrice:[NSDecimalNumber decimalNumberWithString:[[NSNumber numberWithDouble:amount]stringValue]]
                         withCurrency:kCurrencyCode
                         withSku:@"Hip-00037"];
    
    NSArray *items = @[item1];
    NSDecimalNumber *subtotal = [PayPalItem totalPriceForItems:items];
    
    NSDecimalNumber *shipping   = [[NSDecimalNumber alloc] initWithString:@"0.0"];
    NSDecimalNumber *tax        = [[NSDecimalNumber alloc] initWithString:@"0.0"];
    PayPalPaymentDetails *paymentDetails = [PayPalPaymentDetails paymentDetailsWithSubtotal:subtotal
                                                                               withShipping:shipping
                                                                                    withTax:tax];
    
    NSDecimalNumber *total = [[subtotal decimalNumberByAdding:shipping] decimalNumberByAdding:tax];
    
    PayPalPayment *payment = [[PayPalPayment alloc] init];
    payment.amount = total;
    payment.currencyCode     = kCurrencyCode;
    payment.shortDescription = @"LUXit";
    payment.items = items;
    payment.paymentDetails = paymentDetails;
    
    self.payPalConfig.acceptCreditCards = YES;
    
    _paymentViewController = [[PayPalPaymentViewController alloc] initWithPayment:payment
                                                                    configuration:self.payPalConfig
                                                                         delegate:self];
    [appDelegate().window.rootViewController presentViewController:_paymentViewController animated:YES completion:nil];
    
}


#pragma mark PayPalPaymentDelegate methods

- (void)payPalPaymentViewController:(PayPalPaymentViewController *)paymentViewController didCompletePayment:(PayPalPayment *)completedPayment
{
    NSDictionary *_dictionary=[completedPayment.confirmation objectForKey:@"proof_of_payment"];
   
    NSArray *_keys=[_dictionary allKeys];
    
    if ([_keys containsObject:@"adaptive_payment"])
    {
        NSString *_orderId=[[[completedPayment.confirmation objectForKey:@"proof_of_payment"]objectForKey:@"adaptive_payment"]objectForKey:@"pay_key"];
    
        NSString *_appID=[[[completedPayment.confirmation objectForKey:@"proof_of_payment"]objectForKey:@"adaptive_payment"]objectForKey:@"app_id"];

        NSMutableDictionary *_paymentDictionary=[NSMutableDictionary dictionaryWithCapacity:4];
        [_paymentDictionary setObject:_orderId forKey:@"orderId"];
        [_paymentDictionary setObject:_appID forKey:@"appId"];
        [_paymentDictionary setObject:@"NO" forKey:@"isTransactionIdfetched"];
        [_paymentDictionary setObject:@"" forKey:@"transactionId"];
        [[NSUserDefaults standardUserDefaults]setObject:_paymentDictionary forKey:@"PaypalInfo"];
        [[NSUserDefaults standardUserDefaults]synchronize];
       
        [self fetchTransactionIdForOrderId:_orderId appId:_appID];
      
        [_paymentViewController dismissViewControllerAnimated:YES completion:nil];
    }
    else
    {
        NSString *_orderId=[[completedPayment.confirmation objectForKey:@"response"]objectForKey:@"id"];
        
        NSMutableDictionary *_paymentDictionary=[NSMutableDictionary dictionaryWithCapacity:4];
        [_paymentDictionary setObject:_orderId forKey:@"orderId"];
        [_paymentDictionary setObject:@"" forKey:@"appId"];
        [_paymentDictionary setObject:@"YES" forKey:@"isTransactionIdfetched"];
        [_paymentDictionary setObject:_orderId forKey:@"transactionId"];
        [[NSUserDefaults standardUserDefaults]setObject:_paymentDictionary forKey:@"PaypalInfo"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        if (_finishedPayingByPaypal)
        {
            _finishedPayingByPaypal(_orderId,TSPaid);
        }
        
        [_paymentViewController dismissViewControllerAnimated:NO completion:nil];
     
    }
}

- (void)payPalPaymentDidCancel:(PayPalPaymentViewController *)paymentViewController
{
    if (_finishedPayingByPaypal)
    {
        _finishedPayingByPaypal(nil,TSCancelled);
    }
    [paymentViewController dismissViewControllerAnimated:NO completion:nil];
}


- (void)fetchTransactionIdForOrderId:(NSString *)orderId appId:(NSString *)appId
{
   [progressHud() showWithTitle:@"Please wait"];
    
    NSString *api_username=kAPIUsername;
   
    NSString *api_password=kAPIPassword;
   
    NSString *api_signature=kAPISignature;
   
    NSURL *_url       = [NSURL URLWithString:[NSString stringWithFormat:@"https://svcs.paypal.com/AdaptivePayments/PaymentDetails"]];
   
    NSString *_params = [NSString stringWithFormat:@"payKey=%@&requestEnvelope.errorLanguage=%@",orderId,@"en_US"];
   
    NSString *_msgLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_params length]];
   
    NSMutableURLRequest *_request=[NSMutableURLRequest requestWithURL:_url];
   
    [_request setHTTPMethod:@"POST"];
   
    [_request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
   
    [_request setValue: _msgLength forHTTPHeaderField:@"Content-Length"];
    
    [_request setHTTPBody: [_params dataUsingEncoding:NSUTF8StringEncoding]];
    
    [_request setValue:api_username forHTTPHeaderField:@"X-PAYPAL-SECURITY-USERID"];
   
    [_request setValue:api_password forHTTPHeaderField:@"X-PAYPAL-SECURITY-PASSWORD"];
   
    [_request setValue:api_signature forHTTPHeaderField:@"X-PAYPAL-SECURITY-SIGNATURE"];
   
    [_request setValue:@"NV" forHTTPHeaderField:@"X-PAYPAL-REQUEST-DATA-FORMAT"];
   
    [_request setValue:@"JSON" forHTTPHeaderField:@"X-PAYPAL-RESPONSE-DATA-FORMAT"];
  
    [_request setValue:appId forHTTPHeaderField:@"X-PAYPAL-APPLICATION-ID"];
    
    [NSURLConnection sendAsynchronousRequest:_request  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             [self fetchTransactionIdForOrderId:orderId appId:appId];
         }
         else
         {
             NSDictionary *_jsonDictionary=[NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:nil];
             
             if ([[_jsonDictionary allKeys]containsObject:@"paymentInfoList"]) {
                 
                 if ([[[_jsonDictionary objectForKey:@"paymentInfoList"]objectForKey:@"paymentInfo"]isKindOfClass:[NSDictionary class]])
                 {
                     [self fetchTransactionIdForOrderId:orderId appId:appId];
                 }
                 else
                 {
                     NSArray *_tempPaymentArray=[[_jsonDictionary objectForKey:@"paymentInfoList"]objectForKey:@"paymentInfo"];
                    
                     if (_tempPaymentArray.count>0)
                     {
                         NSMutableDictionary *_paymentDictionary=[NSMutableDictionary dictionaryWithDictionary:[[NSUserDefaults standardUserDefaults]objectForKey:@"PaypalInfo"]];
                         [_paymentDictionary setObject:@"YES" forKey:@"isTransactionIdfetched"];
                         [_paymentDictionary setObject:[[_tempPaymentArray objectAtIndex:0]objectForKey:@"senderTransactionId"] forKey:@"transactionId"];
                         
                         [[NSUserDefaults standardUserDefaults]setObject:_paymentDictionary forKey:@"PaypalInfo"];
                         [[NSUserDefaults standardUserDefaults]synchronize];
                         
                         if (_finishedPayingByPaypal)
                         {
                             _finishedPayingByPaypal([[_tempPaymentArray objectAtIndex:0]objectForKey:@"senderTransactionId"],TSPaid);
                         }
                     }
                     else
                     {
                        [self fetchTransactionIdForOrderId:orderId appId:appId];
                     }
                 }
             }
         }
     }];
}



- (void)refundAmount:(float)amount forPaykey:(NSString *)payKey completion:(void(^)(NSString *,TransactionStatus))completion
{
    _finishedPayingByPaypal=[completion copy];
    
    NSString *_strClientIdAndSecretKey=[NSString stringWithFormat:@"%@:%@",kPaypalClientId,kPaypalSecretKey];
  
    NSData * _credential = [_strClientIdAndSecretKey  dataUsingEncoding:NSUTF8StringEncoding];
   
    NSString *_credentialString = [_credential base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithCarriageReturn];
    
    NSURL *_url = [NSURL URLWithString:[NSString stringWithFormat:@"https://api.paypal.com/v1/oauth2/token"]];
  
    NSMutableURLRequest *_request=[NSMutableURLRequest requestWithURL:_url];
  
    [_request addValue:@"application/json" forHTTPHeaderField:@"Accept"];
   
    [_request addValue:@"en_US" forHTTPHeaderField:@"Accept-Language"];
   
    [_request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    
    [_request setValue:[NSString stringWithFormat:@"Basic %@",_credentialString] forHTTPHeaderField:@"Authorization"];
    
    NSString *parameterString = [NSString stringWithFormat:@"grant_type=client_credentials"];
    
    NSString *msgLength = [NSString stringWithFormat:@"%d", [parameterString length]];
    
    [_request addValue: msgLength forHTTPHeaderField:@"Content-Length"];
    
    [_request setHTTPMethod:@"POST"];
    
    [_request setHTTPBody:[parameterString dataUsingEncoding:NSUTF8StringEncoding]];
    
    
    [NSURLConnection sendAsynchronousRequest:_request  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             if (_finishedPayingByPaypal)
             {
                 _finishedPayingByPaypal(nil,TSError);
             }
         }
         else
         {
             NSDictionary *_jsonDictionary=[NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:nil];
             
             if (_jsonDictionary.allKeys.count>0)
             {
                 NSString *_appId=[_jsonDictionary objectForKey:@"app_id"];
                 
                 NSString *_token=[_jsonDictionary objectForKey:@"access_token"];
                 
                 if (_appId.length>0 && _token.length>0)
                 {
                      [self getTransactionId:_appId payKey:payKey token:_token amount:amount];
                 }
                 else
                 {
                     if (_finishedPayingByPaypal)
                     {
                         _finishedPayingByPaypal(nil,TSError);
                     }
                 }
             }
             else
             {
                 if (_finishedPayingByPaypal)
                 {
                     _finishedPayingByPaypal(nil,TSError);
                 }
             }
         }
     }];
}


- (void)getTransactionId:(NSString *)appKey payKey:(NSString *)payKey token:(NSString *)token amount:(float)amount
{
    NSURL *_url = [NSURL URLWithString:[NSString stringWithFormat:@"https://api.paypal.com/v1/payments/payment/%@",payKey]];
  
    NSMutableURLRequest *_request=[NSMutableURLRequest requestWithURL:_url];
   
    [_request addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    [_request addValue:@"en_US" forHTTPHeaderField:@"Accept-Language"];
    
    [_request setValue:@"application/json;charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
    
    [_request setValue:[NSString stringWithFormat:@"Bearer %@",token] forHTTPHeaderField:@"Authorization"];
    
    [_request setHTTPMethod:@"GET"];
    
    
    [NSURLConnection sendAsynchronousRequest:_request  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error)
    {
         if (error)
         {
             if (_finishedPayingByPaypal)
             {
                 _finishedPayingByPaypal(nil,TSError);
             }
         }
         else
         {
             NSDictionary *_jsonDictionary=[NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:nil];
             
             if (_jsonDictionary.allKeys.count>0)
             {
                 if ([_jsonDictionary.allKeys containsObject:@"transactions"])
                 {
                       NSString *_transactionId=[[[[[(NSArray *)[_jsonDictionary objectForKey:@"transactions"] objectAtIndex:0]objectForKey:@"related_resources"]objectAtIndex:0]objectForKey:@"sale"]objectForKey:@"id"];
                    
                     [self refundTransaction:_transactionId token:token amount:amount];
                 }
                 else
                 {
                     if (_finishedPayingByPaypal)
                     {
                         _finishedPayingByPaypal(nil,TSError);
                     }
                 }
             }
             else
             {
                 if (_finishedPayingByPaypal)
                 {
                     _finishedPayingByPaypal(nil,TSError);
                 }
             }
         }
     }];
}


- (void)refundTransaction:(NSString *)transactionId token:(NSString *)token amount:(float)amount
{
    NSDictionary *_amount=@{
                             @"currency":@"AUD",
                             @"total":[NSString stringWithFormat:@"%.2f",amount]
                            };
    
    NSDictionary *_jsonDict=@{
                                @"amount":_amount,
                              };

    NSError     *_error = nil;
   
    NSData      *_jsonData   = [NSJSONSerialization dataWithJSONObject:_jsonDict options:NSJSONWritingPrettyPrinted error:&_error];
   
    NSString    *jsonString = [[NSString alloc] initWithData:_jsonData encoding:NSUTF8StringEncoding];
    
    NSURL *_url = [NSURL URLWithString:[NSString stringWithFormat:@"https://api.paypal.com/v1/payments/sale/%@/refund",transactionId]];
   
    NSMutableURLRequest *_request=[NSMutableURLRequest requestWithURL:_url];
    [_request addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [_request addValue:@"en_US" forHTTPHeaderField:@"Accept-Language"];
    [_request setValue:@"application/json;charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
    [_request setValue:[NSString stringWithFormat:@"Bearer %@",token] forHTTPHeaderField:@"Authorization"];
    
    [_request setHTTPMethod:@"POST"];
    [_request setHTTPBody:[jsonString dataUsingEncoding:NSUTF8StringEncoding]];
    [_request setValue: [NSString stringWithFormat:@"%lu", (unsigned long)[jsonString length]] forHTTPHeaderField:@"Content-Length"];
    
    [NSURLConnection sendAsynchronousRequest:_request  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error)
    {
         if (error)
         {
             if (_finishedPayingByPaypal)
             {
                 _finishedPayingByPaypal(nil,TSError);
             }
         }
         else
         {
             NSDictionary *_jsonDictionary=[NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:nil];

             if (_jsonDictionary.allKeys.count>0)
             {
                 if ([_jsonDictionary.allKeys containsObject:@"id"])
                 {
                     [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"RefundInfo"];
                     [[NSUserDefaults standardUserDefaults]synchronize];
                     
                     if (_finishedPayingByPaypal)
                     {
                         _finishedPayingByPaypal(nil,TSPaid);
                     }
                 }
                 else
                 {
                     if ([[_jsonDictionary objectForKey:@"message"]isEqualToString:@"The request was refused.{0}"])
                     {
                         [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"RefundInfo"];
                         [[NSUserDefaults standardUserDefaults]synchronize];
                         
                         if (_finishedPayingByPaypal)
                         {
                             _finishedPayingByPaypal(nil,TSPaypalError);
                         }
                     }
                     else
                     {
                         if (_finishedPayingByPaypal)
                         {
                             _finishedPayingByPaypal(nil,TSError);
                         }
                     }
                 }
             }
             else
             {
                 if (_finishedPayingByPaypal)
                 {
                     _finishedPayingByPaypal(nil,TSError);
                 }
             }
         }
     }];
}

@end

PaypalManager *paypalManager(void)
{
    return [PaypalManager singleton];
}
