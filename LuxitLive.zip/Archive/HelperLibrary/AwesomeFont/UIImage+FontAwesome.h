//
//  UIImage+UIImage_FontAwesome.h
//  Luxit
//
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (FontAwesome)

+(UIImage*)imageWithIcon:(NSString*)identifier backgroundColor:(UIColor*)bgColor iconColor:(UIColor*)iconColor andSize:(CGSize)size;
+(UIImage*)imageWithIcon:(NSString*)identifier backgroundColor:(UIColor*)bgColor iconColor:(UIColor*)iconColor fontSize:(int)fontSize;

@end
