//
//  eWAYHelper.h
//  LUXit
//
//  Created by GP on 23/12/15.
//  Copyright © 2015 LUXit. All rights reserved.
//

//  4386280019671613
//  01/17
//  864


typedef enum
{
    eWAYStatusInvalidCardDetails,
    eWAYStatusError,
    eWAYStatusAuthenticationFailure,
    eWAYStatusSuccess
}eWAYStatus;


#import <Foundation/Foundation.h>
#import "CardInfo.h"

@interface eWAYHelper : NSObject

@property (nonatomic, copy)   void(^finishedAddingCardDetail)(eWAYStatus, NSString *);
@property (nonatomic, retain) CardInfo *cardInfo;

+ (eWAYHelper *)singleton;

- (void)registerCardForCustomerTokenWithCardInfo:(CardInfo *)cardInfo Completion:(void(^)(eWAYStatus,NSString*))completion;

- (void)chargeToken:(NSString *)token withAmount:(float)amount completion:(void(^)(eWAYStatus,NSString*))completion;

- (void)refundTransactionForId:(NSString *)transactionId amount:(float)amount completion:(void(^)(eWAYStatus,NSString*))completion;

@end

eWAYHelper *eWayHelper(void);
