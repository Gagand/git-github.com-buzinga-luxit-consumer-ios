//
//  eWAYHelper.m
//  LUXit
//
//  Created by GP on 23/12/15.
//  Copyright © 2015 LUXit. All rights reserved.
//

#import "eWAYHelper.h"

#define keWAYPublicAppKey    @"epk-0A6FC37D-675E-47E1-A88D-6FD78028339B"
#define keWAYAppKey          @"60CF3Ain6J4SNjWOD0bZxiYdIxo/sv2U6ZQlCUeMlMaFTwD6654Y7Z+8539VcWAgZRCkfX"
#define keWAYAppPassword     @"9p8a2ro0"

#define keWAYSandboxEndPoint @"https://api.sandbox.ewaypayments.com/"
#define keWAYLiveEndPoint    @"https://api.ewaypayments.com/"

@implementation eWAYHelper

#pragma mark- Singleton

static eWAYHelper * _sharedManager = nil;


+(eWAYHelper *)singleton
{
    @synchronized([eWAYHelper class])
    {
        if (!_sharedManager)
        {
            _sharedManager=[[self alloc] init];
        }
        return _sharedManager;
    }
    return nil;
}


+(id)alloc
{
    @synchronized([eWAYHelper class])
    {
        _sharedManager = [super alloc];
       
        return _sharedManager;
    }
    return nil;
}


-(id)init
{
    self = [super init];
    if (self != nil)
    {

    }
    return self;
}

/***
 TO GENERATE CUSTOMER TOKEN
 FIRST ENCRYPT CARD NUMBER AND CVV
 THEN SEND THESE ENCRYPTED VALUES ALONG WITH OTHER INFO TO GENRATE TOKEN
**/

- (void)registerCardForCustomerTokenWithCardInfo:(CardInfo *)cardInfo Completion:(void(^)(eWAYStatus,NSString*))completion
{
    _cardInfo=cardInfo;
    
    _finishedAddingCardDetail=[completion copy];
   
    if (_cardInfo.cardNumber.length>0)
    {
        [self registerCardDetails];
    }
    else
    {
        if (completion)
        {
            completion(eWAYStatusInvalidCardDetails,nil);
        }
    }
}


- (void)registerCardDetails
{
    NSDictionary *_cardNumberInfo=@{
                                    @"Name":@"Card",
                                    @"Value":_cardInfo.cardNumber
                                    };
    NSDictionary *_cardCVVInfo=@{
                                 @"Name":@"CVN",
                                 @"Value":_cardInfo.cvv
                                 };
    
    NSDictionary *_jsonDict=@{
                              @"Method": @"eCrypt",
                              @"Items":@[_cardNumberInfo,_cardCVVInfo]
                              };
    
    NSError     *writeError = nil;
    NSData      *jsonData   = [NSJSONSerialization dataWithJSONObject:_jsonDict options:NSJSONWritingPrettyPrinted error:&writeError];
    NSString    *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    NSString    *authStr    = [NSString stringWithFormat:@"%@:%@", keWAYPublicAppKey, @""];
    NSData      *authData   = [authStr dataUsingEncoding:NSUTF8StringEncoding];
    NSString    *authValue  = [NSString stringWithFormat:@"Basic %@", [authData base64EncodedStringWithOptions:0]];
    
    NSString* userAgent = @"Mozilla/6.0 (iPhone; CPU iPhone OS 8_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/8.0 Mobile/10A5376e Safari/8536.25;eWAY SDK iOS 1.1";
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@/encrypt",keWAYLiveEndPoint]]];

    [request setValue:authValue forHTTPHeaderField:@"Authorization"];
    
    [request setHTTPMethod:@"POST"];
    
    [request setValue:userAgent forHTTPHeaderField:@"User-Agent"];
    
    [request setValue:@"application/json;charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:[jsonString dataUsingEncoding:NSUTF8StringEncoding]];
    
    [request setValue: [NSString stringWithFormat:@"%lu", (unsigned long)[jsonString length]] forHTTPHeaderField:@"Content-Length"];
    
    
    [NSURLConnection sendAsynchronousRequest:request  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error)
    {
         if (error)
         {
             if (_finishedAddingCardDetail)
             {
                 _finishedAddingCardDetail(eWAYStatusError,nil);
             }
         }
         else{
             
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
           
             NSArray *_itemsArray=[_dictionary objectForKey:@"Items"];
           
             NSString *_cardNumber=@"";
           
             NSString *_cvvNumber=@"";
             
             for (NSDictionary *_dict in _itemsArray) {
                 if ([[_dict objectForKey:@"Name"]isEqualToString:@"Card"])
                 {
                     _cardNumber=[_dict objectForKey:@"Value"];
                 }
                 else if ([[_dict objectForKey:@"Name"]isEqualToString:@"CVN"])
                 {
                     _cvvNumber=[_dict objectForKey:@"Value"];;
                 }
             }
             if (_cardNumber.length>0 && _cvvNumber.length>0)
             {
                 _cardInfo.encryptedCardNumber=_cardNumber;
                 _cardInfo.encryptedCVVNumber=_cvvNumber;
               
                 [self saveCardToGenerateCustomerToken];
             }
             else
             {
                 if (_finishedAddingCardDetail)
                 {
                     _finishedAddingCardDetail(eWAYStatusAuthenticationFailure,nil);
                 }
             }
         }
     }];
}


- (void)saveCardToGenerateCustomerToken
{
    NSDictionary *__cardAttributes=@{
                                     @"Name":_cardInfo.cardHolderName,
                                     @"Number":_cardInfo.encryptedCardNumber,
                                     @"ExpiryMonth":_cardInfo.expiryMonth,
                                     @"ExpiryYear":_cardInfo.expiryYear,
                                     @"CVN":_cardInfo.encryptedCVVNumber
                                     };
    
    NSDictionary *_cardDetails=@{
                                 @"CardDetails":__cardAttributes,
                                 @"FirstName":_cardInfo.firstName,
                                 @"LastName":_cardInfo.lastName,
                                 @"Country":@"au",
                                 @"Title":@""
                                 };
    
    NSDictionary *_amount=@{
                            @"TotalAmount":@"0"
                            };
    
    NSDictionary *_jsonDict=@{
                              @"TransactionType":@"Purchase",
                              @"Method": @"CreateTokenCustomer",
                              @"Payment":_amount,
                              @"Customer":_cardDetails
                              };
    
    NSError     *writeError = nil;
    NSData      *jsonData   = [NSJSONSerialization dataWithJSONObject:_jsonDict options:NSJSONWritingPrettyPrinted error:&writeError];
    NSString    *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    NSString    *authStr    = [NSString stringWithFormat:@"%@:%@", keWAYAppKey, keWAYAppPassword];
    NSData      *authData   = [authStr dataUsingEncoding:NSUTF8StringEncoding];
    NSString    *authValue  = [NSString stringWithFormat:@"Basic %@", [authData base64EncodedStringWithOptions:0]];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@Transaction",keWAYLiveEndPoint]]];
    
    [request setValue:authValue forHTTPHeaderField:@"Authorization"];
    
    [request setHTTPMethod:@"POST"];

    [request setValue:@"application/json;charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:[jsonString dataUsingEncoding:NSUTF8StringEncoding]];
    
    [request setValue: [NSString stringWithFormat:@"%lu", (unsigned long)[jsonString length]] forHTTPHeaderField:@"Content-Length"];
    
    
    [NSURLConnection sendAsynchronousRequest:request  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             if (_finishedAddingCardDetail)
             {
                 _finishedAddingCardDetail(eWAYStatusError,nil);
             }
         }
         else{
             
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
          
             if ((NSNull *)[_dictionary objectForKey:@"Errors"]!=[NSNull null])
             {
                 if (_finishedAddingCardDetail)
                 {
                     _finishedAddingCardDetail(eWAYStatusAuthenticationFailure,nil);
                 }
                 return;
             }
             
            
             
             NSString *_customerTokenId=[NSString stringWithFormat:@"%lli",[[[_dictionary  objectForKey:@"Customer"]objectForKey:@"TokenCustomerID"]longLongValue]];;
             
             if (_customerTokenId.length>0)
             {
                 if (_finishedAddingCardDetail)
                 {
                     _finishedAddingCardDetail(eWAYStatusSuccess,_customerTokenId);
                 }
             }
             else
             {
                 if (_finishedAddingCardDetail)
                 {
                     _finishedAddingCardDetail(eWAYStatusAuthenticationFailure,nil);
                 }
             }
         }
     }];
}


- (void)chargeToken:(NSString *)token withAmount:(float)amount completion:(void(^)(eWAYStatus,NSString*))completion
{
    NSDictionary *_tokenInfo=@{
                               @"TokenCustomerID":token
                               };
    
    NSDictionary *_amount=@{
                            @"TotalAmount":@(amount)
                            };
    
    NSDictionary *_jsonDict=@{
                              @"TransactionType":@"MOTO",
                              @"Method": @"TokenPayment",
                              @"Payment":_amount,
                              @"Customer":_tokenInfo
                              };
    
    NSError     *writeError = nil;
    NSData      *jsonData   = [NSJSONSerialization dataWithJSONObject:_jsonDict options:NSJSONWritingPrettyPrinted error:&writeError];
    NSString    *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    NSString    *authStr    = [NSString stringWithFormat:@"%@:%@", keWAYAppKey, keWAYAppPassword];
    NSData      *authData   = [authStr dataUsingEncoding:NSUTF8StringEncoding];
    NSString    *authValue  = [NSString stringWithFormat:@"Basic %@", [authData base64EncodedStringWithOptions:0]];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"https://api.ewaypayments.com/Transaction"]]];
    
    [request setValue:authValue forHTTPHeaderField:@"Authorization"];
    
    [request setHTTPMethod:@"POST"];

    [request setValue:@"application/json;charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:[jsonString dataUsingEncoding:NSUTF8StringEncoding]];
    
    [request setValue: [NSString stringWithFormat:@"%lu", (unsigned long)[jsonString length]] forHTTPHeaderField:@"Content-Length"];
    
    
    [NSURLConnection sendAsynchronousRequest:request  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error)
    {
         if (error)
         {
             if (_finishedAddingCardDetail)
             {
                 _finishedAddingCardDetail(eWAYStatusError,nil);
             }
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
          
             NSString *_transactionId=@"";
             
             if ((NSNull *)[_dictionary objectForKey:@"Errors"]==[NSNull null])
             {
                 _transactionId= [NSString stringWithFormat:@"%lli",[[_dictionary  objectForKey:@"TransactionID"]longLongValue]];
             }

             if (_transactionId.length>0)
             {
                 if (_finishedAddingCardDetail)
                 {
                     _finishedAddingCardDetail(eWAYStatusSuccess,_transactionId);
                 }
             }
             else
             {
                 if (_finishedAddingCardDetail)
                 {
                     _finishedAddingCardDetail(eWAYStatusAuthenticationFailure,nil);
                 }
             }
         }
     }];
}


- (void)refundTransactionForId:(NSString *)transactionId amount:(float)amount completion:(void(^)(eWAYStatus,NSString*))completion
{
    _finishedAddingCardDetail=[completion copy];
    NSDictionary *_amount=@{
                            @"TotalAmount":@(amount)
                            };
    
    NSDictionary *_jsonDict=@{
                              @"Refund":_amount
                              };
    
    NSError     *writeError = nil;
    NSData      *jsonData   = [NSJSONSerialization dataWithJSONObject:_jsonDict options:NSJSONWritingPrettyPrinted error:&writeError];
    NSString    *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    NSString    *authStr    = [NSString stringWithFormat:@"%@:%@", keWAYAppKey, keWAYAppPassword];
    NSData      *authData   = [authStr dataUsingEncoding:NSUTF8StringEncoding];
    NSString    *authValue  = [NSString stringWithFormat:@"Basic %@", [authData base64EncodedStringWithOptions:0]];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"https://api.ewaypayments.com/Transaction/%@/Refund",transactionId]]];
    
    [request setValue:authValue forHTTPHeaderField:@"Authorization"];
    
    [request setHTTPMethod:@"POST"];
    
    [request setValue:@"application/json;charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:[jsonString dataUsingEncoding:NSUTF8StringEncoding]];
    
    [request setValue: [NSString stringWithFormat:@"%lu", (unsigned long)[jsonString length]] forHTTPHeaderField:@"Content-Length"];
    
    
    
    [NSURLConnection sendAsynchronousRequest:request  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             if (_finishedAddingCardDetail)
             {
                 _finishedAddingCardDetail(eWAYStatusError,nil);
             }
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];

             if ((NSNull *)[_dictionary objectForKey:@"Errors"]==[NSNull null])
             {
                 if (_finishedAddingCardDetail)
                 {
                     _finishedAddingCardDetail(eWAYStatusSuccess,nil);
                 }
             }
             else
             {
                 if (_finishedAddingCardDetail)
                 {
                     _finishedAddingCardDetail(eWAYStatusAuthenticationFailure,nil);
                 }
             }
         }
     }];
}

@end

eWAYHelper *eWayHelper(void){
    return [eWAYHelper singleton];
}
