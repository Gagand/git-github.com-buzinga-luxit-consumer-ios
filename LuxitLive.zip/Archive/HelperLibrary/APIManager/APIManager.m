//
//  APIManager.m
//  Luxit
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "APIManager.h"

@implementation APIManager

- (void)loginWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_email=[attributes objectForKey:@"email"];
   
    NSString *_password=[attributes objectForKey:@"password"];
   
    NSString *_deviceToken=[attributes objectForKey:@"deviceToken"];
   
    NSString *_deviceType=[attributes objectForKey:@"deviceType"];
  
    NSString *_userType=[attributes objectForKey:@"userType"];
   
    NSString *_fbid=@"";
    
    NSCharacterSet *set = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ0123456789"];
    
    NSString *encodedEmail = [_email stringByAddingPercentEncodingWithAllowedCharacters:set];
    NSString *encodedPassword = [_password stringByAddingPercentEncodingWithAllowedCharacters:set];
    
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL,LOGIN_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"email=%@&password=%@&device_token=%@&device_type=%@&usertype=%@&fbid=%@",encodedEmail,encodedPassword,_deviceToken,_deviceType,_userType,_fbid];

    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error)
    {
         if (error)
         {
             NSError*_error=nil;
            
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
           
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
       
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 NSMutableDictionary *_userInfoDictionary=[NSMutableDictionary dictionaryWithDictionary:[[_dictionary objectForKey:@"message"]objectForKey:@"User"]];
                
                 if ([[_userInfoDictionary objectForKey:@"role_id"]intValue]==2)
                 {
                     if ([[[_dictionary objectForKey:@"message"]objectForKey:@"PaymentInfo"]isKindOfClass:[NSDictionary class]])
                     {
                        
                         NSDictionary *_paymentMethodInfo=[[_dictionary objectForKey:@"message"]objectForKey:@"PaymentInfo"];
                        
                         if (_paymentMethodInfo.allKeys.count>0)
                         {
                            [_userInfoDictionary setObject:_paymentMethodInfo forKey:@"paymentInfo"];
                         }
                         else
                         {
                           [_userInfoDictionary setObject:[NSMutableDictionary dictionaryWithCapacity:0] forKey:@"paymentInfo"];
                         }
                     }
                     else
                     {
                         [_userInfoDictionary setObject:[NSMutableDictionary dictionaryWithCapacity:0] forKey:@"paymentInfo"];
                     }
                    
                     [[NSUserDefaults standardUserDefaults]setObject:_userInfoDictionary forKey:@"UserInfo"];
                     [[NSUserDefaults standardUserDefaults]synchronize];
                     
                     [appDelegate().userInfo updateWithAttributes:_userInfoDictionary];
                     
                     if (completion)
                         completion(YES,nil);
                 }
                 else
                 {
                     NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"Invalid user for app",@"description", nil]];
                     
                     if (completion)
                         completion(NO,_error);
                 }
             }
             else
             {
                 NSString *_errorTitle=@"Error";
               
                 if ([[_dictionary objectForKey:@"message"]rangeOfString:@"lease fill in all fields and verify that"].length!=NSNotFound)
                 {
                    _errorTitle=@"Login details not valid";
                 }
                 
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:_errorTitle,@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}


- (void)signupWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_email=[attributes objectForKey:@"email"];
   
    NSString *_password=[attributes objectForKey:@"password"];
   
    NSString *_deviceToken=[attributes objectForKey:@"deviceToken"];
   
    NSString *_deviceType=[attributes objectForKey:@"deviceType"];
   
    NSString *_userType=[attributes objectForKey:@"userType"];
   
    NSString *_fbid=[attributes objectForKey:@"fbid"];
    
    NSCharacterSet *set = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ0123456789"];
    
    NSString *encodedEmail = [_email stringByAddingPercentEncodingWithAllowedCharacters:set];
    NSString *encodedPassword = [_password stringByAddingPercentEncodingWithAllowedCharacters:set];
    
    
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL,SIGNUP_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"email=%@&password=%@&device_token=%@&device_type=%@&usertype=%@&fbid=%@",encodedEmail,encodedPassword,_deviceToken,_deviceType,_userType,_fbid];
    
    NSLog(@"%@",_urlString);
    NSLog(@"%@",_postParameters);
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error)
    {
         if (error)
         {
             NSLog(@"%@",[error description]);
            
             NSError*_error=nil;
            
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
            
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];

             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                  NSMutableDictionary *_userInfo=nil;
                  NSMutableDictionary *_recordInfo=nil;
                 
                 if ([[_dictionary objectForKey:@"record"] isKindOfClass:[NSDictionary class]])
                 {
                     _recordInfo=[_dictionary objectForKey:@"record"];
                 }
                 else
                 {
                     _recordInfo=[[_dictionary objectForKey:@"record"] objectAtIndex:0];
                 }
                 
                 if ([_recordInfo.allKeys containsObject:@"User"])
                 {
                       _userInfo=[NSMutableDictionary dictionaryWithDictionary:[_recordInfo objectForKey:@"User"]];
                 }
                 else
                 {
                     _userInfo=[NSMutableDictionary dictionaryWithDictionary:_recordInfo];
                 }
               
                
                 if ([[_recordInfo objectForKey:@"PaymentInfo"]isKindOfClass:[NSDictionary class]])
                 {
                     NSDictionary *_paymentMethodInfo=[_recordInfo objectForKey:@"PaymentInfo"];
                     if (_paymentMethodInfo.allKeys.count>0)
                     {
                         [_userInfo setObject:_paymentMethodInfo forKey:@"paymentInfo"];
                     }
                     else
                     {
                         [_userInfo setObject:[NSMutableDictionary dictionaryWithCapacity:0] forKey:@"paymentInfo"];
                     }
                 }
                 else
                 {
                     [_userInfo setObject:[NSMutableDictionary dictionaryWithCapacity:0] forKey:@"paymentInfo"];
                 }

                 [[NSUserDefaults standardUserDefaults]setObject:_userInfo forKey:@"UserInfo"];
                 [[NSUserDefaults standardUserDefaults]synchronize];
                
                 [appDelegate().userInfo updateWithAttributes:_userInfo];
                 
                 if (completion)
                     completion(YES,nil);
             }
            
             else
             {
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"])
                 {
                     [progressHud() hide];
                    
                     [ccManager() showAlertWithTitle:@"Login details not valid" message:@"Please fill in all fields and verify that your email and password are correct" buttons:nil completion:nil];

                     [appDelegate().userInfo reset];

                     return;
                     
                 }
                 
                 NSString *_errorTitle=@"Error";
                 if ([[_dictionary objectForKey:@"message"]rangeOfString:@"email format"].length!=NSNotFound){
                     _errorTitle=@"Email";
                 }
                 else  if ([[_dictionary objectForKey:@"message"]rangeOfString:@"password is"].length!=NSNotFound){
                     _errorTitle=@"Password";
                 }

                 
                 NSError*_error = [NSError errorWithDomain:_errorTitle code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:_errorTitle,@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}


- (void)updateUserInfoWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_urlString = [NSString stringWithFormat:@"%@%@",APPURL,UPDATEPROFILE_EXTENSION];
    
    NSString *_userId       =[attributes objectForKey:@"userId"];
    NSString *_firstName    =[attributes objectForKey:@"firstName"];
    NSString *_lastName     =[attributes objectForKey:@"lastName"];
    NSString *_mobile       =[attributes objectForKey:@"mobile"];;
    NSString *_city         =[attributes objectForKey:@"city"];
    
    NSData   *_imageData=nil;
    
    NSMutableURLRequest *_request= [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:_urlString]];
    [_request setHTTPMethod:@"POST"];
    
    if ([[attributes objectForKey:@"image"]isKindOfClass:[UIImage class]])
    {
        _imageData=UIImageJPEGRepresentation([attributes objectForKey:@"image"], 0.2);
        
        NSDictionary *_parameters = @{
                                      @"user_id": _userId,
                                      @"first_name": _firstName,
                                      @"last_name": _lastName,
                                      @"mobile": _mobile,
                                      @"city": _city
                                      };
        
        NSString *_filename = @"profileImage";
        
        NSString *_boundary = @"---------------------------14737809831466499882746641449";
        NSString *_contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",_boundary];
        [_request addValue:_contentType forHTTPHeaderField: @"Content-Type"];
        NSMutableData *_postbody = [NSMutableData data];
        
        for (NSString *_key in [_parameters allKeys])
        {
            [_postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",_boundary] dataUsingEncoding:NSUTF8StringEncoding]];
            [_postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"\r\n\r\n",_key] dataUsingEncoding:NSUTF8StringEncoding]];
            [_postbody appendData:[[_parameters objectForKey:_key] dataUsingEncoding:NSUTF8StringEncoding]];
        }
        
        [_postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",_boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [_postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"image\"; filename=\"%@.png\"\r\n", _filename] dataUsingEncoding:NSUTF8StringEncoding]];
        
        [_postbody appendData:[[NSString stringWithFormat:@"Content-Type: application/octet-stream\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
        [_postbody appendData:_imageData];
        [_postbody appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n",_boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        
        [_request setHTTPBody:_postbody];
        [_request setValue:[NSString stringWithFormat:@"%lu", (unsigned long)[_postbody length]] forHTTPHeaderField:@"Content-Length"];
    }
    else
    {
        NSString *_postParameters =[NSString stringWithFormat:@"city=%@&user_id=%@&first_name=%@&last_name=%@&mobile=%@&image=",_city,_userId,_firstName,_lastName,_mobile];

        NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
        NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
        
        [_request setValue:_postLength forHTTPHeaderField:@"Content-Length"];
        [_request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        [_request setHTTPBody:_postData];
    }
    
    [NSURLConnection sendAsynchronousRequest:_request  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
             
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 NSMutableDictionary *_userInfo=[NSMutableDictionary dictionaryWithDictionary:[[NSUserDefaults standardUserDefaults]objectForKey:@"UserInfo"]];
                 [_userInfo setObject:_firstName forKey:@"first_name"];
                 [_userInfo setObject:_lastName forKey:@"last_name"];
                 [_userInfo setObject:_mobile forKey:@"mobile"];
                 
                 NSString *_imageName=[self genRandStringLength:10];
                
                 NSString *_fileName=[[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:[NSString stringWithFormat:@"Images/%@.png",_imageName]];

                 [_imageData writeToFile:_fileName atomically:YES];
                 
                 [_userInfo setObject:_imageName forKey:@"image"];
                 
                 [_userInfo setObject:[NSMutableDictionary dictionaryWithCapacity:0] forKey:@"paymentInfo"];
                 
                 [[NSUserDefaults standardUserDefaults]setObject:_userInfo forKey:@"UserInfo"];
                 [[NSUserDefaults  standardUserDefaults]synchronize];
                
                 [appDelegate().userInfo updateWithAttributes:_userInfo];
                 
               
                 if (completion)
                     completion(YES,nil);
                 
             }
             else
             {
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"])
                 {
                     [progressHud() hide];
                    
                     [ccManager() showAlertWithTitle:@"Info" message:@"Your account has been suspended." buttons:nil completion:nil];
                     
                     [appDelegate().userInfo reset];
                     
                     [appDelegate() showAppHomeViewController];
                     
                     return;
                     
                 }
                 
                 NSString *_errorTitle=@"Error";
                 if ([[_dictionary objectForKey:@"message"]rangeOfString:@"email format"].length!=NSNotFound){
                     _errorTitle=@"Email";
                 }
                 
                NSError*_error = [NSError errorWithDomain:_errorTitle code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:_errorTitle,@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}


-(NSString *) genRandStringLength: (int) len
{
    NSString *_Characters = @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    NSMutableString *randomString = [NSMutableString stringWithCapacity: len];
    for (int i=0; i<len; i++)
        [randomString appendFormat: @"%C", [_Characters characterAtIndex: arc4random() % [_Characters length]]];
    return randomString;
}


- (void)sendPasswordWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_email=[attributes objectForKey:@"email"];
    
    NSCharacterSet *set = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ0123456789"];
    
    NSString *encodedEmail = [_email stringByAddingPercentEncodingWithAllowedCharacters:set];
  
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL,FORGOTPASSWORD_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"email=%@",encodedEmail];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error)
    {
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
       
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"])
                 {
                     [progressHud() hide];
                    
                     [ccManager() showAlertWithTitle:@"Info" message:@"Your account has been suspended." buttons:nil completion:nil];
                     return;
                 }
                 
                 NSString *_errorTitle=@"Error";
                 if ([[_dictionary objectForKey:@"message"]rangeOfString:@"email format"].length!=NSNotFound){
                     _errorTitle=@"Email";
                 }
                 
                 NSError*_error = [NSError errorWithDomain:_errorTitle code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:_errorTitle,@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}


- (void)addPaymentMethodWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_userId=[attributes objectForKey:@"userId"];
    NSString *_type=[attributes objectForKey:@"type"];
    NSString *_cardNo=[attributes objectForKey:@"cardLastFourDigit"];
    NSString *_token=[attributes objectForKey:@"consumerToken"];
    NSString *_paypalEmail=[attributes objectForKey:@"paypalEmail"];
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_1,ADDPAYMENTMETHOD_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"consumer_id=%@&type=%@&card_last_four_digit=%@&consumer_token=%@&paypal_email=%@",_userId,_type,_cardNo,_token,_paypalEmail];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
            
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 NSMutableDictionary *_paymentInfo=[NSMutableDictionary dictionaryWithCapacity:3];
                 if ([_type isEqualToString:@"0"])
                 {
                     [_paymentInfo setObject:@"credit card" forKey:@"type"];
                     [_paymentInfo setObject:_cardNo forKey:@"card_no"];
                 }
                 else
                 {
                     [_paymentInfo setObject:@"paypal" forKey:@"type"];
                     [_paymentInfo setObject:_paypalEmail forKey:@"paypal_email"];
                 }
                
                 NSMutableDictionary *_userInfoDictionary=[NSMutableDictionary dictionaryWithDictionary:[[NSUserDefaults standardUserDefaults]objectForKey:@"UserInfo"]];
                 [_userInfoDictionary setObject:_paymentInfo forKey:@"paymentInfo"];
                 
                 [[NSUserDefaults standardUserDefaults]setObject:_userInfoDictionary forKey:@"UserInfo"];
                 [[NSUserDefaults standardUserDefaults]synchronize];
                 
                 [appDelegate().userInfo updatePaymentMethodWithAttributes:_paymentInfo];
                 
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"])
                 {
                     [progressHud() hide];
                    
                     [ccManager() showAlertWithTitle:@"Info" message:@"Your account has been suspended." buttons:nil completion:nil];
                     
                     [appDelegate().userInfo reset];
                     
                     [appDelegate() showAppHomeViewController];
                     
                     return;
                     
                 }
                 
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}


- (void)getMenuOptionsWithCompletion:(void(^)(BOOL,NSError*))completion
{
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_1,MENUITEMS_EXTENSION];

    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
 
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
       
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 [[NSUserDefaults standardUserDefaults]setObject:[_dictionary objectForKey:@"record"] forKey:@"HomeMenuItems"];
                 [[NSUserDefaults standardUserDefaults] synchronize];
                 
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}


- (void)fetchPlaceNameForLat:(NSString *)lat lng:(NSString *)lng completion:(void(^)(NSString *,BOOL))completion
{
    NSString *_urlString=[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/geocode/json?latlng=%@,%@",lat,lng];
    
    [NSURLConnection sendAsynchronousRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:_urlString]]  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error)
    {
        NSMutableString *_locationString=[NSMutableString stringWithString:@""];
        
        if (!error)
         {
             NSDictionary *_responseDictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
             
             if ([[_responseDictionary objectForKey:@"status"]isEqualToString:@"OK"])
             {
                 NSArray *_resultArray=[_responseDictionary objectForKey:@"results"];
                
                 if (_resultArray.count>0)
                 {
                     NSArray *_addressComponents=[[_resultArray objectAtIndex:0] objectForKey:@"address_components"];
                    
                     for (NSDictionary *_dictionary in _addressComponents)
                     {
                         [_locationString appendString:[_dictionary objectForKey:@"long_name"]];
                         
                         if(_locationString.length>0)
                         {
                             [_locationString appendString:@","];
                         }
                     }
                     
                     if (_locationString.length>2)
                     {
                         _locationString=[NSMutableString stringWithString:[_locationString substringToIndex:_locationString.length-1]];
                     }
                     
                     if (_locationString.length>0)
                     {
                         NSMutableDictionary *_dictionary=[NSMutableDictionary dictionaryWithCapacity:3];
                         [_dictionary setObject:lat forKey:@"Lat"];
                         [_dictionary setObject:lng forKey:@"Lng"];
                         [_dictionary setObject:_locationString forKey:@"Location"];
                         [[NSUserDefaults standardUserDefaults]setObject:_dictionary forKey:@"LocationDict"];
                         [[NSUserDefaults standardUserDefaults]synchronize];
                     }
                 }
             }
         }
         if (_locationString.length>0)
         {
             if(completion)
                 completion(_locationString,YES);
         }
         else
         {
             if (completion)
                 completion(@"",NO);
         }
     }];
}


- (void)updatePasswordWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_userId      = [attributes objectForKey:@"userId"];
    NSString *_oldPassword = [attributes objectForKey:@"oldPassword"];
    NSString *_newPassword = [attributes objectForKey:@"newPassword"];

    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL,UPDATEPASSWORD_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"user_id=%@&oldpassword=%@&newpassword=%@",_userId,_oldPassword,_newPassword];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
  
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                 NSString *_errorTitle=@"Error";
                
                 if ([[_dictionary objectForKey:@"message"]rangeOfString:@"ur Current Password is not corre"].length!=NSNotFound){
                     _errorTitle=@"Current Password";
                 }

                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:_errorTitle,@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}

- (void)createJobWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*,NSString *, NSString *))completion
{
    NSString *_userId=[attributes objectForKey:@"userId"];
    NSString *_menuId=[attributes objectForKey:@"menuId"];
    NSString *_location=[attributes objectForKey:@"location"];
    NSString *_postalCode =[attributes objectForKey:@"postalCode"];
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_2,CREATEJOB_EXTENSION];
  NSLog(@"%@",_urlString);
    NSString *_postParameters =[NSString stringWithFormat:@"consumer_id=%@&category_id=%@&location=%@&postalCode=%@",_userId,_menuId,_location,_postalCode];
     NSLog(@"%@",_postParameters);
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error)
    {
         if (error)
         {
             NSError*_error=nil;
             
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error,nil,nil);
         }
         else
         {
             NSLog(@"%@",[[NSString alloc]initWithData:responseData encoding:NSUTF8StringEncoding]);
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
            
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil,[NSString stringWithFormat:@"%i",[[_dictionary objectForKey:@"job_id"]intValue]],[NSString stringWithFormat:@"%f",[[_dictionary objectForKey:@"consumer_payable_amount"]floatValue]]);
             }
             else
             {
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"])
                 {
                     [progressHud() hide];
                     
                     [ccManager() showAlertWithTitle:@"Info" message:@"Your account has been suspended." buttons:nil completion:nil];
                     
                     [appDelegate().userInfo reset];
                     
                     [appDelegate() showAppHomeViewController];
                     
                     return;
                     
                 }
                 
                 
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error,nil,nil);
             }
         }
     }];
}


- (void)activateJobWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_jobId=[attributes objectForKey:@"jobId"];
   
    NSString *_status=[attributes objectForKey:@"status"];

    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_2,ACTIVATE_JOBSTATUS];
    
    NSString *_postParameters =[NSString stringWithFormat:@"job_id=%@&status=%@",_jobId,_status];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
             
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"])
                 {
                     [progressHud() hide];
                     
                     [ccManager() showAlertWithTitle:@"Info" message:@"Your account has been suspended." buttons:nil completion:nil];
                     
                     [appDelegate().userInfo reset];
                     
                     [appDelegate() showAppHomeViewController];
                     
                     return;
                     
                 }
                 
        
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}


- (void)fetchLastCreatedJobStatusWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSTimeZone *_currentTimeZone = [NSTimeZone localTimeZone];
    
    NSString *_userId=[attributes objectForKey:@"userId"];
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_2,JOBSTATUS_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"consumer_id=%@&time_zone=%@",_userId,_currentTimeZone.name];

    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];

             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 NSMutableDictionary *_records=nil;
                 
                 if ([[_dictionary objectForKey:@"record"] isKindOfClass:[NSDictionary class]])
                 {
                     _records=[_dictionary objectForKey:@"record"];
                 }
                 else
                 {
                     _records=[[_dictionary objectForKey:@"record"] objectAtIndex:0];
                 }
                 
                 if ([_records isKindOfClass:[NSDictionary class]])
                 {
                     NSString *_paymentType=@"0";
                     NSString *_transactionId=@"";
                     NSDictionary *_paymentInfo=[_records objectForKey:@"paymentinfo"];
                     
                     if (_paymentInfo.allKeys.count>0)
                     {
                         if ([_paymentInfo.allKeys containsObject:@"transactionId"] && (NSNull *)[_paymentInfo objectForKey:@"transactionId"]!=[NSNull null])
                         {
                             _transactionId=[_paymentInfo objectForKey:@"transactionId"];
                            
                             if ([_paymentInfo.allKeys containsObject:@"transationType"] && (NSNull *)[_paymentInfo objectForKey:@"transationType"]!=[NSNull null])
                             {
                                 _paymentType=[_paymentInfo objectForKey:@"transationType"];
                             }
                             else
                             {
                                 if ([_transactionId rangeOfString:@"PAY"].location!=NSNotFound)
                                 {
                                   _paymentType=@"1";
                                 }
                             }
                         }
                     }
                     
                     NSDictionary *_jobDescriptionDictionary=[_records objectForKey:@"jobDescription"];
                     
                     NSMutableDictionary *_jobDetail=[NSMutableDictionary dictionaryWithCapacity:10];
                   
                     [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"id"] forKey:@"id"];
                     [_jobDetail setObject:[NSString stringWithFormat:@"%f",[[_jobDescriptionDictionary objectForKey:@"consumer_payable_amount"]floatValue]] forKey:@"customerPayablePrice"];
                     [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"itemName"] forKey:@"itemName"];
                     [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"itemPrice"] forKey:@"itemPrice"];
                     [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"date"]  forKey:@"date"];
                     [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"location"]  forKey:@"location"];
                     [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"search_duration"]  forKey:@"timeInterval"];
                     [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"cancel_amount"] forKey:@"cancellationFees"];
                     [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"technician_cancellation_fee"] forKey:@"technicianCancellationFees"];
                      [_jobDetail setObject:[NSString stringWithFormat:@"%d",[[_jobDescriptionDictionary objectForKey:@"Paid"] boolValue]] forKey:@"isPaid"];
                     [_jobDetail setObject:_paymentType  forKey:@"transationType"];
                     [_jobDetail setObject:_transactionId  forKey:@"transactionId"];

                     int _status=0;
                     
                     if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Searching"])
                     {
                         _status=0;
                         NSMutableDictionary *_technicianInfo=[NSMutableDictionary dictionaryWithCapacity:0];
                         [_jobDetail setObject:_technicianInfo  forKey:@"technician"];
                     }
                     else if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Accept"])
                     {
                         _status=1;
                         NSMutableDictionary *_technicianInfo=[NSMutableDictionary dictionaryWithDictionary:[_records objectForKey:@"technicianInfo"]];
                         if ([((NSDictionary *)[_records objectForKey:@"technicianInfo"]).allKeys containsObject:@"rating"] && (NSNull *)[((NSDictionary *)[_records objectForKey:@"technicianInfo"]) objectForKey:@"rating"]!=[NSNull null]) {}
                         else
                         {
                             [_technicianInfo setObject:@"0" forKey:@"rating"];
                         }
                         
                         [_jobDetail setObject:_technicianInfo  forKey:@"technician"];
                     }
                     else if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Cancel by consumer"])
                     {
                          _status=2;
                         if (![[_jobDescriptionDictionary objectForKey:@"Paid"]boolValue])
                         {
                             _status=6;
                         }
                         
                         NSMutableDictionary *_technicianInfo=[NSMutableDictionary dictionaryWithCapacity:0];
                         
                         [_jobDetail setObject:_technicianInfo  forKey:@"technician"];
                     }
                     else if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Cancel by technician"])
                     {
                         [_jobDetail setObject:@"0"  forKey:@"timeInterval"];
                         _status=3;
                         NSMutableDictionary *_technicianInfo=[NSMutableDictionary dictionaryWithDictionary:[_records objectForKey:@"technicianInfo"]];
                         if ([((NSDictionary *)[_records objectForKey:@"technicianInfo"]).allKeys containsObject:@"rating"] && (NSNull *)[((NSDictionary *)[_records objectForKey:@"technicianInfo"]) objectForKey:@"rating"]!=[NSNull null]) {}
                         else
                         {
                             [_technicianInfo setObject:@"0" forKey:@"rating"];
                         }
                         
                         [_jobDetail setObject:_technicianInfo  forKey:@"technician"];
                     }
                     else if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Working"])
                     {
                         _status=4;
                         NSMutableDictionary *_technicianInfo=[NSMutableDictionary dictionaryWithDictionary:[_records objectForKey:@"technicianInfo"]];
                         if ([((NSDictionary *)[_records objectForKey:@"technicianInfo"]).allKeys containsObject:@"rating"] && (NSNull *)[((NSDictionary *)[_records objectForKey:@"technicianInfo"]) objectForKey:@"rating"]!=[NSNull null]) {}
                         else
                         {
                             [_technicianInfo setObject:@"0" forKey:@"rating"];
                         }
                         
                         [_jobDetail setObject:_technicianInfo  forKey:@"technician"];
                     }
                     else if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Completed"])
                     {
                         _status=5;
                         NSMutableDictionary *_technicianInfo=[NSMutableDictionary dictionaryWithDictionary:[_records objectForKey:@"technicianInfo"]];
                         if ([((NSDictionary *)[_records objectForKey:@"technicianInfo"]).allKeys containsObject:@"rating"] && (NSNull *)[((NSDictionary *)[_records objectForKey:@"technicianInfo"]) objectForKey:@"rating"]!=[NSNull null]) {}
                         else
                         {
                             [_technicianInfo setObject:@"0" forKey:@"rating"];
                         }
                         
                         [_jobDetail setObject:_technicianInfo  forKey:@"technician"];
                     }
                     else if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Feedback"])
                     {
                         _status=8;
                         NSMutableDictionary *_technicianInfo=[NSMutableDictionary dictionaryWithDictionary:[_records objectForKey:@"technicianInfo"]];
                         if ([((NSDictionary *)[_records objectForKey:@"technicianInfo"]).allKeys containsObject:@"rating"] && (NSNull *)[((NSDictionary *)[_records objectForKey:@"technicianInfo"]) objectForKey:@"rating"]!=[NSNull null]) {}
                         else
                         {
                             [_technicianInfo setObject:@"0" forKey:@"rating"];
                         }
                         
                         [_jobDetail setObject:_technicianInfo  forKey:@"technician"];
                     }
                     else if([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Feedback Received"])
                     {
                         if (![[_jobDescriptionDictionary objectForKey:@"Paid"]boolValue])
                         {
                             _status=7;
                         }
                         else
                         {
                              _status=9;
                         }
                         NSMutableDictionary *_technicianInfo=[NSMutableDictionary dictionaryWithDictionary:[_records objectForKey:@"technicianInfo"]];
                         if ([((NSDictionary *)[_records objectForKey:@"technicianInfo"]).allKeys containsObject:@"rating"] && (NSNull *)[((NSDictionary *)[_records objectForKey:@"technicianInfo"]) objectForKey:@"rating"]!=[NSNull null]) {}
                         else
                         {
                             [_technicianInfo setObject:@"0" forKey:@"rating"];
                         }
                         
                         [_jobDetail setObject:_technicianInfo  forKey:@"technician"];
                     }
                     else if([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Inactive"])
                     {

                         if ([[_jobDescriptionDictionary objectForKey:@"Paid"] boolValue])
                         {
                              _status=11;
                         }
                         else
                         {
                             _status=10;
                         }

                         NSMutableDictionary *_technicianInfo=[NSMutableDictionary dictionaryWithCapacity:0];
                         [_jobDetail setObject:_technicianInfo  forKey:@"technician"];
                     }
                     else
                     {
                         _status=0;
                         [_jobDetail setObject:[NSMutableDictionary dictionaryWithCapacity:0]  forKey:@"technician"];

                     }
                  
                     [_jobDetail setObject:[NSString stringWithFormat:@"%i",_status]  forKey:@"status"];
                    
                     if ([self getStatusValue]==_status)
                     {
                         appDelegate().jobDetail.changed=NO;
                     }
                     else
                     {
                         appDelegate().jobDetail.changed=YES;
                     }
                     
                     
                     
                                          
                     [[NSUserDefaults standardUserDefaults]setObject:_jobDetail forKey:@"LastJobDetail"];
                     [[NSUserDefaults standardUserDefaults]synchronize];
                     
                     [appDelegate().jobDetail updateWithAttributes:_jobDetail];
                     
                     if (completion)
                         completion(YES,nil);
                     
                 }
                 else
                 {
                     NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error. Please try again.",@"description", nil]];
                     
                     if (completion)
                         completion(NO,_error);
                 }
             }
             else
             {
                 
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"])
                 {
                     [progressHud() hide];
                     [ccManager() showAlertWithTitle:@"Info" message:@"Your account has been suspended." buttons:nil completion:nil];
                    
                     [appDelegate().userInfo reset];
                     
                     [appDelegate() showAppHomeViewController];
                    
                     return;
                     
                 }
                 
                 
                 if ([[_dictionary objectForKey:@"message"]rangeOfString:@"No record found"].length!=NSNotFound)
                 {
                     [[NSUserDefaults standardUserDefaults]setObject:[NSMutableDictionary dictionaryWithCapacity:0] forKey:@"LastJobDetail"];
                     [[NSUserDefaults standardUserDefaults]synchronize];
                     
                     if (completion)
                         completion(YES,nil);
                  
                     return ;
                     
                 }
                 
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}


- (int)getStatusValue
{
    if (appDelegate().jobDetail.status==JSSearching)
        return 0;
    else if (appDelegate().jobDetail.status==JSPending)
        return 1;
    else if (appDelegate().jobDetail.status==JSNoJob)
        return 2;
    else if (appDelegate().jobDetail.status==JSCancelByTechnician)
        return 3;
    else if (appDelegate().jobDetail.status==JSStarted)
        return 4;
    else if (appDelegate().jobDetail.status==JSCompleted)
        return 5;
    else if (appDelegate().jobDetail.status==JSCancelledUnpaid)
        return 6;
    else if (appDelegate().jobDetail.status==JSCompleteUnpaid)
        return 7;
    else if (appDelegate().jobDetail.status==JSNeedFeedback)
        return 8;
    else if (appDelegate().jobDetail.status==JSInActiveJobUnpaid)
        return 10;
    else if (appDelegate().jobDetail.status==JSInActiveJobPaid)
        return 11;
    else
        return 9;
}


- (void)extendJobTimeWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_jobId=[attributes objectForKey:@"jobId"];
    NSString *_duration=[attributes objectForKey:@"duration"];
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_2,EXTENDTIME_EXTENSION];

    NSString *_postParameters =[NSString stringWithFormat:@"job_id=%@&search_duration=%@",_jobId,_duration];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
             
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}


- (void)cancelJobWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*,BOOL))completion
{
    NSString *_jobId=[attributes objectForKey:@"jobId"];
    NSString *_userId=[attributes objectForKey:@"userId"];
    NSString *_status=[attributes objectForKey:@"status"];
    NSString *_comment=[attributes objectForKey:@"comment"];
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_2,CANCELJOB_EXTENSION];
    NSLog(@"%@",_urlString);
    
    NSString *_postParameters =[NSString stringWithFormat:@"job_id=%@&consumer_id=%@&status=%@&comment=%@",_jobId,_userId,_status,_comment];
    NSLog(@"%@",_postParameters);
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
           
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error,NO);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
             

             
             NSLog(@"%@",_dictionary);
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 BOOL _isTechnicianAvailable=[[_dictionary objectForKey:@"isTechnicianAccepted"]boolValue];
               
                 if (appDelegate().jobDetail.isPaidByPaypal)
                 {
                      NSLog(@"1");
                     float _refundablePrice=0.0;
                    
                     if (_isTechnicianAvailable && appDelegate().jobDetail.status!=JSCancelByTechnician)
                     {
                         _refundablePrice=appDelegate().jobDetail.customerPayablePrice-appDelegate().jobDetail.cancellationFees;
                     }
                     else
                     {
                         _refundablePrice=appDelegate().jobDetail.customerPayablePrice;
                     }
                     
                     NSLog(@"2");
                     if (_refundablePrice>0)
                     {
                         NSMutableDictionary *_returnDict=[NSMutableDictionary dictionaryWithCapacity:4];
                         [_returnDict setObject:appDelegate().jobDetail.transactionId forKey:@"transactionId"];
                         [_returnDict setObject:@(_refundablePrice) forKey:@"amount"];
                         [[NSUserDefaults standardUserDefaults]setObject:_returnDict forKey:@"RefundInfo"];
                         [[NSUserDefaults standardUserDefaults]synchronize];
                     }
                     else if (_refundablePrice<0)
                     {
                         NSMutableDictionary *_returnDict=[NSMutableDictionary dictionaryWithCapacity:4];
                         [_returnDict setObject:appDelegate().jobDetail.transactionId forKey:@"transactionId"];
                         [_returnDict setObject:@(fabs(_refundablePrice)) forKey:@"amount"];
                        
                         [[NSUserDefaults standardUserDefaults]setObject:_returnDict forKey:@"DuePaymentInfo"];
                         [[NSUserDefaults standardUserDefaults]synchronize];
                     }
                     else
                     {
                         [progressHud() hide];
                     }
                     
                     /*
                     if (_refundablePrice>0)
                     {
                         NSMutableDictionary *_returnDict=[NSMutableDictionary dictionaryWithCapacity:4];
                         [_returnDict setObject:appDelegate().jobDetail.transactionId forKey:@"transactionId"];
                         
                         if (_isTechnicianAvailable && appDelegate().jobDetail.status!=JSCancelByTechnician)
                         {
                             [_returnDict setObject:@(1.0) forKey:@"amount"];
                         }
                         else
                         {
                             [_returnDict setObject:@(appDelegate().jobDetail.paypalAmount) forKey:@"amount"];
                         }
                         NSLog(@"%@",_returnDict);
                         [[NSUserDefaults standardUserDefaults]setObject:_returnDict forKey:@"RefundInfo"];
                         [[NSUserDefaults standardUserDefaults]synchronize];
                     }
                     
                     
                     if (appDelegate().jobDetail.customerPayablePrice>0)
                     {
                         NSMutableDictionary *_returnDict=[NSMutableDictionary dictionaryWithCapacity:4];
                         [_returnDict setObject:appDelegate().jobDetail.transactionId forKey:@"transactionId"];
                         
                         if (_isTechnicianAvailable && appDelegate().jobDetail.status!=JSCancelByTechnician)
                         {
                             [_returnDict setObject:@(1.0) forKey:@"amount"];
                         }
                         else
                         {
                             [_returnDict setObject:@(appDelegate().jobDetail.paypalAmount) forKey:@"amount"];
                         }
                         [[NSUserDefaults standardUserDefaults]setObject:_returnDict forKey:@"RefundInfo"];
                         [[NSUserDefaults standardUserDefaults]synchronize];
                     }
                     else
                     {
                         [progressHud() hide];
                     }
                      */
                 }
                 
                 if (completion)
                     completion(YES,nil,NO);
             }
             else
             {
                 if ([[_dictionary objectForKey:@"message"]rangeOfString:@"Invalid command"].length!=NSNotFound)
                 {
                     if (completion)
                         completion(NO,nil,YES);
                     
                     return ;
                     
                 }
                 
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error,NO);
             }
         }
     }];
}

- (void)markJobAsPaidWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_jobId=[attributes objectForKey:@"jobId"];
    NSString *_userId=[attributes objectForKey:@"userId"];
    NSString *_transactionId=[attributes objectForKey:@"transactionId"];
    NSString *_price=[attributes objectForKey:@"price"];
    NSString *_type=[attributes objectForKey:@"type"];
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_3,MARKASPAID_EXTENSION];

    NSString *_postParameters =[NSString stringWithFormat:@"job_id=%@&consumer_id=%@&transaction_id=%@&amount=%@&type=%@",_jobId,_userId,_transactionId,_price,_type];

    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
          
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}


- (void)completeJobWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_jobId=[attributes objectForKey:@"jobId"];
    NSString *_userId=[attributes objectForKey:@"userId"];
    NSString *_professionalismRating=[attributes objectForKey:@"professionalismRating"];
    NSString *_punctualityRating=[attributes objectForKey:@"punctualityRating"];
    NSString *_presentationRating=[attributes objectForKey:@"presentationRating"];
  
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_2,COMPLETEJOB_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"jobId=%@&userId=%@&professionalism=%@&Punctuality=%@&Presentation=%@",_jobId,_userId,_professionalismRating,_punctualityRating,_presentationRating];

    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
             
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];

}


- (void)sendFeedbackForJobWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_jobId=[attributes objectForKey:@"jobId"];
    NSString *_userId=[attributes objectForKey:@"userId"];
    NSString *_comment=[attributes objectForKey:@"comment"];

    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_2,FEEDBACK_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"jobId=%@&userId=%@&comment=%@",_jobId,_userId,_comment];

    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];

             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}


- (void)fetchJobHistoryForJobWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*, NSMutableArray*))completion
{
    NSString *_userId=[attributes objectForKey:@"userId"];
    NSString *_month=[attributes objectForKey:@"month"];
    NSString *_year=[attributes objectForKey:@"year"];
  
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_2,GETJOBS_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"consumer_id=%@&mm=%@&yyyy=%@",_userId,_month,_year];

    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error,nil);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
             
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil,[_dictionary objectForKey:@"record"]);
             }
             else
             {
                 if ([[[_dictionary objectForKey:@"message"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]isEqualToString:@"Invalid user"])
                 {
                     [progressHud() hide];
                     [ccManager() showAlertWithTitle:@"Info" message:@"Your account has been suspended." buttons:nil completion:nil];
                     
                     [appDelegate().userInfo reset];
                     
                     [appDelegate() showAppHomeViewController];
                     
                     return;
                     
                 }
                 
                 
                 if ([[_dictionary objectForKey:@"message"]rangeOfString:@"No record found"].length!=NSNotFound)
                 {
                     if (completion)
                         completion(YES,nil,[NSMutableArray arrayWithCapacity:0]);
                     
                     return ;
                     
                 }
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error,nil);
             }
         }
     }];
}


- (void)updateDeviceTokenWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion
{
    NSString *_userId=appDelegate().userInfo.userId;
    NSString *_deviceToken=[[NSUserDefaults standardUserDefaults]objectForKey:@"deviceToken"];

    if(_deviceToken==NULL)
        return;
    
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_2,UPDATETOKEN_EXTENSION];
    
    NSString *_postParameters =[NSString stringWithFormat:@"user_id=%@&device_token=%@",_userId,_deviceToken];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
             
             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                 NSError*_error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",[_dictionary objectForKey:@"message"],@"description", nil]];
                 
                 if (completion)
                     completion(NO,_error);
             }
         }
     }];
}


- (void)fetchPostalCodeForAddress:(NSString *)address completion:(void(^)(BOOL,NSString *))completion
{
    NSString *_urlString=[NSString stringWithFormat:@"http://maps.googleapis.com/maps/api/geocode/json?address=%@",address];
    
    NSLog(@"%@",[_urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]);
    
    [NSURLConnection sendAsynchronousRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[_urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]]  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             if (completion)
                 completion(NO,nil);
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
             
             if ([[_dictionary objectForKey:@"status"]isEqualToString:@"OK"])
             {
                 NSArray *_results=[_dictionary objectForKey:@"results"];
                 NSString *_postalCode=@"";
                 float _lat=0;
                 float _lng=0;
                 
                 for (NSDictionary *_locationDict in _results)
                 {
                     NSArray *_addressComponents=[_locationDict objectForKey:@"address_components"];
                     
                     for (NSDictionary *_addressComponentDict in _addressComponents)
                     {
                         NSArray *_type=[_addressComponentDict objectForKey:@"types"];
                         
                         if ([_type containsObject:@"postal_code"])
                         {
                             _postalCode=[_addressComponentDict objectForKey:@"long_name"];
                             break;
                         }
                     }
                     
                     if (_postalCode.length>0)
                     {
                         break;
                     }
                     
                     _lat =[[[[_locationDict objectForKey:@"geometry"]objectForKey:@"location"]objectForKey:@"lat"]floatValue];
                     _lng =[[[[_locationDict objectForKey:@"geometry"]objectForKey:@"location"]objectForKey:@"lng"]floatValue];
                 }
                 
                 if (_postalCode.length>0)
                 {
                     if (completion)
                         completion(YES,_postalCode);
                 }
                 else
                 {
                     if (_lat !=0 && _lng!=0)
                     {
                         NSString *_urlString=[NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/geocode/json?latlng=%f,%f",_lat,_lng];
                         [NSURLConnection sendAsynchronousRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:_urlString]]  queue:[NSOperationQueue mainQueue] completionHandler:
                          ^(NSURLResponse *response, NSData *responseData, NSError *error)
                         {
                             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
                             
                             if ([[_dictionary objectForKey:@"status"]isEqualToString:@"OK"])
                             {
                                 NSArray *_results=[_dictionary objectForKey:@"results"];
                                 NSString *_postalCode=@"";
                                 NSString *_lat=@"";
                                 NSString *_lng=@"";
           
                                 for (NSDictionary *_locationDict in _results)
                                 {
                                     NSArray *_addressComponents=[_locationDict objectForKey:@"address_components"];
                                     
                                     for (NSDictionary *_addressComponentDict in _addressComponents)
                                     {
                                         NSArray *_type=[_addressComponentDict objectForKey:@"types"];
                                         
                                         if ([_type containsObject:@"postal_code"])
                                         {
                                             _postalCode=[_addressComponentDict objectForKey:@"long_name"];
                                             break;
                                         }
                                     }
                                     _lat =[[[_locationDict objectForKey:@"geometry"]objectForKey:@"location"]objectForKey:@"lat"];
                                     _lng =[[[_locationDict objectForKey:@"geometry"]objectForKey:@"location"]objectForKey:@"lng"];
                                 }
                                 
                                 if (_postalCode.length>0)
                                 {
                                     if (completion)
                                         completion(YES,_postalCode);
                                 }
                                 else
                                 {
                                     if (completion)
                                         completion(NO,nil);
                                 }
                             }
                             else
                             {
                                 if (completion)
                                     completion(NO,nil);
                             }
                             
                          }];
                     }
                     else
                     {
                         if (completion)
                             completion(NO,nil);
                     }
                 }
             }
             else
             {
                 if (completion)
                     completion(NO,nil);
             }
         }
     }];
}


- (void)checkPostalCode:(NSString *)postalCode completion:(void(^)(BOOL, NSError *))completion
{
    NSString *_urlString    = [NSString stringWithFormat:@"%@%@",APPURL_2,CHECK_POSTALCODE];
    
    NSString *_postParameters =[NSString stringWithFormat:@"postalCode=%@",postalCode];
    
    NSData *_postData = [_postParameters dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *_postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[_postData length]];
    
    NSMutableURLRequest *_URLrequest = [[NSMutableURLRequest alloc] init];
    [_URLrequest setURL:[NSURL URLWithString:_urlString]];
    [_URLrequest setHTTPMethod:@"POST"];
    [_URLrequest setValue:_postLength forHTTPHeaderField:@"Content-Length"];
    [_URLrequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [_URLrequest setHTTPBody:_postData];
    
    [NSURLConnection sendAsynchronousRequest:_URLrequest  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error){
         if (error)
         {
             NSError*_error=nil;
             if (error.code==-1009)
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Network error",@"title",@"Please check your internet connection.",@"description", nil]];
             }
             else
             {
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Error",@"title",@"There is some error from server. Please try again later.",@"description", nil]];
             }
             
             if (completion)
                 completion(NO,_error);

         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];

             if ([[_dictionary objectForKey:@"status"]boolValue])
             {
                 if (completion)
                     completion(YES,nil);
             }
             else
             {
                 NSError*_error=nil;
                 _error = [NSError errorWithDomain:@"Error" code:200 userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Coming Soon",@"title",@"LUXit is not yet available in your city. We will notify you as soon as LUXit is available in your area. Thank you!",@"description", nil]];
                 
                 if (completion)
                     completion(NO, _error);
             }

             
         }
     }];
}

@end

APIManager *API(void)
{
    return [[APIManager alloc]init];
}
