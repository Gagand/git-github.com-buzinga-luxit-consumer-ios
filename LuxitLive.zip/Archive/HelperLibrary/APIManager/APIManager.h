//
//  APIManager.h
//  Luxit
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface APIManager : NSObject

- (void)loginWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)signupWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)updateUserInfoWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)sendPasswordWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)addPaymentMethodWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)updatePasswordWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)getMenuOptionsWithCompletion:(void(^)(BOOL,NSError*))completion;

- (void)createJobWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*,NSString *, NSString *))completion;

- (void)activateJobWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)fetchLastCreatedJobStatusWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)extendJobTimeWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)cancelJobWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*,BOOL))completion;

- (void)markJobAsPaidWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)completeJobWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)sendFeedbackForJobWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)fetchPlaceNameForLat:(NSString *)lat lng:(NSString *)lng completion:(void(^)(NSString *,BOOL))completion;

- (void)fetchJobHistoryForJobWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*,NSMutableArray *))completion;

- (void)updateDeviceTokenWithAttributes:(NSDictionary *)attributes completion:(void(^)(BOOL,NSError*))completion;

- (void)fetchPostalCodeForAddress:(NSString *)address completion:(void(^)(BOOL,NSString *))completion;

- (void)checkPostalCode:(NSString *)postalCode completion:(void(^)(BOOL, NSError *))completion;

@end

APIManager *API(void);
