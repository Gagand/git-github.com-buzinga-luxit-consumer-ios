//
//  CustomKeyboard.m
//  Luxit
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "CustomKeyboard.h"
#import "Constant.h"

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"

@implementation CustomKeyboard

- (UIToolbar *)getToolbarWithPrevNextDone:(BOOL)prevEnabled :(BOOL)nextEnabled
{
    UIToolbar *_toolbar = [[UIToolbar alloc] init];
    [_toolbar setBarTintColor:COLOR_THEME_DARKGRAY];
    _toolbar.translucent=NO;
    [_toolbar setTintColor:COLOR_THEME_BROWN];
    [_toolbar setBarStyle:UIBarStyleBlackTranslucent];
    [_toolbar sizeToFit];
  
    NSMutableArray *_itemsArray = [[NSMutableArray alloc] init];
   
    UISegmentedControl *_tabNavigation = [[UISegmentedControl alloc] initWithItems:[NSArray arrayWithObjects:@"Previous", @"Next", nil]];
    _tabNavigation.segmentedControlStyle = UISegmentedControlStyleBar;
    [_tabNavigation setEnabled:prevEnabled forSegmentAtIndex:0];
    [_tabNavigation setEnabled:nextEnabled forSegmentAtIndex:1];
    _tabNavigation.momentary = YES;
    [_tabNavigation addTarget:self action:@selector(segmentedControlHandler:) forControlEvents:UIControlEventValueChanged];
  
    UIBarButtonItem *_barSegment = [[UIBarButtonItem alloc] initWithCustomView:_tabNavigation];
    [_itemsArray addObject:_barSegment];

    UIBarButtonItem *_flexBtn=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    [_itemsArray addObject:_flexBtn];
    
    UIBarButtonItem *_doneBtn =[[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(doneBtnAction:)];
    [_itemsArray addObject:_doneBtn];

    _toolbar.items = _itemsArray;
   
    return _toolbar;
}


- (UIToolbar *)getToolbarWithDone
{
    UIToolbar *_toolbar = [[UIToolbar alloc] init];
    [_toolbar setBarTintColor:COLOR_THEME_DARKGRAY];
    _toolbar.translucent=NO;
    [_toolbar setTintColor:COLOR_THEME_BROWN];
    [_toolbar setBarStyle:UIBarStyleBlackTranslucent];
    [_toolbar sizeToFit];
    
    NSMutableArray *_itemsArray = [[NSMutableArray alloc] init];
    
    UIBarButtonItem *_flexBtn=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    [_itemsArray addObject:_flexBtn];
    
    UIBarButtonItem *_doneBtn =[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(doneBtnAction:)];
    [_itemsArray addObject:_doneBtn];
    
    _toolbar.items = _itemsArray;
    return _toolbar;
}


- (UIToolbar *)getToolbarWithCancel
{
    UIToolbar *_toolbar = [[UIToolbar alloc] init];
    [_toolbar setBarTintColor:COLOR_THEME_DARKGRAY];
    _toolbar.translucent=NO;
    [_toolbar setTintColor:COLOR_THEME_BROWN ];
    [_toolbar setBarStyle:UIBarStyleBlackTranslucent];
    [_toolbar sizeToFit];
    
    NSMutableArray *_itemsArray = [[NSMutableArray alloc] init];
    
    UIBarButtonItem *_flexBtn=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    [_itemsArray addObject:_flexBtn];
    
    UIBarButtonItem *_doneBtn =[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelBtnAction)];
    [_itemsArray addObject:_doneBtn];
    
    _toolbar.items = _itemsArray;
    return _toolbar;
}


- (void)segmentedControlHandler:(id)sender
{
    if (_delegate)
    {
        switch ([(UISegmentedControl *)sender selectedSegmentIndex])
        {
            case 0:
                [_delegate customKeyboardAction:ATPrevious];
                break;
            case 1:
                [_delegate customKeyboardAction:ATNext];
                break;
            default:
                break;
        }
    }
}


- (void)doneBtnAction:(id)sender
{
    if (_delegate)
    {
        [_delegate customKeyboardAction:ATDone];
    }
}


-(void)cancelBtnAction
{
    if (_delegate)
    {
        [_delegate customKeyboardAction:ATCancel];
    }
}

@end
