//
//  CustomKeyboard.h
//  Luxit
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

typedef enum {
    ATNext,
    ATPrevious,
    ATCancel,
    ATDone
}ActioType;

#import <Foundation/Foundation.h>

@protocol CustomKeyboardDelegate

@optional
- (void)customKeyboardAction:(ActioType)action;

@end

@interface CustomKeyboard : NSObject

@property (nonatomic, strong) id<CustomKeyboardDelegate> delegate;

- (UIToolbar *)getToolbarWithPrevNextDone:(BOOL)prevEnabled :(BOOL)nextEnabled;
- (UIToolbar *)getToolbarWithDone;
- (UIToolbar *)getToolbarWithCancel;

@end
