//
//  CustomComponents.h
//  Luxit
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

typedef enum {
    TFTextEditingBegin,
    TFTextEditingEnd,
    TFTextEditingReturn
}TFStatus;

typedef void (^ButtonActionBlock)(UIButton *);
typedef void (^AlertViewCompletionBlock)(UIAlertView *,NSInteger);
typedef void (^ActionSheetCompletionBlock)(UIActionSheet *,NSInteger);
typedef void (^TextEditingCompletionBlock)(id,TFStatus);

#define kCCBackgroundColor  @"BackgroundColor"     //UIColor
#define kCCTintColor        @"TintColor"           //UIcolor
#define kCCTextColor        @"TextColor"           //UIColor
#define kCCTextAlignment    @"TextAlignment"       //NSNumber With int Value
#define kCCTextFont         @"TextFont"            //UIFont
#define kCCCornerRadius     @"CornerRadius"        //NSNumber With float Value
#define kCCBorderColor      @"BorderColor"         //UIColor
#define kCCBorderWidth      @"BorderWidth"         //NSNumber With float Value
#define kCCImage            @"Image"               //UIImage
#define kCCTag              @"Tag"                 //NSNumber With int Value
#define kCCContentMode      @"ContentMode"         //NSNumber With int Value
#define kCCAlpha            @"Alpha"               //NSNumber With float Value
#define kCCText             @"Text"                //NSString
#define kCCPlaceHolderText  @"PlaceHolder"         //NSString
#define kCCPlaceHolderColor @"PlaceHolderColor"    //UIColor
#define kCCLeftView         @"LeftView"            //UIView
#define kCCRightView        @"RightView"           //UIView
#define kCCSeparatorColor   @"SeparatorColor"      //UIColor
#define kCCSecureEntery     @"SecureEntery"        //NSNumber With int Value(0,1)
#define kCCReturnKey        @"ReturnKey"           //NSNumber With int Value
#define kCCKeyboardType     @"KeyboardType"        //NSNumber With int Value
#define kCCBarTintColor     @"BarTintColor"        //UIcolor


#import <Foundation/Foundation.h>

@interface CustomComponents : NSObject

+ (CustomComponents *)singleton;
- (UIButton *)buttonWithAttributes:(NSDictionary *)attributes frame:(CGRect)frame completion:(void(^)(UIButton *))completion;
- (UIImageView *)imageViewWithAttributes:(NSDictionary *)attributes frame:(CGRect)frame;
- (UIView *)viewWithAttributes:(NSDictionary *)attributes frame:(CGRect)frame;
- (UILabel *)labelWithAttributes:(NSDictionary *)attributes frame:(CGRect)frame;
- (UITextField *)textFieldWithAttributes:(NSDictionary *)attributes frame:(CGRect)frame target:(id)target completion:(void(^)(UITextField *,TFStatus))completion;
- (UITextView *)textViewWithAttributes:(NSDictionary *)attributes frame:(CGRect)frame target:(id)target completion:(void(^)(UITextField *,TFStatus))completion;
- (UITableView *)tableViewWithAttributes:(NSDictionary *)attributes frame:(CGRect)frame target:(id)target;

- (void)showAlertWithTitle:(NSString *)title message:(NSString *)message buttons:(NSArray *)buttons completion:(void(^)(NSInteger))completion;
- (void)showActionSheetWithCompletion:(void(^)(UIActionSheet *,NSInteger))completion actionSheet:(UIActionSheet *)actionSheet;
- (void)customizeNavigationBarWithAttributes:(NSDictionary *)attributes navigationController:(UINavigationController *)controller;

@end
CustomComponents *ccManager(void);