//
//  CardInfo.m
//  LUXit
//
//  Created by GP on 23/12/15.
//  Copyright © 2015 LUXit. All rights reserved.
//

#import "CardInfo.h"

@implementation CardInfo

- (id)initWithAttributes:(NSDictionary *)attributes
{
    self=[super init];
    
    if (self)
    {
        [self updateWithAttributes:attributes];
    }
    return self;
}


- (void)updateWithAttributes:(NSDictionary *)attributes
{
    if (attributes.count>0)
    {
        _cardNumber =[attributes objectForKey:@"cardNumber"];
        _cardHolderName=[attributes objectForKey:@"cardHolderName"];
        _cvv=[attributes objectForKey:@"cvv"];
        _expiryMonth=[attributes objectForKey:@"expiryMonth"];
        _expiryYear=[attributes objectForKey:@"expiryYear"];
        _firstName=[attributes objectForKey:@"firstName"];
        _lastName=[attributes objectForKey:@"lastName"];
    }
    else
    {
        _cardNumber=nil;
        _cardHolderName=nil;
        _cvv=nil;
        _expiryMonth=nil;
        _expiryYear=nil;
        _encryptedCardNumber=nil;
        _encryptedCVVNumber=nil;
    }
}
@end
