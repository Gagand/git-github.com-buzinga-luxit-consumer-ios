//
//  CardInfo.h
//  LUXit
//
//  Created by GP on 23/12/15.
//  Copyright © 2015 LUXit. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CardInfo : NSObject

@property (nonatomic, retain) NSString *cardNumber;
@property (nonatomic, retain) NSString *cardHolderName;
@property (nonatomic, retain) NSString *firstName;
@property (nonatomic, retain) NSString *lastName;
@property (nonatomic, retain) NSString *cvv;
@property (nonatomic, retain) NSString *expiryMonth;
@property (nonatomic, retain) NSString *expiryYear;
@property (nonatomic, retain) NSString *encryptedCardNumber;
@property (nonatomic, retain) NSString *encryptedCVVNumber;

- (id)initWithAttributes:(NSDictionary *)attributes;
- (void)updateWithAttributes:(NSDictionary *)attributes;

@end
