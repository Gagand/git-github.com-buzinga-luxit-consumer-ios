//
//  PaypalManager.h
//  LUXit
//
//  Created by GP on 16/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

typedef enum
{
    TSError,
    TSCancelled,
    TSPaid,
    TSPaypalError
}TransactionStatus;

#import <Foundation/Foundation.h>

#import "JobDetail.h"
#import "PayPalMobile.h"

@interface PaypalManager : NSObject<PayPalPaymentDelegate, PayPalFuturePaymentDelegate, PayPalProfileSharingDelegate>
{
    JobDetail                   *_jobDetail;
    PayPalPaymentViewController *_paymentViewController;
}

@property (nonatomic, copy)void(^finishedPayingByPaypal)(NSString *,TransactionStatus);
@property(nonatomic, strong, readwrite) NSString *environment;
@property(nonatomic, strong, readwrite) NSString *resultText;
@property(nonatomic, strong, readwrite) PayPalConfiguration *payPalConfig;

+ (PaypalManager *)singleton;
- (void)payForJobDetail:(JobDetail*)jobDetail;
- (void)refundAmount:(float)amount forPaykey:(NSString *)payKey completion:(void(^)(NSString *,TransactionStatus))completion;
- (void)makePaymentWithAmount:(float)amount completion:(void(^)(NSString *,TransactionStatus))completion;

@end

PaypalManager *paypalManager(void);