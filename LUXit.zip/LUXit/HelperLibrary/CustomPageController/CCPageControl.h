//
//  CCPageControl.h
//  Luxit
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <UIKit/UIControl.h>
#import <UIKit/UIKitDefines.h>
#import <Foundation/Foundation.h>

typedef enum
{
	CCPageControlTypeOnFullOffFull,
	CCPageControlTypeOnFullOffEmpty,
	CCPageControlTypeOnEmptyOffFull,
	CCPageControlTypeOnEmptyOffEmpty,
}
CCPageControlType ;


@interface CCPageControl : UIControl 
{
	NSInteger numberOfPages ;
	NSInteger currentPage ;
}

@property (nonatomic) NSInteger numberOfPages ;
@property (nonatomic) NSInteger currentPage ;
@property (nonatomic) BOOL hidesForSinglePage ;
@property (nonatomic) BOOL defersCurrentPageDisplay ;
@property (nonatomic) CCPageControlType type ;
@property (nonatomic,retain) UIColor *onColor ;
@property (nonatomic,retain) UIColor *offColor ;
@property (nonatomic) CGFloat indicatorDiameter ;
@property (nonatomic) CGFloat indicatorSpace ;

- (void)updateCurrentPageDisplay ;
- (CGSize)sizeForNumberOfPages:(NSInteger)pageCount ;
- (id)initWithType:(CCPageControlType)theType ;

@end

