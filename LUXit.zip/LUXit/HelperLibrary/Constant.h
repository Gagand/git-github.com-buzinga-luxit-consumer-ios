
#import "CardInfo.h"
#import "eWAYHelper.h"
#import "APNManager.h"
#import "FBManager.h"
#import "APIManager.h"
#import "CustomLayer.h"
#import "MBProgressHUD.h"
#import "LAAppDelegate.h"
#import "PaypalManager.h"
#import "CustomComponents.h"
#import "UIImage+FontAwesome.h"
#import "NSString+FontAwesome.h"
#import "NSMutableAttributedString+CustomString.h"
#import "UIViewController+LAParentViewController.h"


#define FONT_AVENIRNEXT_REGULAR   @"Avenir Next"
#define FONT_AVENIRNEXT_BOLD      @"AvenirNext-Bold"
#define FONT_AVENIRNEXT_DEMI      @"AvenirNext-DemiBold"
#define FONT_AVENIRNEXT_LIGHT     @"AvenirNext-UltraLight"
#define FONT_AVENIRNEXT_MEDIUM    @"AvenirNext-Medium"


#define   APP_THEME_COLOR       [UIColor colorWithRed:76.0/255.0f   green:162.0/255.0f  blue:203.0/255.0f   alpha:1.0]
#define   COLOR_THEME_BROWN     [UIColor colorWithRed:175.0/255.0   green:131.0/255.0   blue:84.0/255.0     alpha:1.0]
#define   COLOR_THEME_LIGHTBLUE [UIColor colorWithRed:157.0/255.0   green:219.0/255.0   blue:255.0/255.0    alpha:1.0]
#define   COLOR_THEME_DARKGRAY  [UIColor colorWithRed:51.0/255.0    green:50.0/255.0    blue:52.0/255.0     alpha:1.0]
#define   COLOR_THEME_LIGHTPINK [UIColor colorWithRed:253.0/255.0   green:215.0/255.0   blue:187.0/255.0    alpha:1.0]


#define DEGREES_IN_RADIANS(x)   (M_PI * x / 180.0)


#define  APPURL                     @"http://register.luxit.me/index.php/userapis/"
//#define  APPURL                     @"http://register.luxit.me/index.php/myuserapis/"
#define  APPURL_1                   @"http://register.luxit.me/index.php/apis/"
#define  APPURL_2                   @"http://register.luxit.me/index.php/Jobapis/"
//#define  APPURL_2                   @"http://register.luxit.me/index.php/Myjobs/"
#define  APPURL_3                   @"http://register.luxit.me/index.php/paymentapis/"
#define  IMAGEURL                   @"http://register.luxit.me/app/webroot/img/profile/%@"
#define  APPURL_4_Test              @"http://register.luxit.me/index.php/Jobapis2/"



#define  LOGIN_EXTENSION            @"login"
#define  SIGNUP_EXTENSION           @"signup"
#define  UPDATEPROFILE_EXTENSION    @"update_user"
#define  FORGOTPASSWORD_EXTENSION   @"forget_password"
#define  ADDPAYMENTMETHOD_EXTENSION @"add_payment_method"
#define  MENUITEMS_EXTENSION        @"menuoptionlist"
#define  CREATEJOB_EXTENSION        @"createJob"
#define  EXTENDTIME_EXTENSION       @"extend_search_duration"
#define  CANCELJOB_EXTENSION        @"consumer_cancel_job"
#define  UPDATEPASSWORD_EXTENSION   @"changePassword"
#define  JOBSTATUS_EXTENSION        @"last_created_job_status"
#define  MARKASPAID_EXTENSION       @"payment"
#define  COMPLETEJOB_EXTENSION      @"completejob"
#define  FEEDBACK_EXTENSION         @"sendfeedback"
#define  GETJOBS_EXTENSION          @"get_consumer_job_history"
#define  UPDATETOKEN_EXTENSION      @"update_deviceToken"
#define  ACTIVATE_JOBSTATUS         @"update_jobStatus"
#define  CHECK_POSTALCODE           @"checkzipcode"

#define  FBIconImagePath            @"https://graph.facebook.com/%@/picture?width=%@&height=%@"


#define  SERVER_TIMEZONE         @"Australia/Sydney"
#define  SERVER_TIMEFORMAT       @"yyyy-MM-dd HH:mm:ss"
