//
//  APNManager.m
//  Luxit
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "APNManager.h"
#import "Constant.h"

@implementation APNManager

#pragma mark- Singleton

static APNManager * _sharedAPNManager = nil;


+(APNManager *)singleton
{
    @synchronized([APNManager class])
    {
		if (!_sharedAPNManager)
            _sharedAPNManager=[[self alloc] init];
		return _sharedAPNManager;
	}
	return nil;
}


+(id)alloc{
	@synchronized([APNManager class]){
		_sharedAPNManager = [super alloc];
		return _sharedAPNManager;
	}
	return nil;
}


-(id)init
{
	self = [super init];
	if (self != nil)
    {
        _notificationPopover=[[NotificationPopover alloc]init];
        appDelegate().receiveRemoteNotification=^(NSDictionary *dictionary)
        {
            [self handlePushNotificationOnReception:dictionary];
        };
	}
	return self;
}


- (void)handlePushNotificationOnReception:(NSDictionary *)userInfo
{
    if (!appDelegate().userInfo.isUserAvailable)
    {
        return;
    }
    
    NSDictionary *_jobDescriptionDictionary=[[[userInfo objectForKey:@"aps"]objectForKey:@"record"]objectForKey:@"jobDescription"];
    
    int _status=0;
    
    if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Searching"])
    {
        _status=0;
    }
    else if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Accept"])
    {
        _status=1;
    }
    else if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Cancel by consumer"])
    {
        _status=2;
        
        if (![[_jobDescriptionDictionary objectForKey:@"Paid"]boolValue])
        {
            _status=6;
        }
    }
    else if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Cancel by technician"])
    {
        _status=3;
    }
    else if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Working"])
    {
        _status=4;
    }
    else if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Completed"])
    {
        _status=5;
    }
    else if ([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Feedback"])
    {
        _status=8;
    }
    else if([[_jobDescriptionDictionary objectForKey:@"jobStatus"]isEqualToString:@"Feedback Received"])
    {
        if (![[_jobDescriptionDictionary objectForKey:@"Paid"]boolValue])
        {
            _status=7;
        }
        else
        {
            _status=9;
        }
    }
    
    else
    {
        _status=0;
    }
    
    
    if ([self getStatusValue]==_status)
    {
        appDelegate().jobDetail.changed=NO;
    }
    else
    {
        NSMutableDictionary *_jobDetail=[NSMutableDictionary dictionaryWithCapacity:10];
      
        if ([_jobDescriptionDictionary.allKeys containsObject:@"consumer_payable_amount"] && (NSNull *)[_jobDescriptionDictionary objectForKey:@"consumer_payable_amount"]!=[NSNull null] )
        {
             [_jobDetail setObject:[NSString stringWithFormat:@"%f",[[_jobDescriptionDictionary objectForKey:@"consumer_payable_amount"]floatValue]] forKey:@"customerPayablePrice"];
        }
        
        if (appDelegate().jobDetail.status!=JSNoJob && appDelegate().jobDetail.isJobAvailable)
        {
            [_jobDetail setObject:@(appDelegate().jobDetail.isJobAvailable) forKey:@"transationType"];
            [_jobDetail setObject:appDelegate().jobDetail.transactionId forKey:@"transactionId"];
        }
        
        
        [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"job_id"] forKey:@"id"];
        [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"itemName"] forKey:@"itemName"];
        [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"itemPrice"] forKey:@"itemPrice"];
        
        NSDateFormatter *_dateFormatter = [[NSDateFormatter alloc] init];
        NSTimeZone *_standardTimeZone = [NSTimeZone timeZoneWithName:SERVER_TIMEZONE];
        [_dateFormatter setTimeZone:_standardTimeZone];
        [_dateFormatter setDateFormat:SERVER_TIMEFORMAT];
        
        NSDate *_jobTiming = [_dateFormatter dateFromString:[_jobDescriptionDictionary objectForKey:@"date"]];
        NSDateFormatter *_newDateFormatter=[[NSDateFormatter alloc]init];
        [_newDateFormatter setDateFormat:SERVER_TIMEFORMAT];
        [_jobDetail setObject:[_newDateFormatter stringFromDate:_jobTiming] forKey:@"date"];
        
        [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"location"]  forKey:@"location"];
        [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"search_duration"]  forKey:@"timeInterval"];
        [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"cancel_amount"] forKey:@"cancellationFees"];
     
        if ([_jobDescriptionDictionary.allKeys containsObject:@"technician_cancellation_fee"] && (NSNull*)[_jobDescriptionDictionary objectForKey:@"technician_cancellation_fee"]!=[NSNull null])
        {
              [_jobDetail setObject:[_jobDescriptionDictionary objectForKey:@"technician_cancellation_fee"] forKey:@"technicianCancellationFees"];
        }
        else
        {
           [_jobDetail setObject:@"0" forKey:@"technicianCancellationFees"];
                
        }
        
        if (_status==0)
        {
             [_jobDetail setObject:[NSMutableDictionary dictionaryWithCapacity:0]  forKey:@"technician"];
        }
        else
        {
            NSMutableDictionary *_technicianInfo=[NSMutableDictionary dictionaryWithDictionary:[[[userInfo objectForKey:@"aps"]objectForKey:@"record"]objectForKey:@"technicianInfo"]];
           
            if ([((NSDictionary *)[[[userInfo objectForKey:@"aps"]objectForKey:@"record"]objectForKey:@"technicianInfo"]).allKeys containsObject:@"rating"] && (NSNull *)[((NSDictionary *)[[[userInfo objectForKey:@"aps"]objectForKey:@"record"]objectForKey:@"technicianInfo"]) objectForKey:@"rating"]!=[NSNull null]) {
            }
            else
            {
                [_technicianInfo setObject:@"0" forKey:@"rating"];
            }
            
            [_jobDetail setObject:_technicianInfo  forKey:@"technician"];
         
        }
        if (_status==3)
        {
             [_jobDetail setObject:@"0"  forKey:@"timeInterval"];
        }
        
        [_jobDetail setObject:[NSString stringWithFormat:@"%i",_status]  forKey:@"status"];
       
        [[NSUserDefaults standardUserDefaults]setObject:_jobDetail forKey:@"LastJobDetail"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [appDelegate().jobDetail updateWithAttributes:_jobDetail];
         appDelegate().jobDetail.changed=YES;
  
        NSString *_string=[self getMessageStringForStatus:_status];

        [self playAlert];
        
        _notificationPopover.showChatView=nil;
        _notificationPopover.nameLabel.text=@"Luxit Status";
        _notificationPopover.messageLabel.text=_string;
        [_notificationPopover updateViewAdjustment];
        [_notificationPopover showPopup];
        
        if(_updateViewOnReceptionOfRemoteNotification)
        {
            _updateViewOnReceptionOfRemoteNotification();
        }
    }
}


- (int)getStatusValue
{
    if (appDelegate().jobDetail.status==JSSearching)
        return 0;
    else if (appDelegate().jobDetail.status==JSPending)
        return 1;
    else if (appDelegate().jobDetail.status==JSNoJob)
        return 2;
    else if (appDelegate().jobDetail.status==JSCancelByTechnician)
        return 3;
    else if (appDelegate().jobDetail.status==JSStarted)
        return 4;
    else if (appDelegate().jobDetail.status==JSCompleted)
        return 5;
    else if (appDelegate().jobDetail.status==JSCancelledUnpaid)
        return 6;
    else if (appDelegate().jobDetail.status==JSCompleteUnpaid)
        return 7;
    else if (appDelegate().jobDetail.status==JSNeedFeedback)
        return 8;
    else
        return 9;
}


- (NSString *)getMessageStringForStatus:(int)status
{
    if (status==1)
    {
       return [NSString stringWithFormat:@"Please allow up to an hour for %@ to arrive",appDelegate().jobDetail.technician.firstName];
    }
    else if (status==3)
    {
        return [NSString stringWithFormat:@"%@  is no longer able to make your appointment",appDelegate().jobDetail.technician.firstName];
    }
    else if (status==4)
    {
        return [NSString stringWithFormat:@"%@ has arrived",appDelegate().jobDetail.technician.firstName];
    }
    else if (status==5)
    {
        return @"Rate your technician";
    }
    else{
        return @"";
    }
}


- (void)playAlert
{
    NSURL *fileURL = [NSURL URLWithString:@"/System/Library/Audio/UISounds/sms-received1.caf"];
    SystemSoundID soundID;
    AudioServicesCreateSystemSoundID((__bridge_retained CFURLRef)fileURL,&soundID);
    AudioServicesPlaySystemSound(soundID);
}

@end

APNManager *apnManager(void)
{
    return [APNManager singleton];
}
