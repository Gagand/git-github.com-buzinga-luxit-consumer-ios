//
//  NotificationPopover.h
//  Luxit
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//


#import "NotificationPopover.h"
#import "Constant.h"

@implementation NotificationPopover

- (id)init
{
    self = [super init];
    if (self)
    {
        self.frame=CGRectMake(0.0, 0.0, appDelegate().window.frame.size.width, 80.0);
        self.backgroundColor=COLOR_THEME_DARKGRAY;
        self.clipsToBounds=YES;
        
        _nameLabel=[[UILabel alloc]initWithFrame:CGRectMake(10.0, 25.0, appDelegate().window.frame.size.width-20, 20.0)];
        _nameLabel.textColor=[UIColor whiteColor];
        _nameLabel.font=[UIFont fontWithName:FONT_AVENIRNEXT_BOLD size:14.0];
        [self addSubview:_nameLabel];
        
        _messageLabel=[[UILabel alloc]initWithFrame:CGRectMake(10.0, 40.0, appDelegate().window.frame.size.width-40, 20.0)];
        _messageLabel.textColor=[UIColor whiteColor];
        _messageLabel.font=[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0];
        [self addSubview:_messageLabel];
        [appDelegate().window addSubview:self];
      
        
        UIButton *_popupBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        _popupBtn.frame=self.bounds;
        [_popupBtn addTarget:self action:@selector(chatPopOverViewClicked) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_popupBtn];
        
        UIButton *_closeBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [_closeBtn setImage:[UIImage imageNamed:@"Close.png"] forState:UIControlStateNormal];
        _closeBtn.frame=CGRectMake(self.frame.size.width-30.0, 5.0, 30.0, 80.0);
        [_closeBtn addTarget:self action:@selector(closeBtnAction) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_closeBtn];
        
        self.frame=CGRectMake(0.0, 0.0, appDelegate().window.frame.size.width, 0.0);
        self.clipsToBounds=YES;
    }
    return self;
}


- (void)updateViewAdjustment
{
    NSString *_messageString=_messageLabel.text;
    _messageLabel.frame=CGRectMake(10.0, 45.0, appDelegate().window.frame.size.width-45, 20.0);
    _messageLabel.numberOfLines=0;
    _messageLabel.text=_messageString;
    [_messageLabel sizeToFit];
}


- (void)showPopup
{
    [appDelegate().window bringSubviewToFront:self];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    self.frame=CGRectMake(0.0, 0.0, appDelegate().window.frame.size.width, 80.0);
    [UIView commitAnimations];
    [self performSelector:@selector(hidePopup) withObject:nil afterDelay:2.5];
}


- (void)hidePopup
{
    [appDelegate().window bringSubviewToFront:self];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3];
    self.frame=CGRectMake(0.0, 0.0, appDelegate().window.frame.size.width, 0.0);
    [UIView commitAnimations];
}


-(void)closeBtnAction
{
    [self hidePopup];
}


- (void)chatPopOverViewClicked
{
    self.frame=CGRectMake(0.0, 0.0, appDelegate().window.frame.size.width, 0.0);
    if(_showChatView)
     _showChatView();
}

@end
