//
//  APNManager.h
//  Luxit
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "NotificationPopover.h"
#import <AudioToolbox/AudioToolbox.h>

@interface APNManager : NSObject
{
    NotificationPopover *_notificationPopover;
}
@property (nonatomic, copy)void(^updateViewOnReceptionOfRemoteNotification)();

+ (APNManager *)singleton;

@end

APNManager *apnManager(void);