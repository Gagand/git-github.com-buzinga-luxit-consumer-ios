//
//  FBAPI.m
//  Luxit
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//


#import "FBManager.h"
#import "LAAppDelegate.h"

@implementation FBManager

#pragma mark- Singleton
static FBManager * _sharedFBManager = nil;

+(FBManager *)singleton
{
    @synchronized([FBManager class])
    {
		if (!_sharedFBManager)
        {
          _sharedFBManager=[[self alloc] init];
        }
		return _sharedFBManager;
	}
	return nil;
}


+(id)alloc
{
	@synchronized([FBManager class])
    {
		_sharedFBManager = [super alloc];
		return _sharedFBManager;
	}
	return nil;
}


-(id)init
{
	self = [super init];
	if (self != nil)
    {
        
	}
	return self;
}


-(void)checkFBsession:(void(^)(BOOL))validSession
{
    NSArray *array = [[NSArray alloc]initWithObjects:
                      @"email",
                      nil];
    
    FBSession *session=[FBSession activeSession];
    [session closeAndClearTokenInformation];
    [session close];
   
    [[FBSession activeSession] closeAndClearTokenInformation];
    [[FBSession activeSession] close];
    [FBSession setActiveSession:nil];
    
    appDelegate().session = [[FBSession alloc] initWithPermissions:array];
    [appDelegate().session openWithBehavior:FBSessionLoginBehaviorWithFallbackToWebView completionHandler:^(FBSession *session, FBSessionState status, NSError *error)
    {
        if (error)
        {
            if(validSession)
                validSession(NO);
            return;
        }
        if (status == FBSessionStateOpenTokenExtended)
        {
        }
        else if (status == FBSessionStateOpen)
        {
        }
        else if (status == FBSessionStateClosed)
        {
            return;
        }
        else if (status == FBSessionStateClosedLoginFailed)
        {
        }
        else if (status == FBSessionStateCreated)
        {
        }
        else if (status == FBSessionStateCreatedOpening)
        {
        }
        else if (status == FBSessionStateCreatedTokenLoaded)
        {
        }
        if (FB_ISSESSIONOPENWITHSTATE(status))
        {
            [FBSession setActiveSession:appDelegate().session];
            [[NSUserDefaults standardUserDefaults]setObject:appDelegate().session.accessTokenData.accessToken forKey:@"FBAccessToken"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            if(validSession)
                validSession(YES);
        }else{
            if(validSession)
                validSession(NO);
        }
    }];
}


-(void)getUserInfo:(void (^)(NSDictionary*))finishedPickingInfo  failed:(void (^)(NSError *))failure
{
    NSString *_urlString=[NSString stringWithFormat:@"https://graph.facebook.com/me?fields=email,first_name,last_name,id,name&access_token=%@",[[NSUserDefaults standardUserDefaults]objectForKey:@"FBAccessToken"]];
  
    [NSURLConnection sendAsynchronousRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[_urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]]  queue:[NSOperationQueue mainQueue] completionHandler:
     ^(NSURLResponse *response, NSData *responseData, NSError *error)
    {
         if (error)
         {
             if(failure)
             {
                 failure(error);
             }
         }
         else
         {
             NSDictionary *_dictionary=[NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
             if ([_dictionary isKindOfClass:[NSDictionary class]])
             {
                 if(finishedPickingInfo)
                 {
                     finishedPickingInfo(_dictionary);
                 }
             }
             else
             {
                 if(failure)
                 {
                     failure(nil);
                 }
             }
         }
     }];
}


- (void)signOut
{
    FBSession *session=[FBSession activeSession];
    [session closeAndClearTokenInformation];
    [session close];
    [[FBSession activeSession] closeAndClearTokenInformation];
    [[FBSession activeSession] close];
    [FBSession setActiveSession:nil];
}

@end

FBManager *fbManager(void)
{
 return [FBManager singleton];
}

