//
//  FBAPI.h
//  Luxit
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <FacebookSDK/FacebookSDK.h>

@interface FBManager : NSObject

+ (FBManager *)singleton;
- (void)checkFBsession:(void(^)(BOOL))validSession;
- (void)getUserInfo:(void (^)(NSDictionary*))finishedPickingInfo  failed:(void (^)(NSError *))failure;
- (void)signOut;

@end

FBManager *fbManager(void);