//
//  LAPlaceOrderVC.h
//  Luxit
//
//  Created by GP on 27/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MenuItem.h"
#import "LATermsAndConditionsVC.h"
#import "LAPrivacyPolicyVC.h"

@interface LAPlaceOrderVC : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    UIView  *_blackOpaqueLayerView;
    UIView *_containerView;
    UITableView *_tableView;
    UITextField *_dateTF;
    UITextField *_timeTF;
    UITextField *_addressTF;
    NSDateFormatter *_dateFormatter;
}

@property(nonatomic, copy) void(^finishedConfirmingBooking)(void);
@property(nonatomic, retain) MenuItem *menuItem;

@end
