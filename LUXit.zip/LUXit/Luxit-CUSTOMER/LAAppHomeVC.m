//
//  LAAppHomeVC.m
//  Luxit
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "LALoginVC.h"
#import "LAAppHomeVC.h"
#import "LARegisterVC.h"

@implementation LAAppHomeVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    
       
    [super viewDidLoad];
    
    NSArray *_colors=nil;
    _colors=@[
              COLOR_THEME_LIGHTPINK,
              COLOR_THEME_BROWN
              ];
    
    CustomLayer  *_customLayer=[[CustomLayer alloc]initWithFrame:self.view.bounds withColors:_colors gradientMode:GMVertical];
    [self.view addSubview:_customLayer];
    
    NSDictionary *_attributes=nil;
    _attributes=@{
                  kCCBackgroundColor: COLOR_THEME_DARKGRAY
                  };
    CGRect _frame=CGRectMake(3.0, 3.0, self.view.frame.size.width-6.0, self.view.frame.size.height-6.0);
    [self.view addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];
    
 
    self.automaticallyAdjustsScrollViewInsets = NO;

    NSMutableArray *_helpingScreensInfoArray=[[NSMutableArray alloc]init];
   
    [_helpingScreensInfoArray addObject:@{
                                          @"title": @"MAKE A BOOKING",
                                          @"description":@"Select a service and enter your location, we will find you a technician right now!",
                                          @"image":@"Tutorial_1.png"
                                          }];
    [_helpingScreensInfoArray addObject:@{
                                          @"title": @"TECHNICIAN PROFILE",
                                          @"description":@"Once a technician has accepted your booking, you can view the booking details",
                                          @"image":@"Tutorial_2.png"
                                          }];
  
    [_helpingScreensInfoArray addObject:@{
                                          @"title": @"RATE & REVIEW",
                                          @"description":@"After your booking is complete, rate & review your LUXit Technician",
                                          @"image":@"Tutorial_3.png"
                                          }];
    
    _scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0.0, 0.0, self.view.frame.size.width, self.view.frame.size.height-130.0)];
    _scrollView.delegate=self;
    _scrollView.pagingEnabled=YES;
    _scrollView.showsHorizontalScrollIndicator=NO;
    _scrollView.showsVerticalScrollIndicator=NO;
    [self.view addSubview:_scrollView];
    _scrollView.contentSize=CGSizeMake(3*_scrollView.frame.size.width, _scrollView.frame.size.height);
    
    for (int i=0; i<3; i++)
    {
        UIView *_containerView=[ccManager() viewWithAttributes:nil frame:CGRectMake(i*_scrollView.frame.size.width, 20.0, _scrollView.frame.size.width, _scrollView.frame.size.height-20)];
        [_scrollView addSubview:_containerView];
        
        NSDictionary *_attributes=nil;
        _attributes=@{
                      kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                      };
        CGRect _frame=CGRectMake(20.0, 18.0, _containerView.frame.size.width-40.0, 18.0);
       
        UILabel *_titleLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
       
        _attributes=@{
                      kASTextColor: COLOR_THEME_BROWN,
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0],
                      kASText:[[_helpingScreensInfoArray objectAtIndex:i]objectForKey:@"title"],
                      kASCharacterSpace:[NSNumber numberWithFloat:1.35]
                      };
        NSMutableAttributedString *_attributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
        _titleLabel.attributedText=_attributedString;
        
        [_containerView addSubview:_titleLabel];
        
        _attributes=@{
                      kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                      };
         _frame=CGRectMake(20.0, _frame.origin.y+_frame.size.height+10.0, _containerView.frame.size.width-40.0, 40.0);
        
        UILabel *_descriptionLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
        _descriptionLabel.numberOfLines=2;
       
        _attributes=@{
                      kASTextColor: COLOR_THEME_BROWN,
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:13.0],
                      kASText:[[_helpingScreensInfoArray objectAtIndex:i]objectForKey:@"description"],
                      kASCharacterSpace:[NSNumber numberWithFloat:0.26]
                      };
         _attributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
         _descriptionLabel.attributedText=_attributedString;
         [_containerView addSubview:_descriptionLabel];
        
        
        _attributes=@{
                      kCCContentMode:[NSNumber numberWithInt:UIViewContentModeScaleAspectFit],
                      kCCImage:[UIImage imageNamed:[[_helpingScreensInfoArray objectAtIndex:i]objectForKey:@"image"]]
                      };
         _frame=CGRectMake(20.0, _frame.origin.y+_frame.size.height+10.0, _containerView.frame.size.width-40.0, _containerView.frame.size.height-(_frame.origin.y+_frame.size.height+10.0)-5.0);
        [_containerView addSubview:[ccManager() imageViewWithAttributes:_attributes frame:_frame]];
    }
    
    _customPageController = [[CCPageControl alloc] init] ;
    _customPageController.backgroundColor=[UIColor clearColor];
    [_customPageController setCenter: CGPointMake(self.view.frame.size.width/2, self.view.frame.size.height-117.0)] ;
    [_customPageController setNumberOfPages:3] ;
    [_customPageController setCurrentPage: 0] ;
    [_customPageController setDefersCurrentPageDisplay: YES];
    [_customPageController setType: CCPageControlTypeOnFullOffFull] ;
    [_customPageController setOnColor:  COLOR_THEME_BROWN] ;
    [_customPageController setOffColor: [UIColor blackColor]] ;
    [_customPageController setIndicatorDiameter: 5.0f] ;
    [_customPageController setIndicatorSpace: 20.0f] ;
    [self.view addSubview: _customPageController] ;
    
    _colors=@[
              COLOR_THEME_BROWN,
              COLOR_THEME_LIGHTPINK
              ];
    _frame=CGRectMake(20.0, self.view.frame.size.height-100.0, self.view.frame.size.width-40.0, 44.0);
    _customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
    [self.view addSubview:_customLayer];
    
    
    _frame=CGRectMake(_frame.origin.x+1.5, _frame.origin.y+1.5, _frame.size.width-3.0, _frame.size.height-3.0);
  
    _attributes=@{
                  kCCBackgroundColor:COLOR_THEME_DARKGRAY
                  };
    UIButton *_registerButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
        [self registerButtonAction];
    }];
    
    _attributes=@{
                  kASTextColor: COLOR_THEME_BROWN,
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0],
                  kASText:@"REGISTER HERE",
                  kASCharacterSpace:[NSNumber numberWithFloat:1.35]
                  };

    NSMutableAttributedString *_attributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];

    [_registerButton setAttributedTitle:_attributedString forState:UIControlStateNormal];
    [[_registerButton titleLabel] setNumberOfLines:0];
    [[_registerButton titleLabel] setLineBreakMode:NSLineBreakByWordWrapping];
    [self.view addSubview:_registerButton];
    
    
    _attributedString = [[NSMutableAttributedString alloc] init];
    _attributes=@{
                  kASTextColor: COLOR_THEME_BROWN,
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:13.0],
                  kASText:@"Already registered?  ",
                  kASCharacterSpace:[NSNumber numberWithFloat:0.26]
                  };
    [_attributedString appendAttributedString:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
    
    _attributes=@{
                  kASTextColor: COLOR_THEME_BROWN,
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_BOLD size:13.0],
                  kASText:@"Log In",
                  kASCharacterSpace:[NSNumber numberWithFloat:0.26]
                  };
    [_attributedString appendAttributedString:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
    
    _frame=CGRectMake(0.0, _frame.size.height+_frame.origin.y, self.view.frame.size.width, 40.0);
   
    UIButton *_logInButton=[ccManager() buttonWithAttributes:nil frame:_frame completion:^(UIButton *sender)
    {
        [self loginButtonAction];
     }];
    [_logInButton setAttributedTitle:_attributedString forState:UIControlStateNormal];
    [[_logInButton titleLabel] setNumberOfLines:0];
    [[_logInButton titleLabel] setLineBreakMode:NSLineBreakByWordWrapping];
    [self.view addSubview:_logInButton];
    
    _upward=YES;
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"LastJobDetail"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
     appDelegate().updateAppStatus=nil;

}


#pragma mark------------------------------------------------------------
#pragma mark SCROLLVIEW DELEGATE
#pragma mark------------------------------------------------------------

-(void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView
{
    int page=_scrollView.contentOffset.x/_scrollView.frame.size.width;
    _customPageController.currentPage=page;
    [_customPageController updateCurrentPageDisplay];
}


- (void)scrollViewDidEndDecelerating:(UIScrollView *)sender
{
    int page=_scrollView.contentOffset.x/_scrollView.frame.size.width;
    _customPageController.currentPage=page;
    [_customPageController updateCurrentPageDisplay];
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONs
#pragma mark------------------------------------------------------------

- (void)registerButtonAction
{
    LARegisterVC *_registerVC=[[LARegisterVC alloc]init];
    [self.navigationController pushViewController:_registerVC animated:YES];
}


- (void)loginButtonAction
{
    LALoginVC *_loginVC=[[LALoginVC alloc]init];
    [self.navigationController pushViewController:_loginVC animated:YES];
}
@end
