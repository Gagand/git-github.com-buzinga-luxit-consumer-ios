//
//  JobDetail.m
//  Luxit
//
//  Created by GP on 28/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "JobDetail.h"

#define LOCAL_NOTIFICATION_TAG @"LOCAL_NOTIFICATION_TAG"

@implementation JobDetail

- (id)init
{
    self=[super init];
   
    if (self)
    {
        _technician=[[TechnicianInfo alloc]init];
        
        _dateFormatter=[[NSDateFormatter alloc]init];
    }
    return self;
}


- (void)updateWithAttributes:(NSDictionary *)attributes
{
    if (attributes.count>0)
    {
        NSLog(@"%@",attributes);
        
        _isJobAvailable=YES;
        
        _jobId=[attributes objectForKey:@"id"];
      
        _itemName=[attributes objectForKey:@"itemName"];
      
        _itemPrice=[[attributes objectForKey:@"itemPrice"]doubleValue];
       
        _timeInterval=[[attributes objectForKey:@"timeInterval"]doubleValue];
       
        _location=[attributes objectForKey:@"location"];
       
        _timeInterval=[[attributes objectForKey:@"timeInterval"]intValue];
       
        _cancellationFees=[[attributes objectForKey:@"cancellationFees"]floatValue];
        
        _technicianCancellationFees=0;
       
        if ([attributes.allKeys containsObject:@"technicianCancellationFees"])
        {
            _technicianCancellationFees=[[attributes objectForKey:@"technicianCancellationFees"]floatValue];
        }
        
        _customerPayablePrice =0.0;
        
        if ([attributes.allKeys containsObject:@"customerPayablePrice"])
        {
            _customerPayablePrice=[[attributes objectForKey:@"customerPayablePrice"]floatValue];
        }
        else
        {
            _customerPayablePrice=_itemPrice;
        }
        
        _discountedValue=0.0;
        
        _isDicounted=NO;
        
        _isFree=NO;
        
        if (_customerPayablePrice<_itemPrice)
        {
            _discountedValue=_itemPrice-_customerPayablePrice;
           
            _isDicounted=YES;
            
            if (_customerPayablePrice==0)
            {
                _isFree=YES;
            }
        }
        
        _isPaidByPaypal=NO;
        _transactionId=@"";
        
        if ([attributes.allKeys containsObject:@"transationType"])
        {
            if ([[attributes objectForKey:@"transationType"]integerValue]==1)
            {
                _isPaidByPaypal=YES;
                _transactionId=[attributes objectForKey:@"transactionId"];
            }
        }

        
        [_dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        
        _date=[_dateFormatter dateFromString:[attributes objectForKey:@"date"]];
      
        [_dateFormatter setDateFormat:@"MMMM dd, yyyy"];
        _dateString=[_dateFormatter stringFromDate:_date];
      
        
        [_dateFormatter setDateFormat:@"HH:mm"];
        _timeString=[_dateFormatter stringFromDate:_date];
        
        [self disableLocalNotification];
        
        int _statusValue=[[attributes objectForKey:@"status"] intValue];
        
        if (_statusValue==0)
        {
            _status=JSSearching;
            [self enableLocalNotitifcation];
        }
        else if (_statusValue==1)
        {
            _status=JSPending;
            [_technician updateWithAttributes:[attributes objectForKey:@"technician"]];
        }
        else if (_statusValue==2)
        {
            _isJobAvailable=NO;
            _status=JSNoJob;
            [_technician updateWithAttributes:[attributes objectForKey:@"technician"]];
        }
        else if (_statusValue==3)
        {
            _status=JSCancelByTechnician;
            [_technician updateWithAttributes:[attributes objectForKey:@"technician"]];
        }
        else if (_statusValue==4)
        {
             _status=JSStarted;
             [_technician updateWithAttributes:[attributes objectForKey:@"technician"]];
        }
        else if (_statusValue==5)
        {
            _status=JSCompleted;
             [_technician updateWithAttributes:[attributes objectForKey:@"technician"]];
        }
        else if (_statusValue==6)
        {
            _status=JSCancelledUnpaid;
            [_technician updateWithAttributes:[attributes objectForKey:@"technician"]];
        }
        else if (_statusValue==7)
        {
            _status=JSCompleteUnpaid;
            [_technician updateWithAttributes:[attributes objectForKey:@"technician"]];
        }
        else if (_statusValue==8)
        {
            _status=JSNeedFeedback;
            [_technician updateWithAttributes:[attributes objectForKey:@"technician"]];
        }
        else if (_statusValue==9)
        {
            _isJobAvailable=NO;
            _status=JSNoJob;
        }
        else if (_statusValue==10)
        {
            _isJobAvailable=YES;
            _status=JSInActiveJobUnpaid;
        }
        else
        {
            _isJobAvailable=YES;
            _status=JSInActiveJobPaid;
        }

    }
    else
    {
        _isJobAvailable=YES;
        _jobId=@"";
        _itemName=@"";
        _itemPrice=0.0;
        _timeInterval=12;
        _location=@"";
        _timeInterval=5;
        _cancellationFees=0.0;
        
        [_technician updateWithAttributes:nil];
        
        [self disableLocalNotification];
      
        _isJobAvailable=NO;
      
        _status=JSNoJob;
    }
}


- (void)enableLocalNotitifcation
{
    NSDate *_savedDate=[_date copy];
    _savedDate=[_savedDate dateByAddingTimeInterval:_timeInterval*60];
    
    NSDate *_currentDate=[NSDate date];
    
    NSTimeInterval _interval = [_savedDate timeIntervalSinceDate:_currentDate];
   
    [self disableLocalNotification];
   
    if (_interval>0)
    {
        UILocalNotification* _localNotification = [[UILocalNotification alloc] init];
        _localNotification.alertBody = [NSString stringWithFormat:@"We’re currently looking for a technician, you have been placed in our VIP queue and will be notified ASAP. How long would you like us to keep looking for?"];
        _localNotification.soundName = UILocalNotificationDefaultSoundName;
        _localNotification.applicationIconBadgeNumber = 1;
        [_localNotification setTimeZone:[NSTimeZone defaultTimeZone]];
        _localNotification.fireDate = _savedDate;
        _localNotification.userInfo=[NSDictionary dictionaryWithObject:LOCAL_NOTIFICATION_TAG forKey:@"tag"];
        [[UIApplication sharedApplication] scheduleLocalNotification:_localNotification];
    }
}


- (void)disableLocalNotification
{
    UIApplication *_app = [UIApplication sharedApplication];
    
    NSArray *_scheduledNotificationArray = [_app scheduledLocalNotifications];
    
    for (int i=0; i<[_scheduledNotificationArray count]; i++)
    {
        UILocalNotification* _localNotification = [_scheduledNotificationArray objectAtIndex:i];
        [_app cancelLocalNotification:_localNotification];
    }
}

- (void)resetJobDetails
{
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"HistoryInfo"];
    
    [[NSUserDefaults standardUserDefaults]setObject:[NSMutableDictionary dictionaryWithCapacity:0] forKey:@"LastJobDetail"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [self updateWithAttributes:nil];
    
    _changed=YES;
}
@end
