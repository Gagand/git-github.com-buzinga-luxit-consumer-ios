//
//  LATermsAndConditionsVC.m
//  Luxit
//
//  Created by GP on 24/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "LATermsAndConditionsVC.h"
#import "Constant.h"

@implementation LATermsAndConditionsVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    _displacementFactor=0.0;
    
    if (self.navigationController.navigationBarHidden)
    {
        _displacementFactor=65.0;
        
        NSDictionary *_attributes=nil;
        
        _attributes=@{
                      kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                      };
        
        CGRect _frame=CGRectMake(0.0, 15.0, self.view.frame.size.width, 50.0);
        
        UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
        
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                      kASTextColor:COLOR_THEME_BROWN,
                      kASText:@"TERMS & CONDITIONS",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                      };
        [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
        
        [self.view addSubview:_headerLabel];
        
        
        _attributes=@{
                      kCCImage: [UIImage imageNamed:@"Arrow.png"]
                      };
        
        [self.view addSubview:[ccManager() buttonWithAttributes:_attributes frame:CGRectMake(-10.0, 15.0, 90.0, 50.0) completion:^(UIButton *sender)
                               {
                                   [self.navigationController popViewControllerAnimated:YES];
                                    [self dismissViewControllerAnimated:YES completion:nil];
                               }]];
        
        _frame=CGRectMake(0.0, 64.0,self.view.frame.size.width , 1.0);
        _attributes=@{
                      kCCImage:[UIImage imageNamed:@"seprator.png"]
                      };
        UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
        [self.view addSubview:_divider];
    }
    
    else
    {
        
        CGRect _frame=CGRectMake(0.0, 15.0, 190, 50.0);
        NSDictionary *_attributes;
        _attributes=@{
                      kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                      };
        UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
        
        
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                      kASTextColor:COLOR_THEME_BROWN,
                      kASText:@"TERMS & CONDITIONS",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                      };
        [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
        
        self.navigationItem.titleView=_headerLabel;
        
        
        _attributes=@{
                      kCCImage: [UIImage imageNamed:@"Arrow.png"]
                      };
        UIButton *_cancelButton=[ccManager() buttonWithAttributes:_attributes frame:CGRectMake(0.0, 5.0, 80.0, 50.0)completion:^(UIButton *sender){
            [self.navigationController popViewControllerAnimated:YES];
            [self dismissViewControllerAnimated:YES completion:nil];
        }];
        
        
        UIBarButtonItem *_cancelButtonItem=[[UIBarButtonItem alloc]initWithCustomView:_cancelButton];
        
        UIBarButtonItem *_leftSpaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
        _leftSpaceItem.width = -31.0;
        
        self.navigationItem.leftBarButtonItems=[NSArray arrayWithObjects:_leftSpaceItem,_cancelButtonItem, nil];
        
        
        _frame=CGRectMake(0.0, 0.0,self.view.frame.size.width , 1.0);
        _attributes=@{
                      kCCImage:[UIImage imageNamed:@"seprator.png"]
                      };
        UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
        [self.view addSubview:_divider];
    }
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_webView==nil)
    {
        _webView=[[UIWebView alloc]initWithFrame:CGRectMake(0.0, _displacementFactor, self.view.frame.size.width, self.view.frame.size.height)];
        _webView.delegate=self;
        _webView.opaque=NO;
        _webView.scalesPageToFit = YES;
        _webView.autoresizesSubviews = YES;
        _webView.backgroundColor=[UIColor clearColor];
        [self.view addSubview:_webView];
        
        NSString *_docFilePath = [[NSBundle mainBundle] pathForResource:@"Luxit - User Agreement" ofType:@"docx"];
        NSURL *_url = [NSURL fileURLWithPath:_docFilePath];
        NSURLRequest *_request = [NSURLRequest requestWithURL:_url];
        [_webView loadRequest:_request];
        
        
        _activityIndicatorView=[[UIActivityIndicatorView alloc]initWithFrame:self.view.bounds];
        _activityIndicatorView.activityIndicatorViewStyle=UIActivityIndicatorViewStyleGray;
        [self.view addSubview:_activityIndicatorView];
        [_activityIndicatorView startAnimating];
    }
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    _webView.frame=CGRectMake(0.0, _displacementFactor, self.view.frame.size.width, self.view.frame.size.height-_displacementFactor);
}


- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [_activityIndicatorView stopAnimating];
}


- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [_activityIndicatorView stopAnimating];
}


@end
