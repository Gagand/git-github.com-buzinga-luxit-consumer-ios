//
//  LACompletionReceiptVC.m
//  Luxit
//
//  Created by GP on 27/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "LACompletionReceiptVC.h"
#import "LAUserHomeVC.h"
#import "LAParentViewController.h"
#import "Constant.h"

@implementation LACompletionReceiptVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
     [progressHud() hide];
    
    self.navigationItem.hidesBackButton=YES;
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    [self.menuContainerViewController disablePan];
    
    NSDictionary *_attributes=nil;
    _attributes=@{kCCBackgroundColor: [UIColor colorWithWhite:0.0 alpha:0.2]};
    
    CGRect _frame=CGRectMake(0.0, 0.0, self.view.frame.size.width, 0.5);
    
    [self.view addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];
    
     _frame=CGRectMake(0.0, 15.0, 190, 50.0);

    _attributes=@{
                  kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                  };
    UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
    
    
    _attributes=@{
                  kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                  kASTextColor:COLOR_THEME_BROWN,
                  kASText:@"RECEIPT",
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                  };
    [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
    
    self.navigationItem.titleView=_headerLabel;
    
    _frame=CGRectMake(0.0, 0.0,self.view.frame.size.width , 1.0);
    _attributes=@{
                  kCCImage:[UIImage imageNamed:@"seprator.png"]
                  };
    UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
    [self.view addSubview:_divider];
    
    
    _PROFESSIONALISMRating=10;
    _PUNCTUALITYRating=10;
    _PRESENTATIONRating=10;
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_tableView==nil)
    {
        NSDictionary *_attributes=nil;
        
        _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0.0, 0.0, self.view.frame.size.width, self.view.frame.size.height-43.5) style:UITableViewStylePlain];
        _tableView.delegate=self;
        _tableView.dataSource=self;
        _tableView.showsVerticalScrollIndicator=NO;
        _tableView.backgroundColor=[UIColor clearColor];
        _tableView.separatorColor=[UIColor clearColor];
        [self.view addSubview:_tableView];
        
       CGRect _frame=CGRectMake(0.0, self.view.frame.size.height-43.5, self.view.frame.size.width, 43.5);
        _attributes=@{
                      kCCBackgroundColor:COLOR_THEME_DARKGRAY
                      };
        UIButton *_continueButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
            [self submitButtonAction];
        }];
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:1.35],
                      kASTextColor:COLOR_THEME_BROWN,
                      kASText:@"SUBMIT",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0]
                      };
        [_continueButton setAttributedTitle:[NSMutableAttributedString attributedStringWithAttributes:_attributes] forState:UIControlStateNormal];
        [self.view addSubview:_continueButton];
    }
}


#pragma mark------------------------------------------------------------
#pragma mark TABLEVIEW DELEGATE/ DATASOURCE
#pragma mark------------------------------------------------------------

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 9;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0)
    {
         return 174.5;
    }
    else if (indexPath.row==1)
    {
        return 22;
    }
    else if (indexPath.row==2||indexPath.row==3||indexPath.row==4)
    {
        return 97.0;
    }
    else if (indexPath.row==5)
    {
        return 44.0;
    }
    else if (indexPath.row==6)
    {
        return 176.0;
    }
    else
    {
        return 44.0;
    }
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=[NSString stringWithFormat:@"Cell_%i",(int)indexPath.row];
    
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
    
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        if (indexPath.row==0)
        {
            CGRect _frame=CGRectMake(tableView.frame.size.width/2-85.0/2.0, 31.0, 85.0, 85.0);
            
            NSDictionary *_attributes=nil;
            _attributes=@{
                          kCCImage:[UIImage imageNamed:@"Cost_Frame.png"]
                          };
            [_cell.contentView addSubview:[ccManager() imageViewWithAttributes:_attributes frame:_frame]];
            
            
            _attributes=@{
                          kCCText: [NSString stringWithFormat:@"$ %i",(int)appDelegate().jobDetail.itemPrice],
                          kCCTextColor:COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:16.0],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                          };
            [_cell.contentView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
          
            _frame=CGRectMake(10.0, _frame.origin.y+_frame.size.height+14.5, tableView.frame.size.width-20.0, 14.0);
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0],
                          kASText:[[appDelegate().jobDetail.itemName stringByReplacingOccurrencesOfString:@"\n" withString:@" "] uppercaseString],
                          kASCharacterSpace:[NSNumber numberWithFloat:3.5]
                          };
            UILabel *_itemNameLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _itemNameLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_itemNameLabel];
            
            
            _frame=CGRectMake(tableView.frame.size.width/2-12.0, _frame.origin.y+_frame.size.height+15, 24.0, 0.5);
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_LIGHTPINK
                      ];
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            _customLayer.alpha=0.8;
            [_cell.contentView addSubview:_customLayer];
            
            
            
        }
        else if (indexPath.row==1)
        {
            _cell.backgroundColor=COLOR_THEME_DARKGRAY;
            
            NSDictionary *_attributes=nil;
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.6/2.0],
                          kASTextColor:[UIColor whiteColor],
                          kASText:@"Rate your technician",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0]
                          };
            
            CGRect _frame=CGRectMake(0.0, 0.0, tableView.frame.size.width, 22.0);
            
            UILabel *_staticLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_staticLabel];
     
        }
        else if (indexPath.row==2||indexPath.row==3||indexPath.row==4)
        {
            NSString *_titleString=@"PROFESSIONALISM";
            if (indexPath.row==3)
            {
                _titleString=@"PUNCTUALITY";
            }
            else if (indexPath.row==4)
            {
                _titleString=@"PRESENTATION";
            }
            
           
            
            NSDictionary *_attributes=nil;

            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:7.0/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:_titleString,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
        
            CGRect _frame=CGRectMake(16.0, 15.0, tableView.frame.size.width-32.0, 15.0);
            
            UILabel *_staticLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
 
            [_cell.contentView addSubview:_staticLabel];
            
            CGFloat _xoffset=16.0;
            CGFloat _yoffset=_frame.origin.y+_frame.size.height+15.0;
            CGFloat _width=(tableView.frame.size.width-32)/10.0;

            
            UIImage *_starIcon =[UIImage imageNamed:@"Star_Fill.png"];
            for (int i=0; i<10; i++)
            {

                _attributes=@{
                              kCCTag:[NSNumber numberWithInt:1000+i],
                              kCCImage:_starIcon,
                              kCCContentMode: [NSNumber numberWithInt:UIViewContentModeCenter]
                              };
                _frame=CGRectMake(_xoffset, _yoffset, _width, 13.0);
                [_cell.contentView addSubview:[ccManager() imageViewWithAttributes:_attributes frame:_frame]];
                _xoffset+=_width;
            }
            
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_BROWN,
                      [UIColor colorWithRed:247.0/255.0 green:217.0/255.0 blue:184.0/255.0 alpha:1.0]
                      ];
            _frame=CGRectMake(19.0, _yoffset+13.0+9.0+14.5, tableView.frame.size.width-38.0, 1.0);
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_customLayer];
            
            
            
            UISlider *_slider=[[UISlider alloc]initWithFrame:CGRectMake(16.0, _yoffset+13.0+9.0, tableView.frame.size.width-32.0, 30.0)];
            _slider.minimumValue=0.0;
            _slider.maximumValue=10.0;
            [_slider addTarget:self action:@selector(ratingSliderValueChanged:) forControlEvents:UIControlEventValueChanged];
            [_slider setMinimumTrackImage:[UIImage new] forState:UIControlStateNormal];
            [_slider setMaximumTrackImage:[UIImage new] forState:UIControlStateNormal];
            [_cell.contentView addSubview:_slider];
            _slider.value=10.0;
            
        }
        
        else if (indexPath.row==5)
        {
 
   
            NSDictionary *_attributes=nil;
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.6/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"Booking Details",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0]
                          };
            
           CGRect _frame=CGRectMake(0.0, 0.0, tableView.frame.size.width, 44.0);
            
            UILabel *_staticLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_staticLabel];
            
        }
       
        else if (indexPath.row==6)
        {
            int numberOfRows=4;
            
            NSDictionary *_attributes=nil;
            
            CGRect _frame=CGRectMake(8.0, 0.0, tableView.frame.size.width-16.0, 176.0);
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_BROWN
                      ];
            
            CustomLayer*_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMVertical];
            [_cell.contentView addSubview:_customLayer];
            
            
            _attributes=@{
                          kCCBackgroundColor: [UIColor whiteColor]
                          };
            
            _frame=CGRectMake(_frame.origin.x+0.5, _frame.origin.y+0.5,_frame.size.width-1.0, _frame.size.height-1.0);
            UIView *_containerView=[ccManager() viewWithAttributes:_attributes frame:_frame];
            [_cell.contentView addSubview:_containerView];
            
            
            [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, _containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.6)]];
            
            [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, 2*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.6)]];
            
            [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, 3*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.6)]];
            
            
            _frame=CGRectMake(16.0, 0.0, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"DATE",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticDateLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticDateLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticDateLabel];
            
            
            
            _attributes=@{
                          kCCText: appDelegate().jobDetail.dateString,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            
            _frame=CGRectMake(16.0, _containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"TIME",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticTimeLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTimeLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticTimeLabel];
            
            _attributes=@{
                          kCCText:appDelegate().jobDetail.timeString,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            
            _frame=CGRectMake(16.0, 2*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"ADDRESS",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticAddressLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticAddressLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticAddressLabel];
            
            _frame=CGRectMake(90.0, 2*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-105.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kCCText: appDelegate().jobDetail.location,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            
            _frame=CGRectMake(16.0, 3*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"TECHNICIAN",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticTechnicianLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTechnicianLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticTechnicianLabel];
            
            _attributes=@{
                          kCCText: appDelegate().jobDetail.technician.firstName,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
        }
        
        else if (indexPath.row==7)
        {
            NSDictionary *_attributes=nil;
            CGRect _frame=CGRectMake(8.0, 0.0, tableView.frame.size.width-20.0,45.0);
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:1.4],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"TOTAL",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticTotalLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTotalLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_staticTotalLabel];
            
            
            _attributes=@{
                          kCCText: [NSString stringWithFormat:@"$%i",(int)appDelegate().jobDetail.customerPayablePrice],
                          kCCTextColor:COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:14.0],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            _frame=CGRectMake(8.0, 0.0, tableView.frame.size.width-16.0,45.0);
            [_cell.contentView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            
            _frame=CGRectMake(8.0, 43.5, 24.0, 0.5);
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_LIGHTPINK
                      ];
            
            CustomLayer*_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMVertical];
            [_cell.contentView addSubview:_customLayer];
        }
        else if (indexPath.row==8)
        {
            NSDictionary *_attributes=nil;
            CGRect _frame=CGRectMake(8.0, 0.0, tableView.frame.size.width-16.0,45.0);
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:1.4],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"CHARGED TO",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticChargedToLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticChargedToLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_staticChargedToLabel];
            
            NSString *_paymentMethodName=@"";
            
            if (appDelegate().userInfo.paymentMode.type==PTCreditCard)
            {
                _paymentMethodName=[NSString stringWithFormat:@"xxxx %@",[appDelegate().userInfo.paymentMode.cardNumber substringWithRange:NSMakeRange(appDelegate().userInfo.paymentMode.cardNumber.length-4, 4)]];
            }
            else
            {
                if (appDelegate().userInfo.paymentMode.email.length>20)
                {
                    _paymentMethodName=[NSString stringWithFormat:@"%@...",[appDelegate().userInfo.paymentMode.email substringToIndex:14]];
                }
                else
                {
                    _paymentMethodName=appDelegate().userInfo.paymentMode.email;
                }
            }
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:14.0],
                          kASText:_paymentMethodName,
                          kASCharacterSpace:[NSNumber numberWithFloat:0.354],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            _frame=CGRectMake(90.0, 10.0, tableView.frame.size.width-98.0,20.0);
            UILabel *_paymentMethodInfoLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _paymentMethodInfoLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_paymentMethodInfoLabel];
        }
    }
    return _cell;
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONS
#pragma mark------------------------------------------------------------

- (void)submitButtonAction
{
    [progressHud() showWithTitle:@"Please wait"];
    
    NSDictionary *_attributes=@{
                                @"userId":appDelegate().userInfo.userId,
                                @"jobId":appDelegate().jobDetail.jobId,
                                @"professionalismRating":[NSString stringWithFormat:@"%i",_PROFESSIONALISMRating],
                                @"punctualityRating":[NSString stringWithFormat:@"%i",_PUNCTUALITYRating],
                                @"presentationRating":[NSString stringWithFormat:@"%i",_PRESENTATIONRating]
                                };
    
    [API() completeJobWithAttributes:_attributes completion:^(BOOL success,NSError *error){
       
        if (success)
        {
            if (_PROFESSIONALISMRating<5 || _PUNCTUALITYRating<5 || _PRESENTATIONRating<5)
            {
                [progressHud() hide];
                NSMutableDictionary *_jobDetail=[NSMutableDictionary dictionaryWithDictionary:[[NSUserDefaults standardUserDefaults] objectForKey:@"LastJobDetail"]];
                [_jobDetail setObject:@"8"  forKey:@"status"];
                [[NSUserDefaults standardUserDefaults]setObject:_jobDetail forKey:@"LastJobDetail"];
                [[NSUserDefaults standardUserDefaults]synchronize];
                
                [appDelegate().jobDetail updateWithAttributes:[[NSUserDefaults standardUserDefaults]objectForKey:@"LastJobDetail"]];
                
                appDelegate().jobDetail.changed=YES;
                [self.menuContainerViewController switchView];
            }
            else
            {
                 [self sendFeedback];
            }
           
        }
        else
        {
             [progressHud() hide];
            [ccManager() showAlertWithTitle:[[error userInfo] objectForKey:@"title"] message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
        }
    }];
}

- (void)sendFeedback
{
    NSString *_commentString=@"";
    [progressHud() showWithTitle:@"Please wait"];
    
    NSDictionary *_attributes=@{
                                @"userId":appDelegate().userInfo.userId,
                                @"jobId":appDelegate().jobDetail.jobId,
                                @"comment":_commentString
                                };
    
    [API() sendFeedbackForJobWithAttributes:_attributes completion:^(BOOL success,NSError *error)
    {
        [progressHud() hide];
       
        if (success)
        {
           [appDelegate().jobDetail resetJobDetails];
            
           [self.menuContainerViewController switchView];
        }
        else
        {
            [ccManager() showAlertWithTitle:[[error userInfo] objectForKey:@"title"] message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
        }
    }];
}




- (void)ratingSliderValueChanged:(UISlider *)sender
{
    UITableViewCell *_cell=nil;
    if ([[[UIDevice currentDevice]systemVersion]floatValue]>=7.0 &&[[[UIDevice currentDevice]systemVersion]floatValue]<8.0)
    {
        _cell=(UITableViewCell *)sender.superview.superview.superview;
    }
    else
    {
        _cell=(UITableViewCell *)sender.superview.superview;
    }
    
    _selectedCell=_cell;
    
    NSIndexPath *_indexPath=[_tableView indexPathForCell:_cell];
   
    if (_indexPath.row==3)
    {
        _PUNCTUALITYRating=(int)lroundf(sender.value);
    }
    else if (_indexPath.row==4)
    {
       _PRESENTATIONRating=(int)lroundf(sender.value);
    }
    else
    {
        _PROFESSIONALISMRating=(int)lroundf(sender.value);
    }
    
    [self updateStarsWithValue:(int)lroundf(sender.value)];
   
}

- (void)updateStarsWithValue:(int)value
{
    UIImage *_offStarIcon = [UIImage imageNamed:@"Star_No_Fill.png"];
    UIImage *_onStarIcon = [UIImage imageNamed:@"Star_Fill.png"];
    for (id _subView in _selectedCell.contentView.subviews)
    {
        if ([_subView isKindOfClass:[UIImageView class]] && ((UIView *)_subView).tag>=1000)
        {
            UIImageView *_imageView=(UIImageView *)_subView;
            
            if (value+1000>_imageView.tag)
            {
                _imageView.image=_onStarIcon;
            }
            else
            {
                _imageView.image=_offStarIcon;
            }
        }
    }
}
@end
