//
//  LAAddPaymentTypeVC.m
//  Luxit
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "LAAddPaymentTypeVC.h"

#define kScreenTitle            @"PAYMENT DETAILS"
#define kSkipButtonTitle        @"Skip"
#define kCancelButtonTitle      @"Cancel"
#define kSeparatorImage         @"seprator.png"
#define kGrayCardIconImage      @"card.png"
#define kGoldenCardIconImage    @"Card_Gold.png"

@implementation LAAddPaymentTypeVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_tableView==nil)
    {
        CGFloat _displacementFactor=0.0;
       
        if (self.navigationController.navigationBarHidden)
        {
            _displacementFactor=65.0;
         
            NSDictionary *_attributes=nil;
            
            _attributes=@{
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                          };
            
            CGRect _frame=CGRectMake(0.0, 15.0, self.view.frame.size.width, 50.0);
            
            UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:kScreenTitle,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                          };
            [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
            
            [self.view addSubview:_headerLabel];
          
            _attributes=@{
                          kCCText: kSkipButtonTitle,
                          kCCTextColor:COLOR_THEME_BROWN,
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0]
                          };
            
            [self.view addSubview:[ccManager() buttonWithAttributes:_attributes frame:CGRectMake(self.view.frame.size.width-80.0, 15.0, 90.0, 50.0) completion:^(UIButton *sender){
                [appDelegate() showUserHomeViewController];
            }]];
            
            
            _frame=CGRectMake(0.0, 64.0,self.view.frame.size.width , 1.0);
            _attributes=@{
                          kCCImage:[UIImage imageNamed:kSeparatorImage]
                          };
            UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
            [self.view addSubview:_divider];
        }
        else
        {
            CGRect _frame=CGRectMake(0.0, 15.0, 190, 50.0);
            NSDictionary *_attributes;
            _attributes=@{
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                          };
            UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
            
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:kScreenTitle,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                          };
            [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
            
            self.navigationItem.titleView=_headerLabel;
          
            _attributes=@{
                          kCCText: kCancelButtonTitle,
                          kCCTextColor:COLOR_THEME_BROWN,
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0]
                          };
            UIButton *_cancelButton=[ccManager() buttonWithAttributes:_attributes frame:CGRectMake(0.0, 5.0, 80.0, 50.0) completion:^(UIButton *sender)
            {
                [self dismissViewControllerAnimated:YES completion:nil];
            }];
            
            
            UIBarButtonItem *_cancelButtonItem=[[UIBarButtonItem alloc]initWithCustomView:_cancelButton];
           
            UIBarButtonItem *_leftSpaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
            _leftSpaceItem.width = -18.0;
           
            self.navigationItem.leftBarButtonItems=[NSArray arrayWithObjects:_leftSpaceItem,_cancelButtonItem, nil];
            
            _frame=CGRectMake(0.0, 0.0,self.view.frame.size.width , 1.0);
            _attributes=@{
                          kCCImage:[UIImage imageNamed:kSeparatorImage]
                          };
            UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
            [self.view addSubview:_divider];
        }
       
        _customKeyboard=[[CustomKeyboard alloc]init];
        _customKeyboard.delegate=self;
        
        _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0.0, _displacementFactor, self.view.frame.size.width, self.view.frame.size.height-_displacementFactor) style:UITableViewStylePlain];
        _tableView.delegate=self;
        _tableView.dataSource=self;
        _tableView.backgroundColor=[UIColor clearColor];
        _tableView.separatorColor=[UIColor clearColor];
        [self.view addSubview:_tableView];
    }
}


#pragma mark------------------------------------------------------------
#pragma mark TABLEVIEW DELEGATE/DATASOURCE
#pragma mark------------------------------------------------------------

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0||indexPath.row==1)
    {
        return 44.0;
    }
    else if (indexPath.row==2)
    {
        return 55.0;
    }
    else if (indexPath.row==3)
    {
        return 90.0;
    }
    else
    {
        return 55.0;
    }
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=[NSString stringWithFormat:@"%i",(int)indexPath.row];
    
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
   
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
      
        if (indexPath.row==0)
        {
            [_cell.contentView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: [UIColor colorWithWhite:0.0 alpha:0.2]} frame:CGRectMake(0.0, 43.5, tableView.frame.size.width, 0.5)]];
            
            NSDictionary *_attributes=nil;
          
            _attributes=@{
                          kCCImage: [UIImage imageNamed:kGrayCardIconImage],
                          kCCContentMode:[NSNumber numberWithInt:UIViewContentModeCenter]
                          };
           
            CGRect _frame=CGRectMake(16.0, 0.0, 40.0, 44.0);
          
            _cardImageView=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
            [_cell.contentView addSubview:_cardImageView];
            
            _attributes=@{
                          kCCTextColor: COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_MEDIUM size:13.0],
                          kCCPlaceHolderColor:[UIColor colorWithRed:130./255.0 green:130.0/255.0 blue:130.0/255.0 alpha:1.0],
                          kCCPlaceHolderText:@"1234 5678 9012 3456",
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad]
                          };
           
            _frame=CGRectMake(50.0, 0.0, tableView.frame.size.width-80.0, 44.0);
           
            _cardNoTF=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
            [_cell.contentView addSubview:_cardNoTF];
            
            _cardNoTF.inputAccessoryView=[_customKeyboard getToolbarWithPrevNextDone:NO :YES];
        
            NSString *_paymentMethodName=@"";
            
            if (appDelegate().userInfo.paymentMode.type==PTCreditCard && _typeMode==PTEdit )
            {
                if(appDelegate().userInfo.paymentMode.isPaymentModeAvailable){
                    _paymentMethodName=[NSString stringWithFormat:@"xxxx xxxx xxxx %@",[appDelegate().userInfo.paymentMode.cardNumber substringWithRange:NSMakeRange(appDelegate().userInfo.paymentMode.cardNumber.length-4, 4)]];
                
                    _cardNoTF.text=_paymentMethodName;
                
                    _cardImageView.image=[UIImage imageNamed:kGoldenCardIconImage];
                }
            }
        }
        else if (indexPath.row==1)
        {
            [_cell.contentView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: [UIColor colorWithWhite:0.0 alpha:0.2]} frame:CGRectMake(0.0, 43.5, tableView.frame.size.width, 0.5)]];
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_BROWN
                      ];
            CGRect _frame=CGRectMake(tableView.frame.size.width/2, 5.0, 0.5, 34.0);
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMVertical];
            [_cell.contentView addSubview:_customLayer];
           
            NSDictionary *_attributes=nil;
            _attributes=@{
                          kCCTextColor:COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_MEDIUM size:13.0],
                          kCCPlaceHolderColor:[UIColor colorWithRed:130./255.0 green:130.0/255.0 blue:130.0/255.0 alpha:1.0],
                          kCCPlaceHolderText:@"MM/YY",
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                          };
           
            _frame=CGRectMake(00.0, 0.0, tableView.frame.size.width/2, 44.0);
           
            _expiryDateTF=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
            [_expiryDateTF addTarget:self action:@selector(creditCardExpiryFormatter:) forControlEvents:UIControlEventEditingChanged];
            [_cell.contentView addSubview:_expiryDateTF];
          
            _expiryDateTF.inputAccessoryView=[_customKeyboard getToolbarWithPrevNextDone:YES :YES];
            
            _attributes=@{
                          kCCTextColor:COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_MEDIUM size:13.0],
                          kCCPlaceHolderColor:[UIColor colorWithRed:130./255.0 green:130.0/255.0 blue:130.0/255.0 alpha:1.0],
                          kCCPlaceHolderText:@"CVV",
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                          };
           
            _frame=CGRectMake(tableView.frame.size.width/2, 0.0, tableView.frame.size.width/2,44.0);
           
            _cvvTF=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
            [_cell.contentView addSubview:_cvvTF];
          
            _cvvTF.inputAccessoryView=[_customKeyboard getToolbarWithPrevNextDone:YES :NO];
        }
        else if (indexPath.row==2)
        {
            NSDictionary *_attributes=nil;
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_BROWN,
                      COLOR_THEME_LIGHTPINK
                      ];
            CGRect _frame=CGRectMake(20.0, 20.0, self.view.frame.size.width-40.0, 44.0);
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_customLayer];
            
            
            _frame=CGRectMake(_frame.origin.x+1.5, _frame.origin.y+1.5, _frame.size.width-3.0, _frame.size.height-3.0);
            
            _attributes=@{
                          kCCBackgroundColor:COLOR_THEME_DARKGRAY
                          };
            UIButton *_addCardButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
                [self addCardInfo];
            }];
            
            NSString *_textString=@"ADD CARD";
            if (_typeMode==PTEdit)
            {
               _textString=@"USE CARD";
            }
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0],
                          kASText:_textString,
                          kASCharacterSpace:[NSNumber numberWithFloat:1.35]
                          };
            
            NSMutableAttributedString *_attributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            
            [_addCardButton setAttributedTitle:_attributedString forState:UIControlStateNormal];
            [[_addCardButton titleLabel] setNumberOfLines:0];
            [[_addCardButton titleLabel] setLineBreakMode:NSLineBreakByWordWrapping];
            [_cell.contentView addSubview:_addCardButton];
        }
        else if (indexPath.row==3)
        {
          
             NSDictionary *_attributes=nil;
            _attributes=@{
                          kCCTextColor: COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0],
                          kCCText:@"OR",
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                          };
           CGRect  _frame=CGRectMake(0.0, 20.0, self.view.frame.size.width, 20.0);
            
            [_cell.contentView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            _frame=CGRectMake(0.0, _frame.origin.y+_frame.size.height-10.0, self.view.frame.size.width/2-20.0, 0.5);
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_BROWN,
                      COLOR_THEME_LIGHTPINK
                      ];
            CustomLayer *_leftDividerLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_leftDividerLayer];
            
            
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_BROWN
                      ];
            _frame=CGRectMake(self.view.frame.size.width/2+20.0, _frame.origin.y, self.view.frame.size.width/2-20.0, 0.5);
            CustomLayer *_rightDividerLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_rightDividerLayer];
         
            _frame=CGRectMake(0.0, _frame.origin.y+15.0, tableView.frame.size.width, 0.55);
           
            _attributes=@{
                          kCCBackgroundColor:[UIColor colorWithRed:221.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0]
                          };
            [_cell.contentView addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];
            
     
            _frame=CGRectMake(0.0, _frame.origin.y+44.0, tableView.frame.size.width, 0.55);
            [_cell.contentView addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];
            
            
            _frame=CGRectMake(0.0, _frame.origin.y-44.0, tableView.frame.size.width, 44.0);
            _attributes=@{
                          kCCTextColor: COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:15.0],
                          kCCPlaceHolderColor:[UIColor colorWithRed:130./255.0 green:130.0/255.0 blue:130.0/255.0 alpha:1.0],
                          kCCPlaceHolderText:@"Enter email",
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyDone],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeEmailAddress],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                          };
            
            _emailTF=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
            [_cell.contentView addSubview:_emailTF];
            
            if (_typeMode==PTEdit && appDelegate().userInfo.paymentMode.type==PTPaypal)
            {
                 if(appDelegate().userInfo.paymentMode.isPaymentModeAvailable)
                 {
                     _emailTF.text=appDelegate().userInfo.paymentMode.email;
                 }
            }
        }
        
        else
        {
            NSDictionary *_attributes=nil;
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_BROWN,
                      COLOR_THEME_LIGHTPINK
                      ];
            CGRect _frame=CGRectMake(20.0, 20.0, self.view.frame.size.width-40.0, 44.0);
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_customLayer];
            
            
            _frame=CGRectMake(_frame.origin.x+1.5, _frame.origin.y+1.5, _frame.size.width-3.0, _frame.size.height-3.0);
            
            _attributes=@{
                          kCCBackgroundColor:COLOR_THEME_DARKGRAY
                          };
            UIButton *_addCardButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
                [self addPayPalInfo];
            }];
            
            NSString *_textString=@"ADD PAYPAL";
            if (_typeMode==PTEdit)
            {
                _textString=@"USE PAYPAL";
            }

            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0],
                          kASText:_textString,
                          kASCharacterSpace:[NSNumber numberWithFloat:1.35]
                          };
            
            NSMutableAttributedString *_attributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            
            [_addCardButton setAttributedTitle:_attributedString forState:UIControlStateNormal];
            [[_addCardButton titleLabel] setNumberOfLines:0];
            [[_addCardButton titleLabel] setLineBreakMode:NSLineBreakByWordWrapping];
            [_cell.contentView addSubview:_addCardButton];
            
        }
    }
    return _cell;
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONs
#pragma mark------------------------------------------------------------

- (void)skipButtonAction
{
    [appDelegate() showUserHomeViewController];
}


- (void)addPayPalInfo
{
    [self validateAndUpdatePaymentMethod:NO];
}


- (void)addCardInfo
{
    [self validateAndUpdatePaymentMethod:YES];
}


#pragma mark------------------------------------------------------------
#pragma mark CUSTOM KEYBOARD DELEGATE
#pragma mark------------------------------------------------------------

-(void)customKeyboardAction:(ActioType)action
{
    if (action==ATNext)
    {
        if ([_cardNoTF isFirstResponder])
        {
            [_expiryDateTF becomeFirstResponder];
        }
        else  if ([_expiryDateTF isFirstResponder])
        {
            [_cvvTF becomeFirstResponder];
        }
    }
    else if (action==ATPrevious)
    {
        if ([_cvvTF isFirstResponder])
        {
            [_expiryDateTF becomeFirstResponder];
        }
        else  if ([_expiryDateTF isFirstResponder])
        {
            [_cardNoTF becomeFirstResponder];
        }
    }
    else
    {
        [_cardNoTF resignFirstResponder];
        [_expiryDateTF resignFirstResponder];
        [_cvvTF resignFirstResponder];
    }
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{

    if([_cardNoTF isFirstResponder])
    {
        if ([textField.text rangeOfString:@"xxxx"].location!=NSNotFound)
        {
            textField.text=@"";
        }
        
        [self performSelector:@selector(changeCardImage) withObject:nil afterDelay:0.01];
    }
    
    if(range.length + range.location > textField.text.length)
    {
        return NO;
    }
    
    NSUInteger newLength = [textField.text length] + [string length] - range.length;
   
    if (textField==_cardNoTF)
    {
        return newLength <= 16;
    }
    else if (textField==_cvvTF)
    {
        return newLength <= 4;
    }
    else  if (textField==_expiryDateTF)
    {
        return newLength <= 5;
    }
    else
    {
        return YES;
    }
}

#pragma mark------------------------------------------------------------
#pragma mark EXPIRY DATE VALIDATION
#pragma mark------------------------------------------------------------

- (void)creditCardExpiryFormatter:(id)sender
{
    NSString *formattedText = [self formatCreditCardExpiry:_expiryDateTF.text];
    if (![formattedText isEqualToString:_expiryDateTF.text])
    {
        _expiryDateTF.text = formattedText;
    }
}


- (NSString *)formatCreditCardExpiry:(NSString *)input
{
   input =[self trimSpecialCharacters:input];
   NSString *output;
    switch (input.length)
    {
        case 1:
        case 2:
            output = [NSString stringWithFormat:@"%@", [input substringToIndex:input.length]];
            break;
        case 3:
        case 4:
            output = [NSString stringWithFormat:@"%@/%@", [input substringToIndex:2], [input substringFromIndex:2]];
            break;
        default:
            output = @"";
            break;
    }
    return output;
}


- (NSString *)trimSpecialCharacters:(NSString *)input
{
   NSCharacterSet *special = [NSCharacterSet characterSetWithCharactersInString:@"/+-() "];
   return [[input componentsSeparatedByCharactersInSet:special] componentsJoinedByString:@""];
}


- (void)changeCardImage
{
    if (_cardNoTF.text.length>0)
    {
        _cardImageView.image=[UIImage imageNamed:kGoldenCardIconImage];
    }
    else
    {
        _cardImageView.image=[UIImage imageNamed:kGrayCardIconImage];
    }
}


-(BOOL)validateCard:(NSString *)cardNumber
{
    int kMagicSubtractionNumber =48;
	
    int Luhn = 0;
    
	for (int i=0;i<[cardNumber length];i++)
    {
        NSUInteger count = [cardNumber length]-1;
        
        int doubled = [[NSNumber numberWithUnsignedChar:[cardNumber characterAtIndex:count-i]] intValue] - kMagicSubtractionNumber;
        
        if (i % 2)
        {
            doubled = doubled*2;
        }
        
        NSString *double_digit = [NSString stringWithFormat:@"%d",doubled];
        
        if ([[NSString stringWithFormat:@"%d",doubled] length] > 1)
        {
            Luhn = Luhn + [[NSNumber numberWithUnsignedChar:[double_digit characterAtIndex:0]] intValue]-kMagicSubtractionNumber;
            Luhn = Luhn + [[NSNumber numberWithUnsignedChar:[double_digit characterAtIndex:1]] intValue]-kMagicSubtractionNumber;
        }
        else
        {
            Luhn = Luhn + doubled;
        }
    }
    
	if (Luhn%10 == 0)
    {
        return true;
    }
    else
    {
		return false;
    }
}


- (BOOL)validateExpiryDate:(NSString *)expiryDate
{
    if (expiryDate.length!=5)
    {
        return NO;
    }
    
    int _month=[[expiryDate substringWithRange:NSMakeRange(0, 2)]intValue];
    
    if (_month>12 || _month==0)
    {
        return NO;
    }
    
    int _year=[[expiryDate substringWithRange:NSMakeRange(3, 2)]intValue];
    
    NSDate *_currentDate=[NSDate date];
   
    NSDateFormatter *_dateFormatter=[[NSDateFormatter alloc]init];
   
    [_dateFormatter setDateFormat:@"yy"];
    
    int _currentYear=[[_dateFormatter stringFromDate:_currentDate]intValue];
    
    [_dateFormatter setDateFormat:@"MM"];
  
    int _currentMonth=[[_dateFormatter stringFromDate:_currentDate]intValue];
    
    if (_year>_currentYear)
    {
        return YES;
    }
    else
    {
        if (_month>_currentMonth)
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
}


- (void)validateAndUpdatePaymentMethod:(BOOL)isCard
{
    NSString *_userId=appDelegate().userInfo.userId;
    NSString *_type=@"";
    NSString *_cardNo=@"";
    NSString *_mmyy=@"";
    NSString *_cvv=@"";
    NSString *_paypalEmail=@"";
    NSString *_month=@"";
    NSString *_year=@"";
   
    if (isCard)
    {
        _type=@"0";
        _cardNo=[_cardNoTF.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        _cvv=[_cvvTF.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        _mmyy=[_expiryDateTF.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        
        if (_cardNo.length==0 || _cvv.length==0 || _mmyy.length==0)
        {
            [ccManager() showAlertWithTitle:@"Card number, Expiry date and CVV are required fields" message:@"" buttons:nil completion:nil];
            return;
        }
        
        if (![self validateCard:_cardNo])
        {
            [ccManager() showAlertWithTitle:@"Invalid card number" message:@"" buttons:nil completion:nil];
            return;
        }
        
        if (![self validateExpiryDate:_mmyy])
        {
            
            [ccManager() showAlertWithTitle:@"Invalid expiry date" message:@"" buttons:nil completion:nil];
            return;
        }
        
        NSArray *_monthComponents=[_mmyy componentsSeparatedByString:@"/"];
        _month=[_monthComponents objectAtIndex:0];
        _year=[_monthComponents objectAtIndex:1];
        
        NSDictionary *cardAttributes=@{
                                       @"cardNumber":_cardNo,
                                       @"cardHolderName":[NSString stringWithFormat:@"%@ %@",appDelegate().userInfo.firstName,appDelegate().userInfo.lastName],
                                       @"cvv":_cvv,
                                       @"expiryMonth":_month,
                                       @"expiryYear":_year,
                                       @"firstName":appDelegate().userInfo.firstName,
                                       @"lastName":appDelegate().userInfo.lastName
                                       };
        CardInfo *_cardInfo=[[CardInfo alloc]initWithAttributes:cardAttributes];
        
        [progressHud() showWithTitle:@"Please wait"];
      
        // REGISTER CREDIT CARD INFO ON EWAY
        // REGISTER TOKEN AND LAST FOUR DIGHT CARD NUMBER TO LUXIT SERVER
        [eWayHelper() registerCardForCustomerTokenWithCardInfo:_cardInfo Completion:^(eWAYStatus status,NSString *token)
        {
            if (status==eWAYStatusSuccess)
            {
                NSDictionary *_attributes=@{
                                            @"userId":_userId,
                                            @"type":_type,
                                            @"cardLastFourDigit":[_cardNo substringFromIndex:_cardNo.length-4],
                                            @"consumerToken":token,
                                            @"paypalEmail":@""
                                            };
                
                [self updatePaymentInfo:_attributes];
            }
            else
            {
                if (status==eWAYStatusError)
                {
                    [progressHud() showWithTitle:@"Error\nFail to add payment info. Please try again"];
                    
                    [self performSelector:@selector(hideProgessHud:) withObject:[NSNumber numberWithBool:NO] afterDelay:1.5];
                }
                else
                {
                    [progressHud() showWithTitle:@"Error\nInvalid card details"];
                    [self performSelector:@selector(hideProgessHud:) withObject:[NSNumber numberWithBool:NO] afterDelay:1.5];
                }
            }
        }];

    }
    else
    {
        _type=@"1";
        _paypalEmail=[_emailTF.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
       
        if (_paypalEmail.length==0)
        {
            [ccManager() showAlertWithTitle:@"Paypal email address is required" message:@"" buttons:nil completion:nil];
            return;
        }
        if (![self isValidEmail:_paypalEmail])
        {
            [ccManager() showAlertWithTitle:@"Invalid paypal email address" message:@"" buttons:nil completion:nil];
            return;
        }
        
        [_cardNoTF resignFirstResponder];
        [_expiryDateTF resignFirstResponder];
        [_cvvTF resignFirstResponder];
        [_emailTF resignFirstResponder];
        
        // REGISTER PAYPAL EMAIL TO LUXIT SERVER
        NSDictionary *_attributes=@{
                                    @"userId":_userId,
                                    @"type":_type,
                                    @"cardLastFourDigit":@"",
                                    @"consumerToken":@"",
                                    @"paypalEmail":_paypalEmail
                                    };
        [self updatePaymentInfo:_attributes];
    }
}


- (void)updatePaymentInfo:(NSDictionary *)attributes
{
    [progressHud() showWithTitle:@"Please wait"];
    
    [API() addPaymentMethodWithAttributes:attributes completion:^(BOOL success, NSError *error)
     {
         if (success)
         {
             [progressHud() showWithTitle:@"Success\nPayment method added successfully"];
           
             [self performSelector:@selector(hideProgessHud:) withObject:[NSNumber numberWithBool:success] afterDelay:1.5];
         }
         else
         {
             [progressHud() hide];
             
             [ccManager() showAlertWithTitle:[[error userInfo] objectForKey:@"title"] message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
         }
     }];
}


-(BOOL)isValidEmail:(NSString *)email
{
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z()<>@!#$%&'*+-/=?^_`{}|~.]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}


- (void)hideProgessHud:(NSNumber *)success
{
    if ([success intValue]==1)
    {
        if (_finishedAddingCard)
        {
            _finishedAddingCard();
        }
        
        if (_typeMode==PTEdit)
        {
             [progressHud() hide];
            [self dismissViewControllerAnimated:YES completion:nil];
        }
        else
        {
            [appDelegate() showUserHomeViewController];
        }
    }
    else
    {
        [progressHud() hide];
    }
}
@end
