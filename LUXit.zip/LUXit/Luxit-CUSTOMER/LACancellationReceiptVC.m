//
//  LACancellationReceiptVC.m
//  Luxit
//
//  Created by GP on 27/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "LACancellationReceiptVC.h"
#import "LAUserHomeVC.h"
#import "LAParentViewController.h"
#import "Constant.h"

@implementation LACancellationReceiptVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    [progressHud() hide];
   
    self.view.backgroundColor=[UIColor whiteColor];
    
    self.navigationItem.hidesBackButton=YES;
    self.navigationItem.leftBarButtonItem=nil;
    
   
    CGRect _frame=CGRectMake(0.0, 15.0, 190, 50.0);
    NSDictionary *_attributes;
    _attributes=@{
                  kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                  };
    UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
    
    
    _attributes=@{
                  kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                  kASTextColor:COLOR_THEME_BROWN,
                  kASText:@"RECEIPT",
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                  };
    [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
    
    self.navigationItem.titleView=_headerLabel;
    
    
    [self.menuContainerViewController disablePan];
    
    _attributes=@{
                  kCCBackgroundColor: [UIColor colorWithWhite:0.0 alpha:0.2]
                  };
   
     _frame=CGRectMake(0.0, 0.0, self.view.frame.size.width, 0.5);
   
    [self.view addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];
    
    _attributes=@{
                  kCCText: @"Help",
                  kCCTextColor:COLOR_THEME_BROWN,
                  kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight],
                  kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0]
                  };
    
    UIButton *_helpButton=[ccManager() buttonWithAttributes:_attributes frame:CGRectMake(0.0, 0.0, 80.0, 50.0) completion:^(UIButton *sender)
                           {
                               [self helpButtonAction];
                           }];
    
    UIBarButtonItem *_helpButtonItem=[[UIBarButtonItem alloc]initWithCustomView:_helpButton];
    
   UIBarButtonItem *_rightSpaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    _rightSpaceItem.width = -30.0;
    
    self.navigationItem.rightBarButtonItems=[NSArray arrayWithObjects:_rightSpaceItem,_helpButtonItem, nil];
    
    _frame=CGRectMake(0.0, 0.0,self.view.frame.size.width , 1.0);
    _attributes=@{
                  kCCImage:[UIImage imageNamed:@"seprator.png"]
                  };
    UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
    [self.view addSubview:_divider];
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_tableView==nil)
    {
        NSDictionary *_attributes=nil;
 
        _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0.0, 0.0, self.view.frame.size.width, self.view.frame.size.height-43.5) style:UITableViewStylePlain];
        _tableView.delegate=self;
        _tableView.dataSource=self;
        _tableView.showsVerticalScrollIndicator=NO;
        _tableView.backgroundColor=[UIColor clearColor];
        _tableView.separatorColor=[UIColor clearColor];
        [self.view addSubview:_tableView];
        

        
        CGRect _frame=CGRectMake(0.0, self.view.frame.size.height-43.5, self.view.frame.size.width, 43.5);
        _attributes=@{
                      kCCBackgroundColor:COLOR_THEME_DARKGRAY
                      };
        UIButton *_continueButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
            [self submitButtonAction];
        }];
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:1.35],
                      kASTextColor:COLOR_THEME_BROWN,
                      kASText:@"CONTINUE",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0]
                      };
        [_continueButton setAttributedTitle:[NSMutableAttributedString attributedStringWithAttributes:_attributes] forState:UIControlStateNormal];
        [self.view addSubview:_continueButton];
    }
}


#pragma mark------------------------------------------------------------
#pragma mark TABLEVIEW DELEGATE/ DATASOURCE
#pragma mark------------------------------------------------------------

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0)
    {
        return 87.50;
    }
    else if (indexPath.row==1)
    {
        return 176.0;
    }
    else
    {
        return 44.0;
    }
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=[NSString stringWithFormat:@"Cell_%i",(int)indexPath.row];
    
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
    
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        if (indexPath.row==0)
        {
            NSDictionary *_attributes=nil;

            CGRect _frame=CGRectMake(10.0, 13.5, tableView.frame.size.width-20, 15.0);
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0],
                          kASText:[[appDelegate().jobDetail.itemName stringByReplacingOccurrencesOfString:@"\n" withString:@" "] uppercaseString],
                          kASCharacterSpace:[NSNumber numberWithFloat:3.5]
                          };
            UILabel *_itemNameLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _itemNameLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_itemNameLabel];
            
 
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_LIGHTPINK
                      ];
            
            _frame=CGRectMake(tableView.frame.size.width/2-12.0, _frame.origin.y+_frame.size.height+14.5, 24.0, 0.5);
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            _customLayer.alpha=0.8;
            [_cell.contentView addSubview:_customLayer];
            

            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"Cancellation Fee",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:13.0]
                          };
            _frame=CGRectMake(10.0, _frame.origin.y+_frame.size.height+15.0, tableView.frame.size.width-20, 14.0);
            UILabel *_staticCancellationLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticCancellationLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_staticCancellationLabel];
           
        }
        
        else if (indexPath.row==1)
        {
            int numberOfRows=4;
            
            NSDictionary *_attributes=nil;
            
            CGRect _frame=CGRectMake(8.0, 0.0, tableView.frame.size.width-16.0, 176.0);
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_BROWN
                      ];
            
            CustomLayer*_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMVertical];
            [_cell.contentView addSubview:_customLayer];
            
            
            _attributes=@{
                          kCCBackgroundColor: [UIColor whiteColor]
                          };
            
            _frame=CGRectMake(_frame.origin.x+0.5, _frame.origin.y+0.5,_frame.size.width-1.0, _frame.size.height-1.0);
            UIView *_containerView=[ccManager() viewWithAttributes:_attributes frame:_frame];
            [_cell.contentView addSubview:_containerView];

            
            [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, _containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.55)]];
            
            [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, 2*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.6)]];
            
             [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, 3*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.6)]];
            
 
            _frame=CGRectMake(16.0, 0.0, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"DATE",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticDateLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticDateLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticDateLabel];
            
          
            
            _attributes=@{
                          kCCText: appDelegate().jobDetail.dateString,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
          
            _frame=CGRectMake(16.0, _containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"TIME",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticTimeLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTimeLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticTimeLabel];
  
            _attributes=@{
                          kCCText: appDelegate().jobDetail.timeString,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
       
            _frame=CGRectMake(16.0, 2*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"ADDRESS",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticAddressLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticAddressLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticAddressLabel];
            
            _frame=CGRectMake(90.0, 2*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-105.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kCCText: appDelegate().jobDetail.location,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            

            _frame=CGRectMake(16.0, 3*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"TECHNICIAN",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticTechnicianLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTechnicianLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticTechnicianLabel];
            
            _attributes=@{
                          kCCText: appDelegate().jobDetail.technician.firstName,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
        }
        
        else if (indexPath.row==2)
        {
            NSDictionary *_attributes=nil;
            CGRect _frame=CGRectMake(8.0, 0.0, tableView.frame.size.width-20.0,45.0);
  
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:1.4],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"TOTAL",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticTotalLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTotalLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_staticTotalLabel];
            
            
            _attributes=@{
                          kCCText: [NSString stringWithFormat:@"$%i",(int)appDelegate().jobDetail.cancellationFees],
                          kCCTextColor:COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:14.0],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            _frame=CGRectMake(8.0, 0.0, tableView.frame.size.width-16.0,45.0);
            [_cell.contentView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            
            _frame=CGRectMake(8.0, 43.5, 24.0, 0.5);
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_LIGHTPINK
                      ];
            
            CustomLayer*_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMVertical];
            [_cell.contentView addSubview:_customLayer];
            
        }
        else if (indexPath.row==3)
        {

            NSDictionary *_attributes=nil;
            CGRect _frame=CGRectMake(8.0, 0.0, tableView.frame.size.width-16.0,45.0);
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:1.4],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"CHARGED TO",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticChargedToLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticChargedToLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_staticChargedToLabel];
            
            NSString *_paymentMethodName=@"";
            
            if (appDelegate().userInfo.paymentMode.type==PTCreditCard)
            {
                _paymentMethodName=[NSString stringWithFormat:@"xxxx %@",[appDelegate().userInfo.paymentMode.cardNumber substringWithRange:NSMakeRange(appDelegate().userInfo.paymentMode.cardNumber.length-4, 4)]];
            }
            else
            {
                if (appDelegate().userInfo.paymentMode.email.length>20)
                {
                    _paymentMethodName=[NSString stringWithFormat:@"%@...",[appDelegate().userInfo.paymentMode.email substringToIndex:14]];
                }
                else
                {
                    _paymentMethodName=appDelegate().userInfo.paymentMode.email;
                }
            }
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:14.0],
                          kASText:_paymentMethodName,
                          kASCharacterSpace:[NSNumber numberWithFloat:0.354],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            _frame=CGRectMake(90.0, 10.0, tableView.frame.size.width-98.0,20.0);
            UILabel *_paymentMethodInfoLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _paymentMethodInfoLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_paymentMethodInfoLabel];
        }
    }
    return _cell;
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONS
#pragma mark------------------------------------------------------------

- (void)submitButtonAction
{
    [progressHud() showWithTitle:@"Please wait"];
    
    NSDictionary *_attributes=@{
                                @"userId":appDelegate().userInfo.userId,
                                @"jobId":appDelegate().jobDetail.jobId,
                                @"status":@"2",
                                @"comment":@""
                                };
    [API() cancelJobWithAttributes:_attributes completion:^(BOOL success,NSError *error,BOOL invalid)
    {
        if (success)
        {
            [appDelegate().jobDetail resetJobDetails];
           
            [self.menuContainerViewController switchView];
            
           
            if (!appDelegate().jobDetail.isPaidByPaypal)
            {
                [progressHud() hide];
            }
        }
        else
        {
            if (invalid)
            {
               [progressHud() showWithTitle:@"Please wait"];
               
                NSDictionary *_attributes=@{
                                            @"userId":appDelegate().userInfo.userId
                                            };
                [API() fetchLastCreatedJobStatusWithAttributes:_attributes completion:^(BOOL success,NSError *error1)
                {
                    [progressHud() hide];
                    if (success)
                    {
                        [self.menuContainerViewController switchView];
                    }
                    else
                    {
                       [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
                    }
                }];
                return;
            }
            
            [progressHud() hide];
           
            [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
        }
    }];

}

- (void)helpButtonAction
{
    MFMailComposeViewController* _mailController = [[MFMailComposeViewController alloc] init];
    _mailController.mailComposeDelegate = self;
    [_mailController setSubject:@"Cancelled Booking"];
    [_mailController setToRecipients:@[@"support@luxit.me"]];
    [self presentViewController:_mailController animated:YES completion:nil];
}


- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
