//
//  Job.h
//  Luxit
//
//  Created by GP on 28/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TechnicianInfo.h"

@interface Job : NSObject

@property (nonatomic, retain) NSDate *date;
@property (nonatomic, retain) NSString *jobId;
@property (nonatomic, retain) NSString *dateString;
@property (nonatomic, retain) NSString *dayString;
@property (nonatomic, retain) NSString *monthString;
@property (nonatomic, retain) NSString *timeString;
@property (nonatomic, retain) NSString *itemName;
@property (nonatomic, retain) NSString *itemPrice;
@property (nonatomic, retain) NSString *location;
@property (nonatomic, retain) TechnicianInfo *technician;
@property (nonatomic, readwrite) NSString *statusString;

- (id)initWithAttributes:(NSDictionary *)attributes;

@end
