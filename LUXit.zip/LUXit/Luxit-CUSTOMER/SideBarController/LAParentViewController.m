//
//  LAParentViewController.m
//  Luxit
//
//  Created by GP on 21/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "LAParentViewController.h"
#import "Constant.h"

#define RightSidePadding 100.0

@implementation LAParentViewController

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

+ (LAParentViewController *)containerWithCenterViewController:(id)centerViewController
{
    LAParentViewController *controller = [LAParentViewController new];
    controller.centerViewController = centerViewController;
    return controller;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
  
    self.view.backgroundColor=COLOR_THEME_DARKGRAY;
  
    _menuState=MSClosed;
    _containerView=[[UIView alloc]initWithFrame:self.view.bounds];
    _containerView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:_containerView];

    [_centerViewController didMoveToParentViewController:self];
    [self addChildViewController:_centerViewController];
    [_containerView addSubview:[_centerViewController view]];
    
    CGRect pathRect = _containerView.bounds;
    pathRect.size = _containerView.frame.size;
    _containerView.layer.shadowPath = [UIBezierPath bezierPathWithRect:pathRect].CGPath;
    _containerView.layer.shadowOpacity = 0.55;
    _containerView.layer.shadowRadius = 2.0;
    _containerView.layer.shadowColor = [[UIColor blackColor] CGColor];
    _containerView.layer.rasterizationScale = [[UIScreen mainScreen] scale];
    
    [self addGestures];
}


#pragma mark------------------------------------------------------------
#pragma mark GESTURES
#pragma mark------------------------------------------------------------

-(void)addGestures
{
    _tapGesture=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(handleTapGesture)];
    [_containerView addGestureRecognizer:_tapGesture];
    _tapGesture.enabled=NO;
    
   _panGesture=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(handlePan:)];
    _panGesture.delegate=self;
   [_containerView addGestureRecognizer:_panGesture];
}


- (void)enablePan
{
    _panGesture.enabled=YES;
}


- (void)disablePan
{
    _panGesture.enabled=NO;
}


- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer
{
    return YES;
}


- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return NO;
}


-(void)handleTapGesture
{
    _tapGesture.enabled=NO;
    [_centerViewController view].userInteractionEnabled=YES;
    [self close];
}


- (void)handlePan:(UIPanGestureRecognizer *)recognizer
{
    UIView *view = (UIView *)_containerView;;
  
    CGPoint translation = [recognizer translationInView:view];
   
    CGFloat xOffset=fabs(translation.x) ;
  
    CGFloat _threshold=panThreshold;
  
    if (translation.x>0)
    {
        _threshold=0.0;
    }
    
    if (xOffset>_threshold)
    {
        if ( (_menuState==MSClosed && translation.x<0.0)||(_menuState==MSOpen && translation.x>0.0))
        {
            if (translation.x>0.0)
            {
                xOffset=-(self.view.frame.size.width-RightSidePadding)+xOffset;
               
                if (xOffset>0.0)
                    xOffset=0.0;
               
                _containerView.frame=CGRectMake(xOffset, view.frame.origin.y, view.frame.size.width, view.frame.size.height);
            }
            else
            {
                _containerView.frame=CGRectMake(-(xOffset-_threshold), view.frame.origin.y, view.frame.size.width, view.frame.size.height);
            }
        }
    }
    if (recognizer.state==UIGestureRecognizerStateEnded||recognizer.state==UIGestureRecognizerStateCancelled||recognizer.state==UIGestureRecognizerStateFailed)
    {
        if(fabs(_containerView.frame.origin.x)>=(self.view.frame.size.width-RightSidePadding)/2)
        {
            _tapGesture.enabled=YES;
          
            _menuState=MSOpen;
         
            [_centerViewController view].userInteractionEnabled=NO;
           
            [self adjustCenterAnimationWithFrame:CGRectMake(-(self.view.frame.size.width-RightSidePadding), 0.0, self.view.frame.size.width, self.view.frame.size.height) withDuration:0.2];
        }
        else
        {
            _tapGesture.enabled=NO;
          
            _menuState=MSClosed;
           
            [_centerViewController view].userInteractionEnabled=YES;
          
            [self adjustCenterAnimationWithFrame:CGRectMake(0.0, 0.0, self.view.frame.size.width, self.view.frame.size.height) withDuration:0.2];
        }
    }
}


-(void)resetScreen
{
    _tapGesture.enabled=NO;
    
    _menuState=MSClosed;
    
    [_centerViewController view].userInteractionEnabled=YES;
   
    [self adjustCenterAnimationWithFrame:CGRectMake(0.0, 0.0, self.view.frame.size.width, self.view.frame.size.height) withDuration:0.0];
}


#pragma mark------------------------------------------------------------
#pragma mark SIDE MENU HANDLER
#pragma mark------------------------------------------------------------

-(void)openSideMenu
{
    _menuState=MSOpen;
   
    _tapGesture.enabled=YES;
   
    [_centerViewController view].userInteractionEnabled=NO;
  
    [self adjustCenterAnimationWithFrame:CGRectMake(-(self.view.frame.size.width-RightSidePadding), 0.0, self.view.frame.size.width, self.view.frame.size.height) withDuration:0.3];
}


- (void)closeSideMenu:(CloseStatus)status
{
    _tapGesture.enabled=NO;
  
    [_centerViewController view].userInteractionEnabled=YES;
  
    [self adjustCenterAnimationWithFrame:CGRectMake(0.0, 0.0, self.view.frame.size.width, self.view.frame.size.height) withDuration:0.3];
      _menuState=MSClosed;
   
    [self adjustCenterAnimationWithFrame:CGRectMake(0.0, 0.0, self.view.frame.size.width, self.view.frame.size.height) withDuration:0.3];
}


-(void)close
{
     _tapGesture.enabled=NO;
   
    [_centerViewController view].userInteractionEnabled=YES;
   
    _menuState=MSClosed;
   
    [self adjustCenterAnimationWithFrame:CGRectMake(0.0, 0.0, self.view.frame.size.width, self.view.frame.size.height) withDuration:0.25];
}


- (void)toggleSideMenuState
{
    if(_menuState==MSClosed)
    {
        [_centerViewController view].userInteractionEnabled=NO;
       
        _tapGesture.enabled=YES;
       
        _menuState=MSOpen;
       
        [self adjustCenterAnimationWithFrame:CGRectMake(-(self.view.frame.size.width-RightSidePadding), 0.0, self.view.frame.size.width, self.view.frame.size.height) withDuration:0.3];
    }
    else
    {
        [_centerViewController view].userInteractionEnabled=YES;
       
        _tapGesture.enabled=NO;
       
        _menuState=MSClosed;
        
        [self adjustCenterAnimationWithFrame:CGRectMake(0.0, 0.0, self.view.frame.size.width, self.view.frame.size.height) withDuration:0.3];
    }
}


-(void)adjustCenterAnimationWithFrame:(CGRect)frame withDuration:(float)duration
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:duration];
    _containerView.frame=frame;
    [UIView commitAnimations];
}

#pragma mark------------------------------------------------------------
#pragma mark SIDE MENU ITEMS
#pragma mark------------------------------------------------------------

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    if(_tableView==nil)
    {
        _selectedRowIndex=0;
      
        _menuItems=[[NSMutableArray alloc]initWithObjects:
                    @"MY DETAILS",
                    @"HELP & FEEDBACK",
                    @"ABOUT",
                    nil];
      
        _tableView=[[UITableView alloc]initWithFrame:CGRectMake(15.0, 67.5, self.view.frame.size.width-20.0, self.view.frame.size.height) style:UITableViewStylePlain];
        _tableView.backgroundColor=[UIColor clearColor];
        _tableView.separatorColor=[UIColor clearColor];
        _tableView.delegate=self;
        _tableView.dataSource=self;
        _tableView.scrollEnabled=NO;
        [self.view addSubview:_tableView];
      
        NSDictionary *_attributes;
        
        CGRect _frame=CGRectMake(15.0, self.view.frame.size.height-47.5, self.view.frame.size.width-40.0, 16.0);
       
        UILabel *_logoutLabel=[ccManager() labelWithAttributes:nil frame:_frame];

        _attributes=@{
                      kASTextColor: COLOR_THEME_BROWN,
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:16.0],
                      kASText:@"LOGOUT",
                      kASCharacterSpace:[NSNumber numberWithFloat:1.6],
                      kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                      };
        _logoutLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];

        [self.view addSubview:_logoutLabel];
       
        [self.view addSubview:[ccManager() buttonWithAttributes:nil frame:_frame completion:^(UIButton *sender)
        {
            [self signOutButtonAction];
        }]];
        
        _attributes=@{
                      kCCImage: [UIImage imageNamed:@"Side_Menu_Logo.png"],
                      kCCImage:[NSNumber numberWithInt:UIViewContentModeScaleAspectFit]
                      };
        _frame=CGRectMake(137.5, 311, 145, 145);
        [self.view addSubview:[ccManager() imageViewWithAttributes:_attributes frame:_frame]];
        
        
        
        [self.view bringSubviewToFront:_containerView];
    }
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _menuItems.count;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 65.0;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=@"Cell";
   
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
   
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        
        _cell.textLabel.backgroundColor=[UIColor clearColor];
        
        if (indexPath.row==0 || indexPath.row==1)
        {
            [_cell.contentView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: [UIColor blackColor],kCCAlpha:@"0.8"} frame:CGRectMake(tableView.frame.size.width-40.0, 64.0, 24.0, 0.5)]];
        }
    }
    NSDictionary *_attributes;
    _attributes=@{
                  kASTextColor: [UIColor whiteColor],
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0],
                  kASText:[_menuItems objectAtIndex:indexPath.row],
                  kASCharacterSpace:[NSNumber numberWithFloat:1.8],
                  kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                  };
    
    NSMutableAttributedString *_attributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
    _cell.textLabel.attributedText=_attributedString;
   
    return _cell;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UINavigationController *_centerNavigationController=(UINavigationController *)_centerViewController;
    if (indexPath.row==0)
    {
        LAMyDetailsVC *_myDetailsVC=[[LAMyDetailsVC alloc]init];
        [_centerNavigationController pushViewController:_myDetailsVC animated:NO];
        [UIView transitionWithView:self.view duration:0.1 options:UIViewAnimationOptionTransitionCrossDissolve animations:^{} completion:nil];
    }
    else if (indexPath.row==1)
    {
        LAHelpAndFeedbackVC *_helpAndFeedbackVC=[[LAHelpAndFeedbackVC alloc]init];
        [_centerNavigationController pushViewController:_helpAndFeedbackVC animated:NO];
        [UIView transitionWithView:self.view duration:0.1 options:UIViewAnimationOptionTransitionCrossDissolve animations:^{} completion:nil];
    }
    else if (indexPath.row==2)
    {
        LAAboutUsVC *_aboutUsVC=[[LAAboutUsVC alloc]init];
        [_centerNavigationController pushViewController:_aboutUsVC animated:NO];
        [UIView transitionWithView:self.view duration:0.1 options:UIViewAnimationOptionTransitionCrossDissolve animations:^{} completion:nil];
    }
    
    [self close];
}


- (void)signOutButtonAction
{
    [ccManager() showAlertWithTitle:@"Do you wish to\nLog Out?" message:@"" buttons:@[@"Cancel",@"Log Out"] completion:^(NSInteger buttonIndex)
    {
        if (buttonIndex==1)
        {
            
            {
                [appDelegate().userInfo reset];
                
                appDelegate().jobDetail.status = -1;
                
                NSString *appDomain = [[NSBundle mainBundle] bundleIdentifier];
                [[NSUserDefaults standardUserDefaults] removePersistentDomainForName:appDomain];
                
                [appDelegate() showAppHomeViewController];
            }
            
        }
    }];
}


- (void)switchView
{
    if (_finishedUpdatingView)
    {
        _finishedUpdatingView();
    }
}

@end
