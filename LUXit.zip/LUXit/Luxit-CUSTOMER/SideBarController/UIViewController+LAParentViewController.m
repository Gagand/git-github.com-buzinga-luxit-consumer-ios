//
//  UIViewController+LAParentViewController.m
//  Luxit
//
//  Created by GP on 21/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "UIViewController+LAParentViewController.h"
#import "LAParentViewController.h"

@implementation UIViewController (LAParentViewController)

@dynamic menuContainerViewController;

- (LAParentViewController *)menuContainerViewController
{
    id containerView = self;
  
    while (![containerView isKindOfClass:[LAParentViewController class]] && containerView)
    {
        if ([containerView respondsToSelector:@selector(parentViewController)])
        {
            containerView = [containerView parentViewController];
        }
        if ([containerView respondsToSelector:@selector(splitViewController)] && !containerView)
        {
            containerView = [containerView splitViewController];
        }
    }
    return containerView;
}

@end
