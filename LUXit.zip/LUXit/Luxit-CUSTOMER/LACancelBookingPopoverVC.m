//
//  LACancelBookingPopoverVC.m
//  Luxit
//
//  Created by GP on 27/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "LACancelBookingPopoverVC.h"
#import "Constant.h"

@implementation LACancelBookingPopoverVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [progressHud() hide];
    
    _blackOpaqueLayerView=[[UIView alloc]initWithFrame:self.view.bounds];
    _blackOpaqueLayerView.backgroundColor=[UIColor colorWithWhite:0.0 alpha:0.6];
    [self.view addSubview:_blackOpaqueLayerView];
    _blackOpaqueLayerView.alpha=0.0;
    
    
    _containerView=[[UIView alloc]initWithFrame:CGRectMake(15.0, self.view.frame.size.height, self.view.frame.size.width-30.0, self.view.frame.size.height-190.0)];
    _containerView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:_containerView];
    
    _tableView=[[UITableView alloc]initWithFrame:_containerView.bounds style:UITableViewStylePlain];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    _tableView.backgroundColor=[UIColor clearColor];
    _tableView.separatorColor=[UIColor clearColor];
    [_containerView addSubview:_tableView];
    
    
    NSDictionary *_attributes=nil;
    _attributes=@{
                  kCCImage: [UIImage imageNamed:@"Close.png"]
                  };
    CGRect _frame=CGRectMake(0.0, 0.0, 40.0, 40.0);
    [_containerView addSubview:[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){[self closeButtonAction];}]];
  
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self showContainerView];
}

- (void)showContainerView
{
    [UIView animateWithDuration:0.1 animations:^()
     {
         _blackOpaqueLayerView.alpha=1.0;
     }
                     completion:^(BOOL finished)
     {
         if (finished)
         {
             [UIView animateWithDuration:0.2 animations:^()
              {
                  _containerView.frame=CGRectMake(16.0, 90.0, self.view.frame.size.width-32.0, _containerView.frame.size.height);
              } completion:nil];
         }
     }];
}


- (void)closeButtonAction
{
    [UIView animateWithDuration:0.2 animations:^()
     {
         _containerView.frame=CGRectMake(16.0, self.view.frame.size.height, self.view.frame.size.width-32.0, _containerView.frame.size.height);
         
     }
     completion:^(BOOL finished)
     {
         if (finished)
         {
             [UIView animateWithDuration:0.1 animations:^()
              {
                  _blackOpaqueLayerView.alpha=0.0;
              }
              completion:^(BOOL finishded)
              {
                  if (finishded)
                  {
                      [self dismissViewControllerAnimated:NO completion:nil];
                  }
              }];
         }
     }];
}
#pragma mark------------------------------------------------------------
#pragma mark TABLEVIEW DELEGATE/ DATASOURCE
#pragma mark------------------------------------------------------------

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0)
    {
        return 77.50;
    }
    else if (indexPath.row==1)
    {
        return 176.0;
    }
    else if (indexPath.row==2)
    {
        return 50.0;
    }
    else
    {
        return 55.0;
    }
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=[NSString stringWithFormat:@"Cell_%i",(int)indexPath.row];
    
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
    
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        if (indexPath.row==0)
        {
            NSDictionary *_attributes=nil;
            
            CGRect _frame=CGRectMake(10.0, 33.5, tableView.frame.size.width-20, 15.0);
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0],
                          kASText:[[appDelegate().jobDetail.itemName stringByReplacingOccurrencesOfString:@"\n" withString:@" "] uppercaseString],
                          kASCharacterSpace:[NSNumber numberWithFloat:3.5]
                          };
            UILabel *_itemNameLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _itemNameLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_itemNameLabel];
            
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_LIGHTPINK
                      ];
            
            _frame=CGRectMake(tableView.frame.size.width/2-12.0, _frame.origin.y+_frame.size.height+14.5, 24.0, 0.5);
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_customLayer];
     
        }
        
        else if (indexPath.row==1)
        {
            int numberOfRows=4;
            
            NSDictionary *_attributes=nil;
            
            CGRect _frame=CGRectMake(8.0, 0.0, tableView.frame.size.width-16.0, 176.0);
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_BROWN
                      ];
            
            CustomLayer*_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMVertical];
            [_cell.contentView addSubview:_customLayer];
            
            
            _attributes=@{
                          kCCBackgroundColor: [UIColor whiteColor]
                          };
            
            _frame=CGRectMake(_frame.origin.x+0.5, _frame.origin.y+0.5,_frame.size.width-1.0, _frame.size.height-1.0);
            UIView *_cellContainerView=[ccManager() viewWithAttributes:_attributes frame:_frame];
            [_cell.contentView addSubview:_cellContainerView];
            
            
            [_cellContainerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, _cellContainerView.frame.size.height/numberOfRows, _cellContainerView.frame.size.width, 0.55)]];
            
            [_cellContainerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, 2*_cellContainerView.frame.size.height/numberOfRows, _cellContainerView.frame.size.width, 0.6)]];
            
            [_cellContainerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, 3*_cellContainerView.frame.size.height/numberOfRows, _cellContainerView.frame.size.width, 0.6)]];
            
            
            _frame=CGRectMake(16.0, 0.0, _cellContainerView.frame.size.width-32.0, _cellContainerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"DATE",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticDateLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticDateLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cellContainerView addSubview:_staticDateLabel];
            
            
            
            _attributes=@{
                          kCCText: appDelegate().jobDetail.dateString,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            [_cellContainerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            
            _frame=CGRectMake(16.0, _cellContainerView.frame.size.height/numberOfRows, _cellContainerView.frame.size.width-32.0, _cellContainerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"TIME",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticTimeLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTimeLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cellContainerView addSubview:_staticTimeLabel];
            
            _attributes=@{
                          kCCText: appDelegate().jobDetail.timeString,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            [_cellContainerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            
            _frame=CGRectMake(16.0, 2*_cellContainerView.frame.size.height/numberOfRows, _cellContainerView.frame.size.width-32.0, _cellContainerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"ADDRESS",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticAddressLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticAddressLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cellContainerView addSubview:_staticAddressLabel];
            
            _frame=CGRectMake(90.0, 2*_cellContainerView.frame.size.height/numberOfRows, _cellContainerView.frame.size.width-105.0, _cellContainerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kCCText: appDelegate().jobDetail.location,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            [_cellContainerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            
            _frame=CGRectMake(16.0, 3*_cellContainerView.frame.size.height/numberOfRows, _cellContainerView.frame.size.width-32.0, _cellContainerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"TECHNICIAN",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticTechnicianLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTechnicianLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cellContainerView addSubview:_staticTechnicianLabel];
            
            _attributes=@{
                          kCCText: appDelegate().jobDetail.technician.firstName,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            [_cellContainerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
        }
        
        else if (indexPath.row==2)
        {
            NSDictionary *_attributes=nil;
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0],
                          kASText:[NSString stringWithFormat:@"Cancelling a booking after a technician has accepted a booking will occur a $%i fee",(int)appDelegate().jobDetail.cancellationFees],
                          kASCharacterSpace:[NSNumber numberWithFloat:0.24]
                          };
            
            CGRect _frame=CGRectMake(10.0, 0.0, tableView.frame.size.width-20.0,50.0);
            
            UILabel *_staticTextLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTextLabel.alpha=0.8;
            _staticTextLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_cell.contentView addSubview:_staticTextLabel];
            
        }
        
        else if (indexPath.row==3)
        {
            NSDictionary *_attributes=nil;
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_BROWN,
                      COLOR_THEME_LIGHTPINK
                      ];
            CGRect _frame=CGRectMake(16.0, 7.5, tableView.frame.size.width-32.0, 44.0);
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_customLayer];
            
            
            _frame=CGRectMake(_frame.origin.x+1.5, _frame.origin.y+1.5, _frame.size.width-3.0, _frame.size.height-3.0);
            
            _attributes=@{
                          kCCBackgroundColor:COLOR_THEME_DARKGRAY
                          };
            UIButton *_cancelBookingButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
                [self cancelBookingButtonAction];
            }];
            
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0],
                          kASText:@"CANCEL BOOKING",
                          kASCharacterSpace:[NSNumber numberWithFloat:1.35]
                          };
            
            NSMutableAttributedString *_attributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            
            [_cancelBookingButton setAttributedTitle:_attributedString forState:UIControlStateNormal];
            [_cell.contentView addSubview:_cancelBookingButton];
            
        }

    }
    return _cell;
}

- (void)cancelBookingButtonAction
{
    [UIView animateWithDuration:0.2 animations:^()
     {
         _containerView.frame=CGRectMake(16.0, self.view.frame.size.height, self.view.frame.size.width-32.0, _containerView.frame.size.height);
         
     }
     completion:^(BOOL finished)
     {
         if (finished)
         {
             [UIView animateWithDuration:0.1 animations:^()
              {
                  _blackOpaqueLayerView.alpha=0.0;
              }
              completion:^(BOOL finishded)
              {
                  if (finishded)
                  {
                      if (_finishedCancellingBooking)
                      {
                          _finishedCancellingBooking();
                      }
                      
                      [self dismissViewControllerAnimated:NO completion:nil];
                  }
              }];
             
         }}];
}
@end
