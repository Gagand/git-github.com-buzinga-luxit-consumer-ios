//
//  LAUserHomeVC.m
//  Luxit
//
//  Created by GP on 21/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "LAUserHomeVC.h"
#import "LAParentViewController.h"

@implementation LAUserHomeVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)showLocationAlert1
{
    appDelegate().updateLocationAuthorization=^(BOOL authorize)
    {
        if (!authorize)
        {
            [self showLocationAlert2];
        }
        else
        {
            [appDelegate() enablePushNotification];
        }
    };
    [appDelegate().locationManager requestAlwaysAuthorization];
    [appDelegate() enableLocationService];
    
}


- (void)showLocationAlert2
{
    NSArray *_buttonsArray=@[@"Close",@"Go to Settings"];

    [ccManager() showAlertWithTitle:@"Change your Settings to allow LUXit to Access to Your Current Location" message:@"We need to know your current location  to provide an accurate service and find the closest technicians around you. Please go to the App Settings, tap on Location and then select Always." buttons:_buttonsArray completion:^(NSInteger buttonIndex)
    {
       if ([[_buttonsArray objectAtIndex:buttonIndex]isEqualToString:@"Go to Settings"])
        {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
        }
        else
        {
            [appDelegate() enablePushNotification];
        }
    }];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    _menuItems=[[NSMutableArray alloc]init];
    
    appDelegate().jobDetail.changed=YES;
    if (appDelegate().locationServiceStatus==0)
    {
        [self showLocationAlert1];
    }
    else
    {
        if ([[UIApplication sharedApplication]currentUserNotificationSettings].types==UIUserNotificationTypeNone)
        {
            [appDelegate() validateRemoteNotification];
        }
    }

    
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"MySelectedLocation"]!=NULL)
    {
        [appDelegate().userInfo updateLocationWithAttributes:[[NSUserDefaults standardUserDefaults]objectForKey:@"MySelectedLocation"]];
    }
    else
    {
//        if ([[NSUserDefaults standardUserDefaults]objectForKey:@"MyCurrentLocation"]!=NULL)
//        {
//            [appDelegate().userInfo updateLocationWithAttributes:[[NSUserDefaults standardUserDefaults]objectForKey:@"MyCurrentLocation"]];
//        }
//        else
//        {
            [appDelegate().userInfo updateLocationWithAttributes:nil];
       // }
    }
    
    _isJobStatusFeteched=YES;
   
    self.view.backgroundColor=[UIColor whiteColor];
    
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"Menu.png"] style:UIBarButtonItemStylePlain target:self action:@selector(menuButtonAction)];
    
    NSDictionary *_attributes=nil;
    _attributes=@{
                  kCCImage:[UIImage imageNamed:@"Header_Logo.png"],
                  kCCContentMode:[NSNumber numberWithInt:UIViewContentModeCenter]
                  };
    self.navigationItem.titleView=[ccManager() imageViewWithAttributes:_attributes frame:CGRectMake(0.0, 0.0, 120.0, 55.0)];
    
    CGRect _frame=CGRectMake(16.0, 0, self.view.frame.size.width-32.0, 22.0);
    
    NSArray *_colors=nil;
    _colors=@[
              COLOR_THEME_BROWN,
              COLOR_THEME_LIGHTPINK
              ];
    CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
    [self.view addSubview:_customLayer];
    
    _frame=CGRectMake(16.5, 0.5, self.view.frame.size.width-33.0, 21.0);
   
    _attributes=@{
                  kCCBackgroundColor: [UIColor whiteColor]
                  };
    UIView *_containerView=[ccManager() viewWithAttributes:_attributes frame:_frame];
    [self.view addSubview:_containerView];
    
    
    _attributes=@{
                  kCCImage:[UIImage imageNamed:@"location.png"],
                  kCCContentMode:[NSNumber numberWithInt:UIViewContentModeScaleAspectFit]
                  };
    _frame=CGRectMake(5.0, 4.0, 10, 14.0);
    [_containerView addSubview:[ccManager() imageViewWithAttributes:_attributes frame:_frame]];
    
    NSString *_loactionString=@"Choose location";
    if (appDelegate().userInfo.location.isLocatioAvailable)
    {
        _loactionString=appDelegate().userInfo.location.address;
    }
    
    _attributes=@{
                  kCCText:_loactionString,
                  kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter],
                  kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0],
                  kCCTextColor:COLOR_THEME_BROWN
                  };
    
    _frame=CGRectMake(20.0, 0.0, _containerView.frame.size.width-40.0, _containerView.frame.size.height);
    
    _locationLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
    [_containerView addSubview:_locationLabel];
    
    _frame=CGRectMake(0.0, 27.9,self.view.frame.size.width , 1.0);
   
    _attributes=@{
                  kCCImage:[UIImage imageNamed:@"seprator.png"]
                  };
    UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
    [self.view addSubview:_divider];

    _frame=CGRectMake(0.0, 36.5, self.view.frame.size.width, self.view.frame.size.height-65.0-36.5);
    
    _tableView=[[UITableView alloc]initWithFrame:_frame style:UITableViewStylePlain];
    _tableView.backgroundColor=[UIColor clearColor];
    _tableView.separatorColor=[UIColor clearColor];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    _tableView.showsVerticalScrollIndicator=NO;
    [self.view addSubview:_tableView];
   
    _frame=CGRectMake(0.0, 0.0, self.view.frame.size.width, 60.0);
    
    _locatioButton=[ccManager() buttonWithAttributes:nil frame:_frame completion:^(UIButton *sender){
        [self locationButtonAction];
    }];
    
    __block typeof(self) _weakSelf=self;
    
    self.menuContainerViewController.finishedUpdatingView=^()
    {
        [_weakSelf updateViewAccordingToTheLastJobStatus];
    };
    
    apnManager().updateViewOnReceptionOfRemoteNotification=^()
    {
        [self updateViewAccordingToTheLastJobStatus];
    };

    [self.view addSubview:_locatioButton];
    
    [self fetchAndUpdateMenuItems];
    
    [self fetchAndGetLastUpdatedJobStatus];
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
   
    appDelegate().updateAppStatus=^(AppStatus status)
    {
        if (status==ASForeground)
        {
          if (appDelegate().locationServiceStatus!=0)
          {
              [appDelegate() enablePushNotification];
          }
        }
    };
   
    [self checkAndRefundPaypalMoney];
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    NSString *_loactionString=@"Choose location";
    if (appDelegate().userInfo.location.isLocatioAvailable)
    {
        _loactionString=appDelegate().userInfo.location.address;
    }
    _locationLabel.text=_loactionString;
}


#pragma mark------------------------------------------------------------
#pragma mark VIEW OPERATIONS
#pragma mark------------------------------------------------------------

- (void)fetchAndGetLastUpdatedJobStatus
{
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"LastJobDetail"]!=NULL)
    {
        _isJobStatusFeteched=YES;
        
        [appDelegate().jobDetail updateWithAttributes:[[NSUserDefaults standardUserDefaults]objectForKey:@"LastJobDetail"]];
        
        [self updateViewAccordingToTheLastJobStatus];
    }
    else
    {
        _isJobStatusFeteched=NO;
        
        [progressHud() showWithTitle:@"Please wait"];
    }
    
    
    NSDictionary *_attributes=@{
                                @"userId":appDelegate().userInfo.userId
                                };
    
    [API() fetchLastCreatedJobStatusWithAttributes:_attributes completion:^(BOOL success, NSError *error)
     {
         if (success)
         {
             if (_isCategoriesFeteched)
             {
                 [progressHud() hide];
             }
             
             _isJobStatusFeteched=YES;
             
             [appDelegate().jobDetail updateWithAttributes:[[NSUserDefaults standardUserDefaults]objectForKey:@"LastJobDetail"]];
             
             [self updateViewAccordingToTheLastJobStatus];
         }
         else
         {
             if (!_isJobStatusFeteched)
             {
                 [progressHud() hide];
                 
                 [ccManager() showAlertWithTitle:@"Error" message:@"Fail to fetch data. Please retry to fetch again" buttons:@[@"Retry"] completion:^(NSInteger buttonIndex)
                  {
                      [progressHud() showWithTitle:@"Please wait"];
                      
                      [self fetchAndGetLastUpdatedJobStatus];
                  }];
             }
             else
             {
                 if (_isCategoriesFeteched)
                 {
                     [progressHud() hide];
                 }
             }
         }
     }];
}


- (void)checkAndRefundPaypalMoney
{
    NSDictionary *_refundInfoAttributes=[[NSUserDefaults standardUserDefaults]objectForKey:@"RefundInfo"];
    if (_refundInfoAttributes.allKeys.count>0)
    {
        NSString *_transactionId=[_refundInfoAttributes objectForKey:@"transactionId"];
        NSString *_amount       =[_refundInfoAttributes objectForKey:@"amount"];
        
        if (_transactionId.length>0)
        {
            [progressHud() showWithTitle:@"Please wait.\nPayment is refunding to your account"];
          
            [paypalManager() refundAmount:[_amount floatValue] forPaykey:_transactionId completion:^(NSString *tranactionId,TransactionStatus status)
            {
              [progressHud() hide];
                if (status==TSPaid) {
                   
                    [ccManager() showAlertWithTitle:@"Info" message:@"Due payment is refunded to your account." buttons:@[@"Thanks"] completion:nil];
                }
                else if (status==TSPaypalError)
                {
                    
                    [ccManager() showAlertWithTitle:@"Info" message:@"There is some error from paypal. Please connect with luxit team for more info" buttons:@[@"Thanks"] completion:nil];
                }
                else
                {
                    [ccManager() showAlertWithTitle:@"Failure" message:@"Fail to refund your amount. Please retry!" buttons:@[@"Retry"] completion:^(NSInteger buttonIndex)
                    {
                        [self checkAndRefundPaypalMoney];
                    }];
                }
            }];
        }
    }
    else
    {
       NSDictionary *_duePaymentInfoDictionary=[[NSUserDefaults standardUserDefaults]objectForKey:@"DuePaymentInfo"];
        if (_duePaymentInfoDictionary.allKeys.count>0)
        {
           // NSString *_transactionId=[_duePaymentInfoDictionary objectForKey:@"transactionId"];
            NSString *_amount       =[_duePaymentInfoDictionary objectForKey:@"amount"];
           
            NSString *_titleString=@"Pay For Your Booking";
            NSString *_messageString=[NSString stringWithFormat:@"You have a pending payment. Please pay the amount $%i",(int)_amount];
            
            [ccManager() showAlertWithTitle:_titleString message:_messageString buttons:@[@"Pay Now"] completion:^(NSInteger buttonIndex)
            {
                if (buttonIndex==0)
                {
                    [progressHud() showWithTitle:@"Please wait."];
                    
                    [paypalManager() makePaymentWithAmount:[_amount floatValue] completion:^(NSString *transactionId, TransactionStatus status)
                    {
                        if (status==TSPaid)
                        {
                            [progressHud() hide];
                            [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"DuePaymentInfo"];
                            [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"PaypalInfo"];
                            [[NSUserDefaults standardUserDefaults]synchronize];
                        }
                        else
                        {
                            [progressHud() hide];
                            [self checkAndRefundPaypalMoney];
                        }
                    }];
                }
            }];
        }
    }
}


- (void)fetchAndUpdateMenuItems
{
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"HomeMenuItems"]!=NULL)
    {
        _isCategoriesFeteched=YES;
        
        [_menuItems removeAllObjects];
     
        NSArray *_tempMenuItems=[[NSUserDefaults standardUserDefaults]objectForKey:@"HomeMenuItems"];
      
        for (NSDictionary *_menuItemDict in _tempMenuItems)
        {
            [_menuItems addObject:[[MenuItem alloc]initWithAttributes:_menuItemDict]];
        }
        
        [_tableView reloadData];
    }
    else
    {
        _isCategoriesFeteched=NO;
       
        [progressHud() showWithTitle:@"Please wait"];
    }
    
    [self fetchAndUpdatesMenuItemsFromServer];
}


- (void)fetchAndUpdatesMenuItemsFromServer
{
    [API() getMenuOptionsWithCompletion:^(BOOL success, NSError *error)
    {
        if (success)
        {
            if (_isJobStatusFeteched)
            {
                [progressHud() hide];
            }
            
             _isCategoriesFeteched=YES;
            
            [_menuItems removeAllObjects];
           
            NSArray *_tempMenuItems=[[NSUserDefaults standardUserDefaults]objectForKey:@"HomeMenuItems"];
            
            for (NSDictionary *_menuItemDict in _tempMenuItems)
            {
                [_menuItems addObject:[[MenuItem alloc]initWithAttributes:_menuItemDict]];
            }
           
            [_tableView reloadData];
        }
        else
        {
            if (_menuItems.count==0)
            {
                 [progressHud() hide];
                
                [ccManager() showAlertWithTitle:@"Error" message:@"Fail to fetch menu items. Please retry to fetch again" buttons:@[@"Retry"] completion:^(NSInteger buttonIndex)
                {
                    [progressHud() showWithTitle:@"Please wait"];
                   
                    [self fetchAndUpdatesMenuItemsFromServer];
                }];
            }
            else
            {
                if (_isJobStatusFeteched)
                {
                    [progressHud() hide];
                }
            }
        }
    }];
}


#pragma mark------------------------------------------------------------
#pragma mark UITABLEVIEW DELEGATE/ DATASOURCE
#pragma mark------------------------------------------------------------

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _menuItems.count;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return _tableView.frame.size.height/4;
    return 117.0;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=[NSString stringWithFormat:@"Cell%i",(int)indexPath.row];
   
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
    
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        NSDictionary *_attributes=nil;
        _attributes=@{
                      kCCTag:[NSNumber numberWithInt:100]
                      };
        UIView *_containerView=[ccManager() viewWithAttributes:_attributes frame:CGRectMake(16.0, 0.0, tableView.frame.size.width-32.0, _tableView.frame.size.height/4-12)];
        [_cell.contentView addSubview:_containerView];
        
        _attributes=@{
                      kCCTag:[NSNumber numberWithInt:101]
                      };
        [_containerView addSubview:[ccManager() imageViewWithAttributes:_attributes frame:_containerView.bounds]];
        
        _attributes=@{
                      kCCTag:[NSNumber numberWithInt:102]
                      };
       
        CGRect _frame=CGRectMake(65.0, -4.0, _containerView.frame.size.width-130.0, _containerView.frame.size.height-4.0);
        
        [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
        
        _attributes=@{
                      kCCBackgroundColor: COLOR_THEME_BROWN,
                      kCCTag:[NSNumber numberWithInt:103]
                      };
        [_containerView addSubview:[ccManager() viewWithAttributes:_attributes frame:CGRectMake(0, 0,0, 0)]];
    }
    
    MenuItem *_menuItem=(MenuItem *)[_menuItems objectAtIndex:indexPath.row];
    
    UIView *_containerView=(UIView *)[_cell viewWithTag:100];
    
    UIImageView *_imageView=(UIImageView *)[_containerView viewWithTag:101];
   
    if (indexPath.row%2==0)
    {
        _imageView.image=[UIImage imageNamed:@"_60.png"];
    }
    else
    {
        _imageView.image=[UIImage imageNamed:@"_90.png"];
    }
   
    UILabel *_textLabel=(UILabel *)[_containerView viewWithTag:102];
    _textLabel.numberOfLines=4;
    
    NSDictionary *_attributes;
    _attributes=@{
                  kASTextColor: COLOR_THEME_BROWN,
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:20.0],
                  kASText:[_menuItem.name uppercaseString],
                  kASCharacterSpace:[NSNumber numberWithFloat:2.0]
                  };
    
    _textLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
    
    
    UIView *_divider=(UIView *)[_containerView viewWithTag:103];
   
    float _displacementFactor=25.0;
  
    if (self.view.frame.size.height>700.0)
    {
        _displacementFactor=40.0;
    }
    
    _divider.frame=CGRectMake(_containerView.frame.size.width/2-15.0, (_containerView.frame.size.height-_displacementFactor), 30.0, 0.55);
    
    return _cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (appDelegate().userInfo.location.isLocatioAvailable)
    {
        if (appDelegate().userInfo.paymentMode.isPaymentModeAvailable)
        {
            LAPlaceOrderVC *_placeOrderVC=[[LAPlaceOrderVC alloc]init];
            _placeOrderVC.menuItem=(MenuItem *)[_menuItems objectAtIndex:indexPath.row];
            _placeOrderVC.finishedConfirmingBooking=^()
            {
                [self updateViewAccordingToTheLastJobStatus];
            };
            _placeOrderVC.providesPresentationContextTransitionStyle = YES;
            [_placeOrderVC setModalPresentationStyle:UIModalPresentationOverCurrentContext];
            [self.navigationController presentViewController:_placeOrderVC animated:NO completion:nil];
    
        }
        else
        {
            [ccManager() showAlertWithTitle:@"Add Payment Options" message:@"To perform this action, we require you to add a payment option." buttons:[NSArray arrayWithObjects:@"Cancel",@"Add Payment", nil] completion:^(NSInteger buttonIndex)
             {
                 if (buttonIndex==1)
                 {
                     LAAddPaymentTypeVC *_addPaymentVC=[[LAAddPaymentTypeVC alloc]init];
                     _addPaymentVC.typeMode=PTEdit;
                     _addPaymentVC.finishedAddingCard=^()
                     {
                         [self performSelector:@selector(showOrderVC:) withObject:indexPath afterDelay:0.75];
                     };
                     UINavigationController *_navigationController=[[UINavigationController alloc]initWithRootViewController:_addPaymentVC];
                     [ccManager() customizeNavigationBarWithAttributes:@{
                                                                         kCCTintColor: COLOR_THEME_BROWN,
                                                                         kCCBarTintColor:[UIColor whiteColor],
                                                                         kCCTextColor:COLOR_THEME_BROWN,
                                                                         kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                                                                         }
                                                  navigationController:_navigationController];
                     [self presentViewController:_navigationController animated:YES completion:nil];
                 }
             }];
        }
    }
    else
    {
        [ccManager() showAlertWithTitle:@"Info" message:@"Please choose location" buttons:nil completion:nil];
    }
}


- (void)showOrderVC:(NSIndexPath *)indexPath
{
    [self tableView:_tableView didSelectRowAtIndexPath:indexPath];
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONs
#pragma mark------------------------------------------------------------

- (void)locationButtonAction
{
    LALocationPickerVC *_locationPickerVC=[[LALocationPickerVC alloc]init];
    [self presentViewController:_locationPickerVC animated:NO completion:nil];
    [UIView transitionWithView:appDelegate().window duration:0.20 options:UIViewAnimationOptionTransitionCrossDissolve animations:nil completion:nil];
}


- (void)menuButtonAction
{
    [self.menuContainerViewController openSideMenu];
}


- (void)updateViewAccordingToTheLastJobStatus
{
    
    JobStatus _jobStatus=appDelegate().jobDetail.status;

    if (!appDelegate().jobDetail.changed)
    {
        return;
    }
    
    appDelegate().jobDetail.changed=NO;
    
    [self.menuContainerViewController enablePan];

    if (_jobStatus==JSInActiveJobUnpaid)
    {
        [self.navigationController popToRootViewControllerAnimated:NO];
        [self showPaymentPopover];
        return;
    }
    
    else if (_jobStatus==JSInActiveJobPaid)
    {
        [self ativateJob];
        return;
    }
    
    else if (_jobStatus==JSCancelledUnpaid || _jobStatus ==JSCompleteUnpaid)
    {
        [self.navigationController popToRootViewControllerAnimated:NO];
        [self showPaymentPopover];
        return;
    }
    
    else if (_jobStatus==JSNoJob)
    {
        [self.navigationController popToRootViewControllerAnimated:NO];
    }
    
    else if (_jobStatus==JSSearching||_jobStatus==JSCancelByTechnician)
    {
        LATechnicianSearchVC *_searchTechnicianVC=[[LATechnicianSearchVC alloc]init];
        [self.navigationController pushViewController:_searchTechnicianVC animated:NO];
    }
    
    else if (_jobStatus==JSPending)
    {
        LABookedTechinicanDetailVC *_bookedTechnicianDetailVC=[[LABookedTechinicanDetailVC alloc]init];
        [self.navigationController pushViewController:_bookedTechnicianDetailVC animated:NO];
    }
    
    else if (_jobStatus==JSStarted)
    {
        LATechnicanStatusWorkingVC *_bookedTechnicianWorkingVC=[[LATechnicanStatusWorkingVC alloc]init];
        [self.navigationController pushViewController:_bookedTechnicianWorkingVC animated:NO];
    }
    
    else if (_jobStatus==JSCompleted)
    {
        LACompletionReceiptVC *_completionReceiptVC=[[LACompletionReceiptVC alloc]init];
        [self.navigationController pushViewController:_completionReceiptVC animated:NO];
    }
    
    else if (_jobStatus==JSNeedFeedback)
    {
        LAFeedbackVC *_feedbackVC=[[LAFeedbackVC alloc]init];
        [self.navigationController pushViewController:_feedbackVC animated:NO];
    }
    
    [UIView transitionWithView:appDelegate().window duration:0.25 options:UIViewAnimationOptionTransitionCrossDissolve animations:nil completion:nil];
}


// SHOW PAYMENT POPOVER IN CASE OF PAYPAL
- (void)showPaymentPopover
{
    if (appDelegate().jobDetail.status==JSInActiveJobUnpaid)
    {
        float _price = appDelegate().jobDetail.customerPayablePrice;
        
        [self.navigationController popToRootViewControllerAnimated:NO];
        
        NSString *_titleString=@"Pay For Your Booking";
        NSString *_messageString=[NSString stringWithFormat:@"You have a pending payment. Please pay the amount $%i",(int)_price];
        NSArray *_buttonArray=@[@"Pay Now",@"Cancel Booking"];
        
        if (appDelegate().jobDetail.isDicounted)
        {
            _titleString=@"Congratulation";
            _messageString=[NSString stringWithFormat:@"You are getting $%i discount on your service. Now you have to pay $%i.",(int)appDelegate().jobDetail.discountedValue,(int)appDelegate().jobDetail.customerPayablePrice];
            
            if(appDelegate().jobDetail.isFree)
            {
                _buttonArray=@[@"Activate Job"];
                _titleString=@"Congratulation";
                _messageString=[NSString stringWithFormat:@"This is a free service from LUXit"];
            }
        }
        
        [ccManager() showAlertWithTitle:_titleString message:_messageString buttons:_buttonArray completion:^(NSInteger buttonIndex)
         {
             if ([[_buttonArray objectAtIndex:buttonIndex]isEqualToString:@"Activate Job"])
             {
                 [self markJobAsPaidWithTransactionId:@"Discounted_Value"];
             }
             
             else if ([[_buttonArray objectAtIndex:buttonIndex]isEqualToString:@"Pay Now"])
             {
                 [self makePayment];
             }
             else
             {
                 [self cancelJob];
             }
         }];
    }
}


- (void)makePayment
{
    paypalManager().finishedPayingByPaypal=^(NSString *transactionId,TransactionStatus status)
    {
        if (status==TSCancelled)
        {
            [self showPaymentPopover];
        }
        else
        {
            [self markJobAsPaidWithTransactionId:transactionId];
        }
    };
     [paypalManager() payForJobDetail:appDelegate().jobDetail];
}


- (void)markJobAsPaidWithTransactionId:(NSString *)transactionId
{
    [progressHud() showWithTitle:@"Please wait"];
  
    JobStatus _jobStatus=appDelegate().jobDetail.status;
   
    float _price=0.0;
   
    if (_jobStatus==JSCancelledUnpaid)
    {
        _price=appDelegate().jobDetail.cancellationFees;
    }
    else
    {
        _price=appDelegate().jobDetail.customerPayablePrice;
    }
    
    NSDictionary *_attributes=@{
                                @"jobId":appDelegate().jobDetail.jobId,
                                @"userId":appDelegate().userInfo.userId,
                                @"transactionId":transactionId,
                                @"price":[NSString stringWithFormat:@"%f",_price],
                                @"type":@"1"
                                };
    
    [API() markJobAsPaidWithAttributes:_attributes completion:^(BOOL success, NSError *error)
     {
         if (success)
         {
             NSMutableDictionary *_jobDetail=[NSMutableDictionary dictionaryWithDictionary:[[NSUserDefaults standardUserDefaults]objectForKey:@"LastJobDetail"]];
             [_jobDetail setObject:@"1" forKey:@"isPaid"];
             [_jobDetail setObject:@"11" forKey:@"status"];
             [_jobDetail setObject:@"1" forKey:@"transationType"];
             [_jobDetail setObject:transactionId forKey:@"transactionId"];
             
             [[NSUserDefaults standardUserDefaults]setObject:_jobDetail forKey:@"LastJobDetail"];
             [[NSUserDefaults standardUserDefaults]synchronize];
             
             [appDelegate().jobDetail updateWithAttributes:[[NSUserDefaults standardUserDefaults]objectForKey:@"LastJobDetail"]];
             
             [self ativateJob];
            
             [ccManager() showAlertWithTitle:@"Confirmation" message:@"We received payment." buttons:@[@"Thanks"] completion:nil];
         }
         else
         {
             [progressHud() hide];
            
             [ccManager() showAlertWithTitle:@"Error" message:@"Fail to update payment info.\nPlease retry." buttons:@[@"Retry"] completion:^(NSInteger buttonIndex)
             {
                 [self markJobAsPaidWithTransactionId:transactionId];
             }];
         }
     }];
}


- (void)cancelJob
{
    [progressHud() showWithTitle:@"Please wait"];
    
    NSDictionary *_attributes=@{
                                @"userId":appDelegate().userInfo.userId,
                                @"jobId" :appDelegate().jobDetail.jobId,
                                @"status":@"2",
                                @"comment":@""
                                };
    
    [API() cancelJobWithAttributes:_attributes completion:^(BOOL success,NSError *error,BOOL invalid){
        
        if (success)
        {
            [progressHud() hide];
            
            [appDelegate().jobDetail resetJobDetails];

            [self.menuContainerViewController switchView];
        }
        else
        {
            if (invalid)
            {
                [progressHud() showWithTitle:@"Please wait"];
                
                NSDictionary *_attributes=@{
                                            @"userId":appDelegate().userInfo.userId
                                            };
                [API() fetchLastCreatedJobStatusWithAttributes:_attributes completion:^(BOOL success,NSError *error1)
                 {
                     [progressHud() hide];
                   
                     if (success)
                     {
                         [self.menuContainerViewController switchView];
                     }
                     else
                     {
                         [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
                     }
                 }];
                return;
            }
            
            [progressHud() hide];
          
            [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo] objectForKey:@"description"] buttons:@[@"Retry",@"Cancel"] completion:^(NSInteger buttonIndex)
            {
                if (buttonIndex==0)
                {
                    [self cancelJob];
                }
                else
                {
                    [self showPaymentPopover];
                }
            }];
        }
    }];
}


- (void)ativateJob
{
    [progressHud() showWithTitle:@"Please wait"];
    
    NSDictionary *_attributes=@{
                                @"jobId":appDelegate().jobDetail.jobId,
                                @"status":@"0",
                                };
    [API() activateJobWithAttributes:_attributes completion:^(BOOL success,NSError *error)
    {
        if (success)
        {
            [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"PaypalInfo"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            [progressHud() hide];
          
            NSDateFormatter *_dateFormatter=[[NSDateFormatter alloc]init];
            [_dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
            
            NSMutableDictionary *_jobDetail=[NSMutableDictionary dictionaryWithDictionary:[[NSUserDefaults standardUserDefaults]objectForKey:@"LastJobDetail"]];
            [_jobDetail setObject:@"1" forKey:@"isPaid"];
            [_jobDetail setObject:@"0" forKey:@"status"];
            [_jobDetail setObject:[_dateFormatter stringFromDate:[NSDate date]]  forKey:@"date"];
            
            [[NSUserDefaults standardUserDefaults]setObject:_jobDetail forKey:@"LastJobDetail"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            [appDelegate().jobDetail updateWithAttributes:[[NSUserDefaults standardUserDefaults]objectForKey:@"LastJobDetail"]];

            appDelegate().jobDetail.changed=YES;
          
            [self.menuContainerViewController switchView];
        }
        else
        {
            [progressHud() hide];
          
            [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo] objectForKey:@"description"] buttons:@[@"Retry"] completion:^(NSInteger buttonIndex)
            {
                [self ativateJob];
            }];
        }
    }];
}


@end
