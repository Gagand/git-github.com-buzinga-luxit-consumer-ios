//
//  LAChangePasswordVC.m
//  Luxit
//
//  Created by GP on 24/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "LAChangePasswordVC.h"
#import "Constant.h"
#import "LAParentViewController.h"

@implementation LAChangePasswordVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];

    CGRect _frame=CGRectMake(0.0, 15.0, 190, 50.0);
    NSDictionary *_attributes;
    _attributes=@{
                  kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                  };
    UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
    
    
    _attributes=@{
                  kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                  kASTextColor:COLOR_THEME_BROWN,
                  kASText:@"CHANGE PASSWORD",
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                  };
    [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
    
    self.navigationItem.titleView=_headerLabel;
    
    UITapGestureRecognizer *_tapGesture=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(handlePan)];
    [self.view addGestureRecognizer:_tapGesture];

    
    _attributes=@{
                  kCCImage: [UIImage imageNamed:@"Arrow.png"]
                  };
    UIButton *_cancelButton=[ccManager() buttonWithAttributes:_attributes frame:CGRectMake(0.0, 5.0, 80.0, 50.0) completion:^(UIButton *sender)
                             {
                                 [self.navigationController popViewControllerAnimated:YES];
                             }];
    
    
    UIBarButtonItem *_cancelButtonItem=[[UIBarButtonItem alloc]initWithCustomView:_cancelButton];
    
    UIBarButtonItem *_leftSpaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    _leftSpaceItem.width = -31.0;
    
    self.navigationItem.leftBarButtonItems=[NSArray arrayWithObjects:_leftSpaceItem,_cancelButtonItem, nil];
    
    _frame=CGRectMake(0.0, 0.0,self.view.frame.size.width , 1.0);
    _attributes=@{
                  kCCImage:[UIImage imageNamed:@"seprator.png"]
                  };
    UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
    [self.view addSubview:_divider];
    
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_tableView==nil)
    {
        _tableView=[[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.delegate=self;
        _tableView.dataSource=self;
        _tableView.backgroundColor=[UIColor clearColor];
        _tableView.separatorColor=[UIColor clearColor];
        [self.view addSubview:_tableView];
    }
}


#pragma mark------------------------------------------------------------
#pragma mark TABLEVIEW DELEGATE/ DATESOURCE
#pragma mark------------------------------------------------------------

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0||indexPath.row==3)
    {
        return 60.0;
    }
    else{
        return 44.0;
    }
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=[NSString stringWithFormat:@"Cell_%i",(int)indexPath.row];
    
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
    
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        if (indexPath.row==0)
         {
            
             NSDictionary *_attributes=nil;
            _attributes=@{
                          kCCTextColor: COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:15.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCTag:[NSNumber numberWithInt:(int)indexPath.row],
                          kCCPlaceHolderColor:COLOR_THEME_BROWN,
                          kCCPlaceHolderText:@"Current Password",
                          kCCSecureEntery:@"YES"
                          };
            CGRect _frame=CGRectMake(9.0, 0.0, tableView.frame.size.width-20.0, 45.0);
            _oldPasswordTF=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
            [_cell.contentView addSubview:_oldPasswordTF];
            
             _frame=CGRectMake(0.0, 45.0,tableView.frame.size.width , 1.0);
             _attributes=@{
                           kCCImage:[UIImage imageNamed:@"seprator.png"]
                           };
             UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
             [_cell.contentView addSubview:_divider];
             
            
        }
        
        else if (indexPath.row==1)
        {
            _cell.backgroundColor=[UIColor whiteColor];
            
            NSDictionary *_attributes=nil;
            _attributes=@{
                          kCCBackgroundColor:[UIColor colorWithRed:221.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0]
                          };
            CGRect _frame=CGRectMake(0.0, 43.5, tableView.frame.size.width, 0.55);
            [_cell.contentView addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];
            
            _frame=CGRectMake(0.0, 0.0, tableView.frame.size.width, 0.55);
            [_cell.contentView addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];
            

            _attributes=@{
                          kCCTextColor: COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:15.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCTag:[NSNumber numberWithInt:(int)indexPath.row],
                          kCCPlaceHolderColor:[UIColor colorWithRed:130./255.0 green:130.0/255.0 blue:130.0/255.0 alpha:1.0],
                          kCCPlaceHolderText:@"New Password",
                          kCCSecureEntery:@"YES"
                          };
            _frame=CGRectMake(9.0, 0.0, tableView.frame.size.width-20.0, 44.0);
            _newPasswordTf=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
            [_cell.contentView addSubview:_newPasswordTf];
        }
        
        else if (indexPath.row==2)
        {
           _cell.backgroundColor=[UIColor whiteColor];
            
            NSDictionary *_attributes=nil;
            _attributes=@{
                          kCCBackgroundColor:[UIColor colorWithRed:221.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0]
                          };
            CGRect _frame=CGRectMake(0.0, 43.5, tableView.frame.size.width, 0.55);
            [_cell.contentView addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];

            _attributes=@{
                          kCCTextColor: COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:15.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyGo],
                          kCCTag:[NSNumber numberWithInt:(int)indexPath.row],
                          kCCPlaceHolderColor:[UIColor colorWithRed:130./255.0 green:130.0/255.0 blue:130.0/255.0 alpha:1.0],
                          kCCPlaceHolderText:@"Confirm New Password",
                          kCCSecureEntery:@"YES"
                          };
             _frame=CGRectMake(9.0, 0.0, tableView.frame.size.width-20.0, 44.0);
            _confirmPasswordTF=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
            [_cell.contentView addSubview:_confirmPasswordTF];
            
        }
        
        else
        {
            
            NSDictionary *_attributes=nil;
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_BROWN,
                      COLOR_THEME_LIGHTPINK
                      ];
            CGRect _frame=CGRectMake(16.0, 15.0, self.view.frame.size.width-32.0, 44.0);
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_customLayer];
            
            
            _frame=CGRectMake(_frame.origin.x+1.5, _frame.origin.y+1.5, _frame.size.width-3.0, _frame.size.height-3.0);
            
            _attributes=@{
                          kCCBackgroundColor:COLOR_THEME_DARKGRAY
                          };
            UIButton *_updatePasswordButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender)
            {
                [self validateAndUpdatePassord];
            }];
            
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0],
                          kASText:@"UPDATE PASSWORD",
                          kASCharacterSpace:[NSNumber numberWithFloat:1.35]
                          };
            
            NSMutableAttributedString *_attributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            
            [_updatePasswordButton setAttributedTitle:_attributedString forState:UIControlStateNormal];
            [[_updatePasswordButton titleLabel] setNumberOfLines:0];
            [[_updatePasswordButton titleLabel] setLineBreakMode:NSLineBreakByWordWrapping];
            [_cell.contentView addSubview:_updatePasswordButton];
        }
        
        
    }
    return _cell;
}


#pragma mark------------------------------------------------------------
#pragma mark TEXTFIELD DELEGATE
#pragma mark------------------------------------------------------------

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    _tableView.frame=CGRectMake(0.0, 0.0, self.view.frame.size.width, self.view.frame.size.height-216.0);
    [_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:textField.tag inSection:0] atScrollPosition:UITableViewScrollPositionMiddle animated:NO];
}


-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField==_oldPasswordTF)
    {
        [_newPasswordTf becomeFirstResponder];
    }
    else  if (textField==_newPasswordTf)
    {
        [_confirmPasswordTF becomeFirstResponder];
    }
    else  if (textField==_confirmPasswordTF)
    {
        [self validateAndUpdatePassord];
    }
   
    return YES;
}


- (void)handlePan
{
    [self resetView];
}


- (void)resetView
{
    [_confirmPasswordTF resignFirstResponder];
    [_newPasswordTf resignFirstResponder];
    [_oldPasswordTF resignFirstResponder];
    _tableView.frame=self.view.bounds;
}


- (void)validateAndUpdatePassord
{
    NSString *_oldPassword=[_oldPasswordTF.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *_newPassword=[_newPasswordTf.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *_confirmPassword=[_confirmPasswordTF.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    
    if (_oldPassword.length==0 && _newPassword.length==0 && _confirmPassword.length==0)
    {
        [ccManager() showAlertWithTitle:@"Fill in all the fields" message:@"Please fill in all fields to continue" buttons:nil completion:nil];
        return;
    }
    
    if (_oldPassword.length==0)
    {
        [ccManager() showAlertWithTitle:@"Current Password" message:@"Your Current Password is not correct" buttons:nil completion:nil];
        return;
    }
    
    if (![_newPassword isEqualToString:_confirmPassword])
    {
        [ccManager() showAlertWithTitle:@"Confirm New Password" message:@"New Password does not match the Confirm Password" buttons:nil completion:nil];
        return;
    }
    
    if (![self isValidPassword:_newPassword])
    {
        [ccManager() showAlertWithTitle:@"New Password" message:@"A password is required and needs to be at least 8 characters and include at least one uppercase, one lowercase letter, a number and a symbol (+, #, &, !, @, etc.)" buttons:nil completion:nil];
        return;
    }
    
    [self resetView];
    
    NSDictionary *_attributes=@{
                                @"userId":appDelegate().userInfo.userId,
                                @"oldPassword":_oldPassword,
                                @"newPassword":_newPassword
                                };
    
    [progressHud() showWithTitle:@"Please wait"];
   
    [API() updatePasswordWithAttributes:_attributes completion:^(BOOL success, NSError *error)
     {
         [progressHud() hide];
         if (success)
         {
             [ccManager() showAlertWithTitle:@"Success" message:@"Password changed successfully" buttons:@[@"OK"] completion:^(NSInteger buttonIndex){
                 [self.navigationController popViewControllerAnimated:YES];
             }];
         }
         else
         {
             [ccManager() showAlertWithTitle:[[error userInfo] objectForKey:@"title"] message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
         }
         
     }];


}

-(BOOL)isValidPassword:(NSString *)password
{
    NSString *stricterFilterString = @"^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$";
    NSString *passwordRegex =stricterFilterString;
    NSPredicate *passwordTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", passwordRegex];
    return [passwordTest evaluateWithObject:password];
}
@end
