//
//  LAAppDelegate.h
//  Luxit
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

typedef enum
{
    ASBackground,
    ASForeground
}AppStatus;

#import <UIKit/UIKit.h>
#import <FacebookSDK/FacebookSDK.h>
#import <CoreLocation/CoreLocation.h>

#import "UserInfo.h"
#import "JobDetail.h"
#import "GAI.h"
#import "GAIFields.h"
#import "GAIDictionaryBuilder.h"

@interface LAAppDelegate : UIResponder <UIApplicationDelegate,CLLocationManagerDelegate,UIAlertViewDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UINavigationController *navigationController;
@property (strong, nonatomic) CLLocationManager *locationManager;
@property (strong, nonatomic) UserInfo *userInfo;
@property (strong, nonatomic) JobDetail *jobDetail;
@property (nonatomic, assign) BOOL okToWait;
@property (assign, nonatomic) BOOL locationEnabled;
@property (assign, nonatomic) int locationServiceStatus;
@property (strong, nonatomic) FBSession*session;
@property (nonatomic, copy) void(^receiveRemoteNotification)(NSDictionary *);
@property (nonatomic, copy) void(^updateAppStatus)(AppStatus);
@property (nonatomic, copy) void(^updateLocationAuthorization)(BOOL);
@property(nonatomic, copy)   void (^dispatchHandler)(GAIDispatchResult result);

- (void)showSplashViewController;
- (void)showAppHomeViewController;
- (void)showUserHomeViewController;
- (void)enableLocationService;
- (void)disableLocationService;
- (void)enablePushNotification;
- (void)validateRemoteNotification;


@end

LAAppDelegate *appDelegate(void);