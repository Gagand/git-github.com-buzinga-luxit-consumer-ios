//
//  LAForgotPasswordVC.m
//  Luxit
//
//  Created by GP on 26/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "LAForgotPasswordVC.h"
#import "Constant.h"

@implementation LAForgotPasswordVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_tableView==nil)
    {
        NSDictionary *_attributes=nil;
        _attributes=@{
                      kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                      };
        
        CGRect _frame=CGRectMake(0.0, 15.0, self.view.frame.size.width, 50.0);
        
        UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
        
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                      kASTextColor:COLOR_THEME_BROWN,
                      kASText:@"FORGOT PASSWORD",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                      };
        [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
        
        [self.view addSubview:_headerLabel];
        
        _attributes=@{
                      kCCImage: [UIImage imageNamed:@"Arrow.png"],
                      kCCContentMode:[NSNumber numberWithInt:UIViewContentModeScaleAspectFit]
                      };
        
        [self.view addSubview:[ccManager() imageViewWithAttributes:_attributes frame:CGRectMake(10.0, 15.0, 20.0, 45.0)]];
        
        [self.view addSubview:[ccManager() buttonWithAttributes:nil frame:CGRectMake(0.0, 15.0, 90.0, 45.0) completion:^(UIButton *sender)
        {
            [self.navigationController popViewControllerAnimated:YES];
        }]];
        
        _frame=CGRectMake(0.0, 64.0,self.view.frame.size.width , 1.0);
        _attributes=@{
                      kCCImage:[UIImage imageNamed:@"seprator.png"]
                      };
        UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
        [self.view addSubview:_divider];
        
        _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0.0, 65.0, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];
        _tableView.delegate=self;
        _tableView.dataSource=self;
        _tableView.backgroundColor=[UIColor clearColor];
        _tableView.separatorColor=[UIColor clearColor];
        [self.view addSubview:_tableView];
    }
}


#pragma mark------------------------------------------------------------
#pragma mark UITABLEVIEW DELEGATE/ DATASOURCE
#pragma mark------------------------------------------------------------

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0)
    {
        return 150.0;
    }
    else if (indexPath.row==1)
    {
        return 44.0;
    }
    else
    {
        return 65.0;
    }
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=[NSString stringWithFormat:@"Cell_%i",(int)indexPath.row];
    
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
    
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        if (indexPath.row==0)
        {
            CGFloat _cellHeight=[self tableView:tableView heightForRowAtIndexPath:indexPath];
           
            CGRect _frame=CGRectMake(tableView.frame.size.width/2-10.0, _cellHeight-15.5, 20.0, 0.7);
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_BROWN,
                      COLOR_THEME_LIGHTPINK
                      ];
            
            CustomLayer *_layer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_layer];
            
            NSDictionary *_attributes=nil;
            _attributes=@{
                          kCCTextColor: COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:13.0],
                          kCCText:@"",
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                          };
             _frame=CGRectMake(20.0, _cellHeight-28.0-82.0, self.view.frame.size.width-40, 82.0);
           
            UILabel *_descriptionLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.26],
                          kASLineSpace:[NSNumber numberWithFloat:1.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"It happens.\nRe-enter your details and we'll send you an email with instructions to reset your password.",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:13.0]
                          };
            [_descriptionLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
            
            [_cell.contentView addSubview:_descriptionLabel];
            
        }
        
        else if (indexPath.row==1)
        {
            _cell.backgroundColor=[UIColor whiteColor];

            NSDictionary *_attributes=nil;
            _attributes=@{
                          kCCBackgroundColor:[UIColor colorWithRed:221.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0]
                          };
            CGRect _frame=CGRectMake(0.0, 43.5, tableView.frame.size.width, 0.55);
            [_cell.contentView addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];
            
            _frame=CGRectMake(0.0, 0.0, tableView.frame.size.width, 0.55);
            [_cell.contentView addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];
            
            
            _attributes=@{
                          kCCTextColor: COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:15.0],
                          kCCPlaceHolderColor:[UIColor colorWithRed:130./255.0 green:130.0/255.0 blue:130.0/255.0 alpha:1.0],
                          kCCPlaceHolderText:@"Enter email",
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyGo],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeEmailAddress],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                          };
            _frame=CGRectMake(10.0, 0.0, tableView.frame.size.width-20.0, 44.0);
           
            _emailTF=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
            [_cell.contentView addSubview:_emailTF];
            
        }
        
        else
        {
            NSDictionary *_attributes=nil;
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_BROWN,
                      COLOR_THEME_LIGHTPINK
                      ];
            CGRect _frame=CGRectMake(20.0, 15.0, self.view.frame.size.width-40.0, 44.0);
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_customLayer];
            
            
            _frame=CGRectMake(_frame.origin.x+1.5, _frame.origin.y+1.5, _frame.size.width-3.0, _frame.size.height-3.0);
            
            _attributes=@{
                          kCCBackgroundColor:COLOR_THEME_DARKGRAY
                          };
            UIButton *_sendButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
                [self sendButtonAction];
            }];
            
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0],
                          kASText:@"SEND",
                          kASCharacterSpace:[NSNumber numberWithFloat:1.35]
                          };
            
            NSMutableAttributedString *_attributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            
            [_sendButton setAttributedTitle:_attributedString forState:UIControlStateNormal];
            [[_sendButton titleLabel] setNumberOfLines:0];
            [[_sendButton titleLabel] setLineBreakMode:NSLineBreakByWordWrapping];
            [_cell.contentView addSubview:_sendButton];
        }
    }
    return _cell;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
   [self validateAndSendForgottonPassword];
    return YES;
}


- (void)sendButtonAction
{
    [self validateAndSendForgottonPassword];
}


- (void)validateAndSendForgottonPassword
{
    NSString *_email=[_emailTF.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    
    if (_email.length==0)
    {
         [ccManager() showAlertWithTitle:@"Email" message:@"Your Email is required, it must exist and in a valid email format" buttons:nil completion:nil];
        return;
    }
    
    if (![self isValidEmail:_email])
    {
        [ccManager() showAlertWithTitle:@"Email" message:@"Your Email is required, it must exist and in a valid email format" buttons:nil completion:nil];
        return;
    }
    
    [_emailTF resignFirstResponder];
   
    NSDictionary *_attributes=@{
                                @"email":_email
                                };
    
    [progressHud() showWithTitle:@"Please wait"];
    
    [API() sendPasswordWithAttributes:_attributes completion:^(BOOL success, NSError *error)
     {
         [progressHud() hide];
         if (success)
         {
             [ccManager() showAlertWithTitle:@"Success" message:@"Password sent to your email" buttons:@[@"OK"] completion:^(NSInteger buttonIndex){
                 [self.navigationController popViewControllerAnimated:YES];
             }];
         }
         else
         {
             [ccManager() showAlertWithTitle:[[error userInfo] objectForKey:@"title"] message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
         }
         
     }];
}


-(BOOL)isValidEmail:(NSString *)email
{
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z()<>@!#$%&'*+-/=?^_`{}|~.]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}
@end
