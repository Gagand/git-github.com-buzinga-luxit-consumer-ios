//
//  Location.m
//  Luxit
//
//  Created by GP on 07/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Location.h"

@implementation Location

- (void)updateWithAttributes:(NSDictionary *)attributes
{
    if (attributes.allKeys.count>0)
    {
        _isLocatioAvailable=YES;
        _address=[attributes objectForKey:@"Address"];
        _lat=[[attributes objectForKey:@"Lat"]doubleValue];
        _lng=[[attributes objectForKey:@"Lng"]doubleValue];
       
        _postalCode=@"";
       
        if ([attributes.allKeys containsObject:@"postalCode"])
        {
            _postalCode=[attributes objectForKey:@"postalCode"];
        }
    }
    else
    {
        _postalCode=@"";
        _isLocatioAvailable=NO;
        _address=@"";
        _lat=0.0;
        _lng=0.0;
    }
}


- (void)updatePostalCode:(NSString *)postalCode
{
    NSDictionary *_attribute=@{
                               @"Address":_address,
                               @"Lat":@(_lat),
                               @"Lng":@(_lng),
                               @"postalCode":postalCode
                               };
    _postalCode=postalCode;
    [[NSUserDefaults standardUserDefaults]setObject:_attribute forKey:@"MySelectedLocation"];
}

@end
