//
//  LALoginVC.m
//  Luxit
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "LALoginVC.h"
#import "Constant.h"

@implementation LALoginVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    [progressHud() hide];
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_tableView==nil)
    {
        NSDictionary *_attributes=nil;
        _attributes=@{
                      kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                      };
        
        CGRect _frame=CGRectMake(0.0, 15.0, self.view.frame.size.width, 50.0);
        
        UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
        
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                      kASTextColor:COLOR_THEME_BROWN,
                      kASText:@"LOGIN",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                      };
        [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
        
        [self.view addSubview:_headerLabel];
       
        _attributes=@{
                      kCCImage: [UIImage imageNamed:@"Arrow.png"],
                      kCCContentMode:[NSNumber numberWithInt:UIViewContentModeScaleAspectFit]
                      };
       
        [self.view addSubview:[ccManager() imageViewWithAttributes:_attributes frame:CGRectMake(10.0, 15.0, 20.0, 45.0)]];
        
        [self.view addSubview:[ccManager() buttonWithAttributes:nil frame:CGRectMake(0.0, 15.0, 90.0, 45.0) completion:^(UIButton *sender){
            [self.navigationController popViewControllerAnimated:YES];
        }]];
        
        
        _frame=CGRectMake(0.0, 64.0,self.view.frame.size.width , 1.0);
        _attributes=@{
                      kCCImage:[UIImage imageNamed:@"seprator.png"]
                      };
        UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
        [self.view addSubview:_divider];
        

        _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0.0, 65.0, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];
        _tableView.delegate=self;
        _tableView.dataSource=self;
        _tableView.backgroundColor=[UIColor clearColor];
        _tableView.separatorColor=[UIColor clearColor];
        [self.view addSubview:_tableView];
    }
}


#pragma mark------------------------------------------------------------
#pragma mark UITABLEVIEW DELEGATE/ DATASOURCE
#pragma mark------------------------------------------------------------

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0)
    {
        return 100.0;
    }
    else if (indexPath.row==1||indexPath.row==2)
    {
        return 44.0;
    }
    else if (indexPath.row==3)
    {
        return 65.0;
    }
    else
    {
        return 90.0;
    }
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=[NSString stringWithFormat:@"Cell_%i",(int)indexPath.row];
    
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
    
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        if (indexPath.row==0)
        {
            NSDictionary *_attributes=nil;
            _attributes=@{
                          kCCBackgroundColor:COLOR_THEME_LIGHTBLUE
                          };
            CGRect _frame=CGRectMake(16.0, 14.0, self.view.frame.size.width-32.0, 44.0);
            
            UIButton *_fbButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
                [self signinwithFacebookButtonAction];
            }];
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:1.35],
                          kASTextColor:[UIColor whiteColor],
                          kASText:@"LOG IN WITH FACEBOOK",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0]
                          };
            
            [_fbButton setAttributedTitle:[NSMutableAttributedString attributedStringWithAttributes:_attributes] forState:UIControlStateNormal];
            
            
            [_cell.contentView addSubview:_fbButton];
            
            
            _attributes=@{
                          kCCTextColor: COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0],
                          kCCText:@"OR",
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                          };
            _frame=CGRectMake(0.0, _frame.origin.y+_frame.size.height+10.0, self.view.frame.size.width, 20.0);
            
            [_cell.contentView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
            _frame=CGRectMake(0.0, _frame.origin.y+_frame.size.height-10.0, self.view.frame.size.width/2-20.0, 0.5);
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_BROWN,
                      COLOR_THEME_LIGHTPINK
                      ];
            CustomLayer *_leftDividerLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_leftDividerLayer];
            
            
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_BROWN
                      ];
            _frame=CGRectMake(self.view.frame.size.width/2+20.0, _frame.origin.y, self.view.frame.size.width/2-20.0, 0.5);
            CustomLayer *_rightDividerLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_rightDividerLayer];
            
        }
        
        else if (indexPath.row==1)
        {
            _cell.backgroundColor=[UIColor whiteColor];
    

            NSDictionary *_attributes=nil;
            _attributes=@{
                          kCCBackgroundColor:[UIColor colorWithRed:221.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0]
                          };
            CGRect _frame=CGRectMake(0.0, 43.5, tableView.frame.size.width, 0.55);
            [_cell.contentView addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];
            
            _frame=CGRectMake(0.0, 0.0, tableView.frame.size.width, 0.55);
            [_cell.contentView addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];
            
            
            _attributes=@{
                          kCCTextColor: COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:15.0],
                          kCCPlaceHolderColor:[UIColor colorWithRed:130./255.0 green:130.0/255.0 blue:130.0/255.0 alpha:1.0],
                          kCCPlaceHolderText:@"Enter email",
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeEmailAddress],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                          };
          
             _frame=CGRectMake(10.0, 0.0, tableView.frame.size.width-20.0, 44.0);
           
            _emailTF=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
            [_cell.contentView addSubview:_emailTF];
        }
        
        else if (indexPath.row==2)
        {
            _cell.backgroundColor=[UIColor whiteColor];
 
            NSDictionary *_attributes=nil;
            _attributes=@{
                          kCCBackgroundColor:[UIColor colorWithRed:221.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0]
                          };
            CGRect _frame=CGRectMake(0.0, 43.5, tableView.frame.size.width, 0.55);
            [_cell.contentView addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];
            
 
            _attributes=@{
                          kCCTextColor: COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:15.0],
                          kCCPlaceHolderColor:[UIColor colorWithRed:130./255.0 green:130.0/255.0 blue:130.0/255.0 alpha:1.0],
                          kCCPlaceHolderText:@"Password",
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyGo],
                          kCCSecureEntery:@"YES",
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                          };
            
             _frame=CGRectMake(10.0, 0.0, tableView.frame.size.width-20.0, 44.0);
            
            _passwordTF=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
            [_cell.contentView addSubview:_passwordTF];
            
        }
        
        else if (indexPath.row==3)
        {
            NSDictionary *_attributes=nil;
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_BROWN,
                      COLOR_THEME_LIGHTPINK
                      ];
            CGRect _frame=CGRectMake(20.0, 15.0, self.view.frame.size.width-40.0, 44.0);
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            [_cell.contentView addSubview:_customLayer];
            
            
            _frame=CGRectMake(_frame.origin.x+1.5, _frame.origin.y+1.5, _frame.size.width-3.0, _frame.size.height-3.0);
            
            _attributes=@{
                          kCCBackgroundColor:COLOR_THEME_DARKGRAY
                          };
            UIButton *_loginButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
                [self validateAndLogin];
            }];
            
            _attributes=@{
                          kASTextColor: COLOR_THEME_BROWN,
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0],
                          kASText:@"LOG IN",
                          kASCharacterSpace:[NSNumber numberWithFloat:1.35]
                          };
            
            NSMutableAttributedString *_attributedString=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            
            [_loginButton setAttributedTitle:_attributedString forState:UIControlStateNormal];
            [[_loginButton titleLabel] setNumberOfLines:0];
            [[_loginButton titleLabel] setLineBreakMode:NSLineBreakByWordWrapping];
            [_cell.contentView addSubview:_loginButton];
        }
        
        else if (indexPath.row==4)
        {
            NSDictionary *_attributes=nil;
            _attributes=@{
                          kCCTextColor:COLOR_THEME_BROWN,
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:15.0],
                          kCCText:@"Forgot password?"
                          };
            CGRect _frame=CGRectMake(10.0, 0.0, self.view.frame.size.width-20.0,30.0);
            [_cell.contentView addSubview:[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
                [self forgotPasswordButtonAction];
            }]];
        }
    }
    return _cell;
}


#pragma mark------------------------------------------------------------
#pragma mark TEXTFIELD DELEGATEs
#pragma mark------------------------------------------------------------

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField==_emailTF)
    {
        [_passwordTF becomeFirstResponder];
    }
    else
    {
        [self validateAndLogin];
    }
    return YES;
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONS
#pragma mark------------------------------------------------------------

- (void)forgotPasswordButtonAction
{
    LAForgotPasswordVC *_forgotPasswordVC=[[LAForgotPasswordVC alloc]init];
    [self.navigationController pushViewController:_forgotPasswordVC animated:YES];
}


- (void)validateAndLogin
{
    NSString *_email=[_emailTF.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *_password=[_passwordTF.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    
    if (_email.length==0 && _password.length==0)
    {
        [ccManager() showAlertWithTitle:@"Email and Password" message:@"Email and Password are required to continue" buttons:nil completion:nil];
        return;
    }
    if (_email.length==0 && _password.length!=0)
    {
        [ccManager() showAlertWithTitle:@"Email" message:@"Your email is required and must be in a valid email format" buttons:nil completion:nil];
        return;
    }
    if (_email.length!=0 && _password.length==0)
    {
        [ccManager() showAlertWithTitle:@"Password" message:@"Your password is required and must be valid" buttons:nil completion:nil];
        return;
    }
  
    if (![self isValidEmail:_email])
    {
        [ccManager() showAlertWithTitle:@"Email" message:@"Your email is required and must be in a valid email format" buttons:nil completion:nil];
        return;
    }
    
    [_emailTF resignFirstResponder];
    [_passwordTF resignFirstResponder];
   
    NSString *_deviceToken=[[NSUserDefaults standardUserDefaults]objectForKey:@"deviceToken"];
    
    if (_deviceToken==NULL)
    {
        _deviceToken=@"";
    }
    
    NSDictionary *_attributes=@{
                                @"email":_email,
                                @"password":_password,
                                @"deviceToken":_deviceToken,
                                @"deviceType":@"ios",
                                @"userType":@"0"
                                };
  
    [progressHud() showWithTitle:@"Please wait"];
    
    [API() loginWithAttributes:_attributes completion:^(BOOL success, NSError *error)
     {
         if (success)
         {
             appDelegate().userInfo.isFacebookUser=NO;
             [progressHud() showWithTitle:@"Success\nYou logged in successfully"];
             [self performSelector:@selector(hideProgessHudAfterLogin:) withObject:[NSNumber numberWithBool:success] afterDelay:1.5];
         }
         else
         {
             [progressHud() hide];
             [ccManager() showAlertWithTitle:[[error userInfo] objectForKey:@"title"] message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
         }
     }];
}


-(BOOL)isValidEmail:(NSString *)email
{
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z()<>@!#$%&'*+-/=?^_`{}|~.]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}


- (void)hideProgessHudAfterLogin:(NSNumber *)success
{
    if ([success intValue]==1)
    {
        [appDelegate() showUserHomeViewController];
    }
    else
    {
        [progressHud() hide];
    }
}

- (void)signinwithFacebookButtonAction
{
    [_emailTF resignFirstResponder];
    [_passwordTF resignFirstResponder];
    
    [fbManager() checkFBsession:^(BOOL isValidSession){
        if (isValidSession)
        {
            [progressHud() showWithTitle:@"Please wait"];
            [self fetchFBUserInfo];
        }
        else
        {
            [progressHud() hide];
            [ccManager() showAlertWithTitle:@"Error" message:@"Fail to authorize. Please try again." buttons:nil completion:nil];
        }
    }];
}


- (void)fetchFBUserInfo
{
    [fbManager() getUserInfo:^(NSDictionary *userInfo)
    {
         [self registerWithServerWithUserInfo:userInfo];
     
     }
     failed:^(NSError *error)
     {
         [progressHud() hide];
         [ccManager() showAlertWithTitle:@"Error" message:@"Fail to authorize. Please try again." buttons:nil completion:nil];
    }];
}


- (void)registerWithServerWithUserInfo:(NSDictionary *)userInfo
{
    NSString *_email=@"";
    if ([userInfo.allKeys containsObject:@"email"])
    {
        _email=[userInfo objectForKey:@"email"];
    }
    else
    {
        _email=[NSString stringWithFormat:@"%@@facebook.com",[userInfo objectForKey:@"id"]];
    }
    
    NSString *_deviceToken=[[NSUserDefaults standardUserDefaults]objectForKey:@"deviceToken"];
  
    if (_deviceToken==NULL)
    {
        _deviceToken=@"";
    }
    
    NSDictionary *_attributes=@{
                                @"email":_email,
                                @"password":@"",
                                @"deviceToken":_deviceToken,
                                @"deviceType":@"ios",
                                @"userType":@"1",
                                @"fbid":[userInfo objectForKey:@"id"]
                                };
    
    [progressHud() showWithTitle:@"Please wait"];
    
    [API() signupWithAttributes:_attributes completion:^(BOOL success, NSError *error)
     {
         if (success)
         {
             if (appDelegate().userInfo.mobile.length>0)
             {
                 [progressHud() showWithTitle:@"Success\nYou logged in successfully"];
                 
                 [self performSelector:@selector(hideProgessHudAfterLogin:) withObject:[NSNumber numberWithBool:success] afterDelay:1.5];
             }
             else
             {
                 [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"UserInfo"];
                 [[NSUserDefaults standardUserDefaults]synchronize];
                
                 [appDelegate().userInfo updateWithAttributes:nil];
                
                 [progressHud() hide];
                
                 [ccManager() showAlertWithTitle:@"Account is not created" message:@"This Facebook account has not been linked to LUXit. Please try to Register with Facebook." buttons:nil completion:nil];
             }
         }
         else
         {
             [progressHud() hide];
           
             [ccManager() showAlertWithTitle:[[error userInfo] objectForKey:@"title"] message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
         }
         
     }];
}
@end
