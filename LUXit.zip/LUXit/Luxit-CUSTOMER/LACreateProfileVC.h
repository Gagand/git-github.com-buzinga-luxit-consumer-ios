//
//  LACreateProfileVC.h
//  Luxit
//
//  Created by GP on 27/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomKeyboard.h"
#import "LAAddPaymentTypeVC.h"
#import <AVFoundation/AVFoundation.h>
#import <AssetsLibrary/AssetsLibrary.h>

@interface LACreateProfileVC : UIViewController<UITableViewDataSource,UITableViewDelegate,CustomKeyboardDelegate,UITextFieldDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate, UIPickerViewDataSource, UIPickerViewDelegate>
{
    UITableView             *_tableView;
    UITextField             *_firstNameTF,
                            *_lastNameTF,
                            *_cityTF,
                            *_mobileTF;
    CustomKeyboard          *_customKeyboard;
    UIImageView             *_profileImageView;
    UIImagePickerController *_imagePicker;
    UIActivityIndicatorView *_activityIndicatorView;
    BOOL                    _isImageUpdatingRequired;
    NSMutableArray          *_citiesArray;
    UIPickerView            *_citiesPicker;
    BOOL                    _isCityPickerVisible;
    NSString                *_selectedCity;
    BOOL                    _showErrorCell;
}

@end
