//
//  LASplashVC.h
//  Luxit
//
//  Created by GP on 02/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//


#import <UIKit/UIKit.h>

@interface LASplashVC : UIViewController

@end
