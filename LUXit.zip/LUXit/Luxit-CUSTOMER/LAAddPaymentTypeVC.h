//
//  LAAddPaymentTypeVC.h
//  Luxit
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//
typedef enum {
    PTEdit,
    PTNew
}
PaymentTypeMode;


#import <UIKit/UIKit.h>
#import "CustomKeyboard.h"

@interface LAAddPaymentTypeVC : UIViewController<UITableViewDataSource,UITableViewDelegate,CustomKeyboardDelegate,UITextFieldDelegate>
{
    UITableView     *_tableView;
    UIImageView     *_cardImageView;
    UITextField     *_cardNoTF,*_expiryDateTF,*_cvvTF;
    CustomKeyboard  *_customKeyboard;
    UITextField     *_emailTF;
}

@property (nonatomic, readwrite)PaymentTypeMode typeMode;
@property (nonatomic, copy)void(^finishedAddingCard)();

@end

