//
//  LAHistoryVC.m
//  Luxit
//
//  Created by GP on 24/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "LAHistoryVC.h"
#import "Constant.h"
#import "LAParentViewController.h"

@implementation LAHistoryVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];

    CGRect _frame=CGRectMake(0.0, 15.0, 190, 50.0);
    NSDictionary *_attributes;
    _attributes=@{
                  kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                  };
    UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
    
    
    _attributes=@{
                  kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                  kASTextColor:COLOR_THEME_BROWN,
                  kASText:@"HISTORY",
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                  };
    [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
    
    self.navigationItem.titleView=_headerLabel;
    
    
    _isPickerVisible=NO;
   
    _attributes=@{
                  kCCImage: [UIImage imageNamed:@"Arrow.png"]
                  };
    UIButton *_cancelButton=[ccManager() buttonWithAttributes:_attributes frame:CGRectMake(0.0, 5.0, 80.0, 50.0) completion:^(UIButton *sender){[self.navigationController popViewControllerAnimated:YES];}];
    
    
    UIBarButtonItem *_cancelButtonItem=[[UIBarButtonItem alloc]initWithCustomView:_cancelButton];
    
    UIBarButtonItem *_leftSpaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    _leftSpaceItem.width = -31.0;
    
    self.navigationItem.leftBarButtonItems=[NSArray arrayWithObjects:_leftSpaceItem,_cancelButtonItem, nil];
    
    _frame=CGRectMake(0.0, 0.0,self.view.frame.size.width , 1.0);
    _attributes=@{
                  kCCImage:[UIImage imageNamed:@"seprator.png"]
                  };
    UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
    [self.view addSubview:_divider];
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    if (_tableView==nil)
    {
        _monthsArray=[[NSMutableArray alloc]init];
        [_monthsArray addObject:@"January"];
        [_monthsArray addObject:@"February"];
        [_monthsArray addObject:@"March"];
        [_monthsArray addObject:@"April"];
        [_monthsArray addObject:@"May"];
        [_monthsArray addObject:@"June"];
        [_monthsArray addObject:@"July"];
        [_monthsArray addObject:@"August"];
        [_monthsArray addObject:@"September"];
        [_monthsArray addObject:@"October"];
        [_monthsArray addObject:@"November"];
        [_monthsArray addObject:@"December"];
        
        _yearsArray=[[NSMutableArray alloc]init];
 
        int _minimumYearOffset=2015;
        
        _dateFormatter=[[NSDateFormatter alloc]init];
        [_dateFormatter setDateFormat:@"yyyy"];
        
        int _currentYear=[[_dateFormatter stringFromDate:[NSDate date]]intValue];
        
        for (int _minimumYearValue=_minimumYearOffset;_minimumYearValue<=_currentYear;_minimumYearValue++)
        {
            [_yearsArray addObject:[[NSNumber numberWithInt:_minimumYearValue]stringValue]];
        }
        
        
        _itemsArray=[[NSMutableArray alloc]init];
        
       
        
        UIView *_selectorView=[[UIView alloc]initWithFrame:CGRectMake(0.0, 43.0+80-17.5, self.view.frame.size.width, 37.0)];
        _selectorView.backgroundColor=COLOR_THEME_BROWN;
        [self.view addSubview:_selectorView];
        
        
        
        _pickerView=[[UIPickerView alloc]initWithFrame:CGRectMake(0.0, 43.0, self.view.frame.size.width, 160.0)];
        _pickerView.backgroundColor=[UIColor clearColor];
        _pickerView.delegate=self;
        _pickerView.dataSource=self;
        _pickerView.showsSelectionIndicator=NO;
        _pickerView.clipsToBounds=YES;
        [self.view addSubview:_pickerView];

        CGRect _frame;
        NSDictionary *_attributes;
        _frame=CGRectMake(0.0, 209.5,self.view.frame.size.width , 1.0);
        _attributes=@{
                      kCCImage:[UIImage imageNamed:@"seprator.png"]
                      };
        UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
        [self.view addSubview:_divider];
        
        
        
        _attributes=@{
                      kASTextColor: [UIColor colorWithRed:151.0/255.0 green:143.0/255.0 blue:159.0/255.0 alpha:1.0],
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:13.0],
                      kASText:@"JUMP TO  -",
                      kASCharacterSpace:[NSNumber numberWithFloat:5.2/2.0],
                      kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                      };
        _frame=CGRectMake(16.0, 0.0, self.view.frame.size.width, 43.0);
       
        UILabel *_staticJumpToLabel=[ccManager() labelWithAttributes:nil frame:_frame];
        _staticJumpToLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
        [self.view addSubview:_staticJumpToLabel];
       
  
        _frame=CGRectMake(120.0, 0.0, self.view.frame.size.width-120.0, 43.0);

        _dateLabel=[ccManager() labelWithAttributes:nil frame:_frame];
        [self.view addSubview:_dateLabel];
        
        

        [self.view addSubview:[ccManager() buttonWithAttributes:nil frame:CGRectMake(0.0, 0.0, self.view.frame.size.width, 43.0) completion:^(UIButton *sender){
            [self datePickerViewButtonAction];
        }]];
        
        
       
        _attributes=@{
                      kCCImage: [UIImage imageNamed:@"Chevron.png"]
                      };
        _frame=CGRectMake(self.view.frame.size.width-39.0, 18.0, 12, 6.0);
        _arrowImageView=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
        [self.view addSubview:_arrowImageView];

        _frame=CGRectMake(0.0, 42.5,self.view.frame.size.width , 1.0);
        _attributes=@{
                      kCCImage:[UIImage imageNamed:@"seprator.png"]
                      };
        _divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
        [self.view addSubview:_divider];
        

        
        _isPickerVisible=NO;
        

        
        _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0.0, 43.0, self.view.frame.size.width, self.view.frame.size.height-43.0) style:UITableViewStylePlain];
        _tableView.delegate=self;
        _tableView.dataSource=self;
        _tableView.backgroundColor=[UIColor whiteColor];
        _tableView.separatorColor=[UIColor clearColor];
        _tableView.showsVerticalScrollIndicator=NO;
        [self.view addSubview:_tableView];
        
        UITapGestureRecognizer *_tapGesture=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(handleTap)];
        [self.view addGestureRecognizer:_tapGesture];
        
        _frame=CGRectMake(0, 43.0, self.view.frame.size.width, self.view.frame.size.height-43.0);
        _errorLabel=[ccManager() labelWithAttributes:nil frame:_frame];
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:1.2],
                      kASTextColor:COLOR_THEME_BROWN,
                      kASText:@"No Record\nFound",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0]
                      };
        _errorLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
        [self.view addSubview:_errorLabel];
        
        [self checkAndValidateResults];
    }
}



- (void)checkAndValidateResults
{
    NSString *_monthString=@"";
    NSString *_yearString=@"";
    
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"HistoryInfo"]==NULL)
    {
        _dateFormatter=[[NSDateFormatter alloc]init];
        [_dateFormatter setDateFormat:@"MMMM"];
        _monthString=[_dateFormatter stringFromDate:[NSDate date]];
        
        [_dateFormatter setDateFormat:@"yyyy"];
        _yearString=[_dateFormatter stringFromDate:[NSDate date]];
        
        NSUInteger _monthComponent=[_monthsArray indexOfObject:_monthString];
        NSUInteger _yearComponent=[_yearsArray indexOfObject:_yearString];
        
        [_pickerView selectRow:_monthComponent inComponent:0 animated:NO];
        [_pickerView selectRow:_yearComponent inComponent:1 animated:NO];
        
        [self fetchJobHistoryDataFromServerWithProgressHud:YES];
      
    }
    else
    {
        _monthString=[[[NSUserDefaults standardUserDefaults]objectForKey:@"HistoryInfo"]objectForKey:@"month"];
        _yearString=[[[NSUserDefaults standardUserDefaults]objectForKey:@"HistoryInfo"]objectForKey:@"year"];
        
        NSData *_itemsData = [[[NSUserDefaults standardUserDefaults]objectForKey:@"HistoryInfo"]objectForKey:@"items"];
        NSArray *_savedArray = [NSKeyedUnarchiver unarchiveObjectWithData:_itemsData];

        [_itemsArray removeAllObjects];
      
        for (NSDictionary *_jobInfoDictionary in _savedArray)
        {
            [_itemsArray addObject:[[Job alloc]initWithAttributes:_jobInfoDictionary]];
        }
        
        [_itemsArray sortUsingComparator:^NSComparisonResult(Job *obj1, Job *obj2){
            return [obj2.date compare:obj1.date];
        }];
        
        
        NSUInteger _monthComponent=[_monthsArray indexOfObject:_monthString];
        NSUInteger _yearComponent=[_yearsArray indexOfObject:_yearString];
        
        [_pickerView selectRow:_monthComponent inComponent:0 animated:NO];
        [_pickerView selectRow:_yearComponent inComponent:1 animated:NO];
        
        if (_itemsArray.count>0)
        {
            [_errorLabel setHidden:YES];
        }
        else
        {
            [_errorLabel setHidden:NO];
        }
        [_tableView reloadData];
        
        [self fetchJobHistoryDataFromServerWithProgressHud:NO];
    }
    
    _lastSavedMonthString=_monthString;
    _lastSavedYearString=_yearString;
    
    [self setDateLabelWithYear:_yearString month:_monthString];
}


- (void)fetchJobHistoryDataFromServerWithProgressHud:(BOOL)isProgressHud
{
    if (isProgressHud)
    {
        [progressHud() showWithTitle:@"Please wait"];
    }
    
    NSString *_monthString=[_monthsArray objectAtIndex:[_pickerView selectedRowInComponent:0]];
    NSString *_yearString=[_yearsArray objectAtIndex:[_pickerView selectedRowInComponent:1]];
    
    NSDictionary *_attributes=nil;
    _attributes=@{
                  @"userId": appDelegate().userInfo.userId,
                  @"month":[[NSNumber numberWithInt:(int)[_pickerView selectedRowInComponent:0]+1] stringValue],
                  @"year":_yearString
                  };
    [API() fetchJobHistoryForJobWithAttributes:_attributes completion:^(BOOL success, NSError *error, NSMutableArray *items){
        [progressHud() hide];
        if (success)
        {
            NSData *_dataSave = [NSKeyedArchiver archivedDataWithRootObject:items];
            
            NSMutableDictionary *_dictionary=[NSMutableDictionary dictionaryWithCapacity:3];
            [_dictionary setObject:_monthString forKey:@"month"];
            [_dictionary setObject:_yearString forKey:@"year"];
            [_dictionary setObject:_dataSave forKey:@"items"];
            [[NSUserDefaults standardUserDefaults]setObject:_dictionary forKey:@"HistoryInfo"];
            [[NSUserDefaults standardUserDefaults]synchronize];
            
            [_itemsArray removeAllObjects];
            
            for (NSDictionary *_jobInfoDictionary in items)
            {
                [_itemsArray addObject:[[Job alloc]initWithAttributes:_jobInfoDictionary]];
            }
          
            [_itemsArray sortUsingComparator:^NSComparisonResult(Job *obj1, Job *obj2){
                return [obj2.date compare:obj1.date];
            }];
            
            if (_itemsArray.count>0)
            {
                [_errorLabel setHidden:YES];
            }
            else
            {
                [_errorLabel setHidden:NO];
            }
            [_tableView reloadData];
        }
        else
        {
            if(isProgressHud)
            {
                [ccManager() showAlertWithTitle:[[error userInfo]objectForKey:@"title"] message:[[error userInfo]objectForKey:@"description"] buttons:nil completion:nil];
            }
        }
    }];
}


- (void)setDateLabelWithYear:(NSString *)year month:(NSString *)month
{
    NSDictionary *_attributes=nil;
    _attributes=@{
                  kASTextColor: [UIColor colorWithRed:151.0/255.0 green:143.0/255.0 blue:159.0/255.0 alpha:1.0],
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:13.0],
                  kASText:[NSString stringWithFormat:@"%@ %@",month,year],
                  kASCharacterSpace:[NSNumber numberWithFloat:5.2/2.0],
                  kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                  };
    _dateLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
}


- (void)closePickerAndUpdateViewWithNewData
{
    NSString *_monthString=[_monthsArray objectAtIndex:[_pickerView selectedRowInComponent:0]];
    NSString *_yearString=[_yearsArray objectAtIndex:[_pickerView selectedRowInComponent:1]];
    
    _dateFormatter=[[NSDateFormatter alloc]init];
    [_dateFormatter setDateFormat:@"MMMM"];
    NSString *_currentMonthString=[_dateFormatter stringFromDate:[NSDate date]];
    
    [_dateFormatter setDateFormat:@"yyyy"];
    NSString *_currentYearString=[_dateFormatter stringFromDate:[NSDate date]];
    
    NSUInteger _cMonthComponent=[_monthsArray indexOfObject:_currentMonthString];
    
    
    if (_cMonthComponent<[_pickerView selectedRowInComponent:0] && [_yearString integerValue]==[_currentYearString integerValue])
    {
        NSUInteger _monthComponent=[_monthsArray indexOfObject:_lastSavedMonthString];
        NSUInteger _yearComponent=[_yearsArray indexOfObject:_lastSavedYearString];
        
        [_pickerView selectRow:_monthComponent inComponent:0 animated:YES];
        [_pickerView selectRow:_yearComponent inComponent:1 animated:YES];
        [self setDateLabelWithYear:_lastSavedYearString month:_lastSavedMonthString];
        return;
    }

    if ([_lastSavedMonthString isEqualToString:_monthString] && [_lastSavedYearString isEqualToString:_yearString])
    {
        return;
    }
    _lastSavedYearString=_yearString;
    _lastSavedMonthString=_monthString;
    
     [self fetchJobHistoryDataFromServerWithProgressHud:YES];
}


- (void)handleTap
{
    if (_isPickerVisible)
    {
        _isPickerVisible=NO;
        
        [UIView beginAnimations:nil context:nil];
        _arrowImageView.transform=CGAffineTransformMakeRotation(DEGREES_IN_RADIANS(0));
        _tableView.frame=CGRectMake(0.0, 43.0, self.view.frame.size.width, self.view.frame.size.height-43.0);
        _errorLabel.frame=CGRectMake(0.0, 43.0, self.view.frame.size.width, self.view.frame.size.height-43.0);
        [UIView commitAnimations];
        
        [self closePickerAndUpdateViewWithNewData];
    }
}


#pragma mark------------------------------------------------------------
#pragma mark TABLEVIEW DELEGATE/ DATASOURCE
#pragma mark------------------------------------------------------------

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return _itemsArray.count;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 132.5;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=@"Cell";
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
      

        NSDictionary *_attributes=nil;

        CGRect _frame=CGRectMake(16.0, 17.5, tableView.frame.size.width-120.0, 15.0);
        UILabel *_nameLabel=[ccManager() labelWithAttributes:nil frame:_frame];
        _nameLabel.tag=1001;
        [_cell.contentView addSubview:_nameLabel];
        
       
        _frame=CGRectMake(16.0, _frame.size.height+_frame.origin.y+17.5, 24.0, 0.5);
        NSArray *_colors=nil;
        _colors=@[
                  [UIColor colorWithRed:175.0/255.0 green:131.0/255.0 blue:84.0/255.0 alpha:1.0],
                  [UIColor colorWithRed:247/255.0 green:217/255.0 blue:184.0/255.0 alpha:1.0]
                  ];
        
        CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
        _customLayer.alpha=0.8;
        [_cell.contentView addSubview:_customLayer];
        
        
        _attributes=@{
                      kCCTag:[NSNumber numberWithInt:1002],
                      kCCTextColor:COLOR_THEME_BROWN,
                      kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0]
                      };
         _frame=CGRectMake(15.0, _frame.origin.y+_frame.size.height+13.0, tableView.frame.size.width-120.0, 15.0);
        [_cell.contentView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
        
        
        _attributes=@{
                      kCCTag:[NSNumber numberWithInt:1003],
                      kCCTextColor:COLOR_THEME_BROWN,
                      kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0]
                      };
        _frame=CGRectMake(15.0, _frame.origin.y+20.0, tableView.frame.size.width-120.0, 15.0);
        [_cell.contentView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
        
        _attributes=@{
                      kCCTag:[NSNumber numberWithInt:1004],
                      kCCTextColor:COLOR_THEME_BROWN,
                      kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0]
                      };
        _frame=CGRectMake(15.0, _frame.origin.y+20.0, tableView.frame.size.width-120.0, 20.0);
        [_cell.contentView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
        
        
         _frame=CGRectMake(tableView.frame.size.width-101.0, 23.5, 85.0, 85.0);
        _attributes=@{
                      kCCImage: [UIImage imageNamed:@"Cost_Frame.png"]
                      };
        [_cell.contentView addSubview:[ccManager() imageViewWithAttributes:_attributes frame:_frame]];
        
        _attributes=@{
                      kCCTag:[NSNumber numberWithInt:1005],
                      kCCTextColor:COLOR_THEME_BROWN,
                      kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:16.0],
                      kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                      };
       
        [_cell.contentView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
        
    }
   
    Job *_job=(Job *)[_itemsArray objectAtIndex:indexPath.section];
   
    UILabel *_technicianNameLabel=(UILabel *)[_cell viewWithTag:1001];
   
    NSDictionary *_attributes=nil;
    _attributes=@{
                  kASTextColor: COLOR_THEME_BROWN,
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:14.0],
                  kASText:[_job.technician.firstName uppercaseString],
                  kASCharacterSpace:[NSNumber numberWithFloat:7.0/2.0],
                  kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                  };
    _technicianNameLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
   
    UILabel *_itemNameLabel=(UILabel *)[_cell viewWithTag:1002];
    _itemNameLabel.text=_job.itemName;
    
    UILabel *_timeLabel=(UILabel *)[_cell viewWithTag:1003];
    _timeLabel.text=_job.timeString;
    
    UILabel *_locationLabel=(UILabel *)[_cell viewWithTag:1004];
    _locationLabel.text=_job.location;
    
    UILabel *_priceLabel=(UILabel *)[_cell viewWithTag:1005];
    _priceLabel.text=[NSString stringWithFormat:@"$%i",[_job.itemPrice intValue]];
    
    return _cell;
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 22.5;
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *_headerView=[[UIView alloc]initWithFrame:CGRectMake(0.0, 0.0, tableView.frame.size.width, 22.5)];
    _headerView.backgroundColor=COLOR_THEME_DARKGRAY;
   
    Job *_job=(Job *)[_itemsArray objectAtIndex:section];
  
    NSDictionary *_attributes=nil;
    _attributes=@{
                  kASTextColor: [UIColor whiteColor],
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0],
                  kASText:_job.dateString,
                  kASCharacterSpace:[NSNumber numberWithFloat:2.4/2.0],
                  kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                  };
    
    
    CGRect _frame=CGRectMake(15.0, 0.0, tableView.frame.size.width-30.0, _headerView.frame.size.height);
    UILabel *_headerDateLabel=[ccManager() labelWithAttributes:nil frame:_frame];
    _headerDateLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
    [_headerView addSubview:_headerDateLabel];
    
   
    _attributes=@{
                  kASTextColor: [UIColor whiteColor],
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0],
                  kASText:[_job.statusString uppercaseString],
                  kASCharacterSpace:[NSNumber numberWithFloat:2.4/2.0],
                  kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                  };
    UILabel *_headerStatusLabel=[ccManager() labelWithAttributes:nil frame:_frame];
    _headerStatusLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
    [_headerView addSubview:_headerStatusLabel];
  
    
    return _headerView;
}


#pragma mark------------------------------------------------------------
#pragma mark PICKERVIEW DELEGATE/ DATASOURCE
#pragma mark------------------------------------------------------------

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 2;
}


-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (component==0)
    {
        return _monthsArray.count;
    }
    else
    {
        return _yearsArray.count;
    }
}


-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
     if (component==0)
         return [_monthsArray objectAtIndex:row];
    else
        return [_yearsArray objectAtIndex:row];

}


-(CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component
{
    if (component==0)
    {
        return self.view.frame.size.width/2.0-30.0;
    }
    else{
        return self.view.frame.size.width/2.0+30.0;
    }
    
}


-(CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
    return 35.0;
}


-(UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view
{
    if (view==nil)
    {
        float _width=0.0;
        if (component==0)
        {
           _width= self.view.frame.size.width/2.0-30.0;
        }
        else{
           _width= self.view.frame.size.width/2.0+30.0;
        }
        view=[[UIView alloc]initWithFrame:CGRectMake(0.0, 0.0, _width, 35.0)];
        
        NSDictionary *_attributes=nil;
        _attributes=@{
                      kCCTextColor: [UIColor blackColor],
                      kCCTag:[NSNumber numberWithInt:100],
                      kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:15.0]
                      };
        [view addSubview:[ccManager() labelWithAttributes:_attributes frame:view.bounds]];
    }
    
    UILabel *_label=(UILabel *)[view viewWithTag:100];
    if (component==0)
    {
        _label.textAlignment=NSTextAlignmentRight;
        _label.text=[[_monthsArray objectAtIndex:row]uppercaseString];
    }
    else
    {
        _label.textAlignment=NSTextAlignmentCenter;
        _label.text=[_yearsArray objectAtIndex:row];
    }
    
    _label.textColor=[UIColor blackColor];
    if([_pickerView selectedRowInComponent:component] == row)
    {
        _label.textColor =[UIColor whiteColor];
    }
    
    return view;
}


- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    NSString *_monthString=[_monthsArray objectAtIndex:[pickerView selectedRowInComponent:0]];
    NSString *_yearString=[_yearsArray objectAtIndex:[pickerView selectedRowInComponent:1]];
    
    [self setDateLabelWithYear:_yearString month:_monthString];
    [self validateDate];
    [_pickerView reloadAllComponents];
}


- (void)validateDate
{
    NSString *_yearString=[_yearsArray objectAtIndex:[_pickerView selectedRowInComponent:1]];
    
    _dateFormatter=[[NSDateFormatter alloc]init];
    [_dateFormatter setDateFormat:@"MMMM"];
    NSString *_currentMonthString=[_dateFormatter stringFromDate:[NSDate date]];
    
    [_dateFormatter setDateFormat:@"yyyy"];
    NSString *_currentYearString=[_dateFormatter stringFromDate:[NSDate date]];
    
    NSUInteger _cMonthComponent=[_monthsArray indexOfObject:_currentMonthString];
    
    
    if (_cMonthComponent<[_pickerView selectedRowInComponent:0] && [_yearString integerValue]==[_currentYearString integerValue])
    {
        NSUInteger _monthComponent=[_monthsArray indexOfObject:_lastSavedMonthString];
        NSUInteger _yearComponent=[_yearsArray indexOfObject:_lastSavedYearString];
        
        [_pickerView selectRow:_monthComponent inComponent:0 animated:YES];
        [_pickerView selectRow:_yearComponent inComponent:1 animated:YES];
        [self setDateLabelWithYear:_lastSavedYearString month:_lastSavedMonthString];
    }
    
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONS
#pragma mark------------------------------------------------------------

- (void)datePickerViewButtonAction
{
    if (_isPickerVisible)
    {
         _isPickerVisible=NO;
        
        [UIView beginAnimations:nil context:nil];
        _arrowImageView.transform=CGAffineTransformMakeRotation(DEGREES_IN_RADIANS(0));
        _tableView.frame=CGRectMake(0.0, 43.0, self.view.frame.size.width, self.view.frame.size.height-43.0);
        _errorLabel.frame=CGRectMake(0.0, 43.0, self.view.frame.size.width, self.view.frame.size.height-43.0);
        [UIView commitAnimations];
        
        [self closePickerAndUpdateViewWithNewData];
        
        
    }
    else
    {
        _isPickerVisible=YES;
        
        [UIView beginAnimations:nil context:nil];
         _arrowImageView.transform=CGAffineTransformMakeRotation(DEGREES_IN_RADIANS(180));
        _tableView.frame=CGRectMake(0.0, 210.0, self.view.frame.size.width, self.view.frame.size.height-210.0);
        _errorLabel.frame=CGRectMake(0.0, 210.0, self.view.frame.size.width, self.view.frame.size.height-210.0);
        [UIView commitAnimations];
    }
}
@end
