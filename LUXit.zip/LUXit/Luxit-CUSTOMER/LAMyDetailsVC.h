//
//  LAMyDetailsVC.h
//  Luxit
//
//  Created by GP on 24/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LAHistoryVC.h"
#import "LAChangePasswordVC.h"
#import "LAPaymentMethodsVC.h"

@interface LAMyDetailsVC : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    UITableView             *_tableView;
}

@end
