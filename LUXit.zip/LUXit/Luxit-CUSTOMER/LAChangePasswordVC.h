//
//  LAChangePasswordVC.h
//  Luxit
//
//  Created by GP on 24/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LAChangePasswordVC : UIViewController<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>
{
    UITextField             *_oldPasswordTF,*_newPasswordTf,*_confirmPasswordTF;
    UITableView             *_tableView;
}


@end
