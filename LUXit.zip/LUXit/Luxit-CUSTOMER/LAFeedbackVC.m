//
//  LAFeedbackVC.m
//  Luxit
//
//  Created by GP on 27/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "LAFeedbackVC.h"
#import "LAUserHomeVC.h"
#import "LAParentViewController.h"
#import "Constant.h"

@implementation LAFeedbackVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
     [progressHud() hide];
   
    [self.menuContainerViewController disablePan];
   
    self.view.backgroundColor=[UIColor whiteColor];
    
    self.navigationItem.hidesBackButton=YES;
    

    CGRect _frame=CGRectMake(0.0, 15.0, 160, 50.0);
    NSDictionary *_attributes;
    _attributes=@{
                  kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                  };
    UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
    
    
    _attributes=@{
                  kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                  kASTextColor:COLOR_THEME_BROWN,
                  kASText:@"FEEDBACK",
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                  };
    [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
    
    self.navigationItem.titleView=_headerLabel;
    
    _attributes=@{kCCBackgroundColor: [UIColor colorWithWhite:0.0 alpha:0.2]};
    
    _frame=CGRectMake(0.0, 0.0, self.view.frame.size.width, 0.5);
    
    [self.view addSubview:[ccManager() viewWithAttributes:_attributes frame:_frame]];

    
    _attributes=@{
                  kASTextColor: COLOR_THEME_BROWN,
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0],
                  kASText:@"Send",
                  kASCharacterSpace:[NSNumber numberWithFloat:1.2],
                  kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                  };
    _frame=CGRectMake(0.0, 0.0, 80.0, 50.0);
    UIButton *_sendButton=[ccManager() buttonWithAttributes:nil frame:_frame completion:^(UIButton *sender){
        [self sendButtonAction];
    }];
    [_sendButton setAttributedTitle:[NSMutableAttributedString attributedStringWithAttributes:_attributes] forState:UIControlStateNormal];
    
    UIBarButtonItem *_sendButtonItem=[[UIBarButtonItem alloc]initWithCustomView:_sendButton];
    UIBarButtonItem *_leftSpaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    _leftSpaceItem.width = -24.0;
    self.navigationItem.rightBarButtonItems=[NSArray arrayWithObjects:_leftSpaceItem,_sendButtonItem, nil];
    
    _frame=CGRectMake(0.0, 0.0,self.view.frame.size.width , 1.0);
    _attributes=@{
                  kCCImage:[UIImage imageNamed:@"seprator.png"]
                  };
    UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
    [self.view addSubview:_divider];
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_commentTextView==nil)
    {
         NSDictionary *_attributes=nil;
        
        _attributes=@{
                      kASTextColor: COLOR_THEME_BROWN,
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:13.0],
                      kASText:@"At LUXit, we take all of our customers' experiences seriously. By providing feedback on why this technician has received a poor review, it will allow us to improve our service to you and all other customers.",
                      kASCharacterSpace:[NSNumber numberWithFloat:0.52/2.0]
                      };
        
         CGRect _frame=CGRectMake(16.0, 19.0, self.view.frame.size.width-32, 90.0);
        
        UILabel *_staticInfoLabel=[ccManager() labelWithAttributes:nil frame:_frame];
        _staticInfoLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
        [self.view addSubview:_staticInfoLabel];
 
        _frame=CGRectMake(self.view.frame.size.width/2-12.0, _frame.origin.y+_frame.size.height+36.0, 24, 0.5);
       
        NSArray *_colors=nil;
        _colors=@[
                  COLOR_THEME_LIGHTPINK,
                  COLOR_THEME_LIGHTPINK
                  ];
        
        CustomLayer*_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMVertical];
        [self.view addSubview:_customLayer];
        
        _attributes=@{
                      kCCText:@"Type your comments here",
                      kCCTextColor:[UIColor colorWithRed:220.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0],
                      kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:15.0]
                      };
      
        CGRect _placeHolderFrame=CGRectMake(21.0, _frame.origin.y+_frame.size.height+20.0, self.view.frame.size.width-42.0, 34.0);
      
        _placeHolderLabel=[ccManager() labelWithAttributes:_attributes frame:_placeHolderFrame];
        
        [self.view addSubview:_placeHolderLabel];
        
        _frame=CGRectMake(17.0, _frame.origin.y+_frame.size.height+20.0, self.view.frame.size.width-34.0, self.view.frame.size.height-(_frame.origin.y+_frame.size.height)-236.0);
        
        _attributes=@{
                      kCCTextColor:COLOR_THEME_BROWN,
                      kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:15.0],
                      kCCReturnKey:[NSNumber numberWithInt:UIReturnKeySend]
                      };
        _commentTextView=[ccManager() textViewWithAttributes:_attributes frame:_frame target:self completion:nil];
        [self.view addSubview:_commentTextView];
        [_commentTextView becomeFirstResponder];
        
    }
}


#pragma mark------------------------------------------------------------
#pragma mark TEXTVIEW DELEGATE
#pragma mark------------------------------------------------------------

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    [self performSelector:@selector(checkPlaceHolder) withObject:nil afterDelay:0.01];
    
    if ([text isEqualToString:@"\n"])
    {
        [self sendFeedback];
       
        return NO;
    }
    return YES;
}

- (void)checkPlaceHolder
{
    if (_commentTextView.text.length>0)
    {
        [_placeHolderLabel setHidden:YES];
    }
    else
    {
        [_placeHolderLabel setHidden:NO];
    }
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONS
#pragma mark------------------------------------------------------------

- (void)sendButtonAction
{
    [self sendFeedback];
}


- (void)sendFeedback
{
    NSString *_commentString=[_commentTextView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    
    if (_commentString.length==0)
    {
        [ccManager() showAlertWithTitle:@"Info" message:@"Please add your comments" buttons:nil completion:nil];
        return;
    }
    
    [progressHud() showWithTitle:@"Please wait"];
    
    NSDictionary *_attributes=@{
                                @"userId":appDelegate().userInfo.userId,
                                @"jobId":appDelegate().jobDetail.jobId,
                                @"comment":_commentString
                                };
    
    [API() sendFeedbackForJobWithAttributes:_attributes completion:^(BOOL success,NSError *error){
        [progressHud() hide];
        if (success)
        {
            [appDelegate().jobDetail resetJobDetails];
           
            [self.menuContainerViewController switchView];
        }
        else
        {
            [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
        }
    }];
}
@end
