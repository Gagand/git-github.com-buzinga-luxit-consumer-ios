//
//  TechnicianInfo.m
//  Luxit
//
//  Created by GP on 28/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "TechnicianInfo.h"

@implementation TechnicianInfo

- (void)updateWithAttributes:(NSDictionary *)attributes
{
    _name=@"";
    _mobile=@"";
    _imagePath=@"";
    _rating=0;
    _firstName=@"";
    _lastName=@"";
   
    if ([attributes.allKeys containsObject:@"name"] && (NSNull *)[attributes objectForKey:@"name"]!=[NSNull null])
    {
        _name=[attributes objectForKey:@"name"];
    }
    
    if ([attributes.allKeys containsObject:@"mobileNo"] && (NSNull *)[attributes objectForKey:@"mobileNo"]!=[NSNull null] )
    {
        _mobile=[attributes objectForKey:@"mobileNo"];
    }
    
    if ([attributes.allKeys containsObject:@"image"] && (NSNull *)[attributes objectForKey:@"image"]!=[NSNull null])
    {
        _imagePath=[attributes objectForKey:@"image"];
    }
    
    if ([attributes.allKeys containsObject:@"first_name"] && (NSNull *)[attributes objectForKey:@"first_name"]!=[NSNull null])
    {
        _firstName=[attributes objectForKey:@"first_name"];
    }
    
    if ([attributes.allKeys containsObject:@"last_name"] && (NSNull *)[attributes objectForKey:@"last_name"]!=[NSNull null])
    {
        _lastName=[attributes objectForKey:@"last_name"];
    }

    
    if ([attributes.allKeys containsObject:@"rating"] && (NSNull *)[attributes objectForKey:@"rating"]!=[NSNull null])
    {
        _rating=[[attributes objectForKey:@"rating"]intValue]/2;
    }
}

@end
