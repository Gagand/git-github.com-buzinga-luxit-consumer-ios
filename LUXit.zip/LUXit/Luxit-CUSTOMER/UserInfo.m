//
//  UserInfo.m
//  Luxit
//
//  Created by GP on 28/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "UserInfo.h"

@implementation UserInfo

- (id)init
{
    self=[super init];
    if (self)
    {
        _location=[[Location alloc]init];
        _paymentMode=[[PaymentMode alloc]init];
    }
    return self;
}


- (void)updateWithAttributes:(NSDictionary *)attributes
{
    if (attributes.allKeys.count>0)
    {
        _isUserAvailable=YES;
       
        _firstName=[[attributes objectForKey:@"first_name"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
       
        _lastName=[[attributes objectForKey:@"last_name"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    
        _email=[[attributes objectForKey:@"email"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
       
        if ([attributes.allKeys containsObject:@"id"])
        {
             _userId=[[attributes objectForKey:@"id"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        }
        else
        {
            _userId=[[attributes objectForKey:@"user_id"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        }
       
        _fbId=@"";
        if ([attributes.allKeys containsObject:@"fbid"]) {
        
            _fbId=[[attributes objectForKey:@"fbid"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        }
        
       _mobile=[[attributes objectForKey:@"mobile"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        
        if (_fbId.length>0)
        {
            _isFacebookUser=YES;
        }
        else
        {
            _isFacebookUser=NO;
            _imagePath=[[attributes objectForKey:@"image"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        }
        
        if ([attributes.allKeys containsObject:@"paymentInfo"])
        {
            [_paymentMode updateWithAttributes:[attributes objectForKey:@"paymentInfo"]];
        }
        else
        {
            _paymentMode.isPaymentModeAvailable=NO;
        }
    }
    else
    {
        [[UIApplication sharedApplication] unregisterForRemoteNotifications];
        _isUserAvailable=NO;
        [self updatePaymentMethodWithAttributes:nil];
    }
    
}


- (void)updateLocationWithAttributes:(NSDictionary *)attributes
{
    [_location updateWithAttributes:attributes];
}


- (void)updatePaymentMethodWithAttributes:(NSDictionary *)attributes
{
    [_paymentMode updateWithAttributes:attributes];
}


- (void)reset
{
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"UserInfo"];
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"MySelectedLocation"];
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"LastJobDetail"];
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"HistoryInfo"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    [self updateWithAttributes:nil];
}


@end
