//
//  PaymentMode.h
//  Luxit
//
//  Created by GP on 28/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

typedef enum
{
    PTPaypal,
    PTCreditCard
}
PaymentType;

#import <Foundation/Foundation.h>

@interface PaymentMode : NSObject

@property (nonatomic, assign) BOOL isPaymentModeAvailable;
@property (nonatomic, readwrite) PaymentType type;
@property (nonatomic, retain) NSString *cardNumber;
@property (nonatomic, retain) NSString *email;

- (void)updateWithAttributes:(NSDictionary *)attributes;

@end
