//
//  UserInfo.h
//  Luxit
//
//  Created by GP on 28/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PaymentMode.h"
#import "Location.h"

@interface UserInfo : NSObject

@property (nonatomic, retain) NSString *firstName;
@property (nonatomic, retain) NSString *lastName;
@property (nonatomic, retain) NSString *email;
@property (nonatomic, retain) NSString *userId;
@property (nonatomic, retain) NSString *mobile;
@property (nonatomic, retain) NSString *fbId;
@property (nonatomic, retain) NSString *imagePath;
@property (nonatomic, retain) PaymentMode *paymentMode;
@property (nonatomic, retain) Location *location;
@property (nonatomic, assign) BOOL isUserAvailable;
@property (nonatomic, assign) BOOL isFacebookUser;

- (void)updateWithAttributes:(NSDictionary *)attributes;
- (void)updateLocationWithAttributes:(NSDictionary *)attributes;
- (void)updatePaymentMethodWithAttributes:(NSDictionary *)attributes;
- (void)reset;

@end
