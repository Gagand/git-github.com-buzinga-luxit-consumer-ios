//
//  MenuItem.m
//  LUXit
//
//  Created by GP on 08/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "MenuItem.h"

@implementation MenuItem

- (id)initWithAttributes:(NSDictionary *)attributes
{
    self=[super init];
    
    if (self)
    {
        _ID=[attributes objectForKey:@"id"];
        _name=[attributes objectForKey:@"name"];
        _amount=[[attributes objectForKey:@"amount"]doubleValue];
        
        if( [_name caseInsensitiveCompare:@"Spray Tanning"] == NSOrderedSame )
        {
            _name=@"Spray\nTanning";
        }

        
        else if ([_name caseInsensitiveCompare:@"Make Up"]== NSOrderedSame)
        {
            _name=@"MAKE\nUP";
        }
        
        else if ([_name caseInsensitiveCompare:@"Make up & blow dry"]== NSOrderedSame)
        {
            _name=@"MAKE UP &\nBLOW DRY";
        }
        else if ([_name caseInsensitiveCompare:@"Blow Dry"]== NSOrderedSame)
        {
            _name=@"BLOW\nDRY";
        }
        
    }
    return self;
}
@end
