//
//  MenuItem.h
//  LUXit
//
//  Created by GP on 08/09/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MenuItem : NSObject
@property (nonatomic, retain) NSString *ID;
@property (nonatomic, retain) NSString *name;
@property (nonatomic, assign) double amount;

- (id)initWithAttributes:(NSDictionary *)attributes;

@end
