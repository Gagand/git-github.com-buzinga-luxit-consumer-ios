//
//  LACreateProfileVC.m
//  Luxit
//
//  Created by GP on 27/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "LACreateProfileVC.h"
#import "Constant.h"

@implementation LACreateProfileVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];
    
    [progressHud() hide];
    
    _isCityPickerVisible = NO;
    
    appDelegate().updateAppStatus=^(AppStatus status)
    {
        if (status==ASBackground)
        {
            [self resetView];
        }
    };
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_tableView==nil)
    {
        CGFloat _displacementFactor=0.0;
       
        if (self.navigationController.navigationBarHidden)
        {
            _displacementFactor=65.0;
            
            NSDictionary *_attributes=nil;
          
            _attributes=@{
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                          };
            
            CGRect _frame=CGRectMake(0.0, 15.0, self.view.frame.size.width, 50.0);
            
            UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"CREATE PROFILE",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                          };
            [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
            
            [self.view addSubview:_headerLabel];

            
            _attributes=@{
                          kCCText: @"Cancel",
                          kCCTextColor:COLOR_THEME_BROWN,
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0]
                          };
            
            [self.view addSubview:[ccManager() buttonWithAttributes:_attributes frame:CGRectMake(-10.0, 15.0, 90.0, 50.0) completion:^(UIButton *sender)
            {
                [self cancelButtonAction];
            }]];
           
            _frame=CGRectMake(0.0, 64.0,self.view.frame.size.width , 1.0);
            _attributes=@{
                          kCCImage:[UIImage imageNamed:@"seprator.png"]
                          };
            UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
            [self.view addSubview:_divider];
        }
        
        else
        {
            
            CGRect _frame=CGRectMake(0.0, 15.0, 190, 50.0);
            NSDictionary *_attributes;
            _attributes=@{
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                          };
            UILabel *_headerLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
            
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"CREATE PROFILE",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                          };
            [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
            
            self.navigationItem.titleView=_headerLabel;
            _attributes=@{
                          kCCText: @"Cancel",
                          kCCTextColor:COLOR_THEME_BROWN,
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0]
                          };
           
            UIButton *_cancelButton=[ccManager() buttonWithAttributes:_attributes frame:CGRectMake(0.0, 5.0, 80.0, 50.0) completion:^(UIButton *sender)
            {
                [self dismissViewControllerAnimated:YES completion:nil];
             }];
            
            
            UIBarButtonItem *_cancelButtonItem=[[UIBarButtonItem alloc]initWithCustomView:_cancelButton];
           
            UIBarButtonItem *_leftSpaceItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
            _leftSpaceItem.width = -23.0;
           
            self.navigationItem.leftBarButtonItems=[NSArray arrayWithObjects:_leftSpaceItem,_cancelButtonItem, nil];
           
            _frame=CGRectMake(0.0, 0.0,self.view.frame.size.width , 1.0);
            _attributes=@{
                          kCCImage:[UIImage imageNamed:@"seprator.png"]
                          };
            UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
            [self.view addSubview:_divider];
        }
        
        _selectedCity = @"Sydney";
        _citiesArray=[[NSMutableArray alloc]init];
        [_citiesArray addObject:@"Sydney"];
        [_citiesArray addObject:@"Brisbane"];
        [_citiesArray addObject:@"Canberra"];
        [_citiesArray addObject:@"Darwin"];
        [_citiesArray addObject:@"Gold Coast"];
        [_citiesArray addObject:@"Hobart"];
        [_citiesArray addObject:@"Melbourne"];
        [_citiesArray addObject:@"Perth"];
        
        _customKeyboard=[[CustomKeyboard alloc]init];
        _customKeyboard.delegate=self;
        
        _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0.0, _displacementFactor, self.view.frame.size.width, self.view.frame.size.height-_displacementFactor-43.5) style:UITableViewStylePlain];
        _tableView.delegate=self;
        _tableView.dataSource=self;
        _tableView.backgroundColor=[UIColor clearColor];
        _tableView.separatorColor=[UIColor clearColor];
        [self.view addSubview:_tableView];
        
        NSDictionary *_attributes=nil;
        
        CGRect _frame=CGRectMake(0.0, self.view.frame.size.height-43.5, self.view.frame.size.width, 43.5);
        _attributes=@{
                      kCCBackgroundColor:COLOR_THEME_DARKGRAY
                      };
        UIButton *_continueButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
            [self continueButtonAction];
        }];
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:1.35],
                      kASTextColor:COLOR_THEME_BROWN,
                      kASText:@"CONTINUE",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0]
                      };
        [_continueButton setAttributedTitle:[NSMutableAttributedString attributedStringWithAttributes:_attributes] forState:UIControlStateNormal];
        [self.view addSubview:_continueButton];

    }
}


#pragma mark------------------------------------------------------------
#pragma mark TABLEVIEW DELEGATE/ DATASOURCE
#pragma mark------------------------------------------------------------

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section==0)
    {
        return 2;
    }
    else if (section==2)
    {
        return 1;
    }
    else
    {
        if (_isCityPickerVisible)
        {
          return _citiesArray.count;
        }
        else
        {
            return 0;
        }
    }
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section==0)
    {
        if (indexPath.row==0)
        {
            return 250.0;
        }
        else
        {
            return 4*44;
        }
    }
    else if (indexPath.section==2)
    {
        if (_showErrorCell)
        {
            return 110.0;
        }
        else
        {
            return 0.0;
        }
    }
    else
    {
        return 40;
    }
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=[NSString stringWithFormat:@"Cell_%i_%i",(int)indexPath.section,indexPath.row];
    
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
    
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        if(indexPath.section==0)
        {
            if (indexPath.row==0)
            {
                CGRect _frame=CGRectMake(tableView.frame.size.width/2-66.0, 40.0, 132.0, 132.0);
                
                NSDictionary *_attributes=nil;
                _attributes=@{
                              kCCImage: [UIImage imageNamed:@"Add_Photo.png"]
                              };
                [_cell.contentView addSubview:[ccManager() imageViewWithAttributes:_attributes frame:_frame]];
                
                _activityIndicatorView=[[UIActivityIndicatorView alloc]initWithFrame:_frame];
                _activityIndicatorView.activityIndicatorViewStyle=UIActivityIndicatorViewStyleGray;
                [_cell.contentView addSubview:_activityIndicatorView];
                
                _attributes=@{
                              kCCText: @"ADD PHOTO",
                              kCCTextColor:COLOR_THEME_BROWN,
                              kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:13.0],
                              kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentCenter]
                              };
                
                
                if (appDelegate().userInfo.isFacebookUser)
                {
                    _isImageUpdatingRequired=YES;
                    [_activityIndicatorView startAnimating];
                    [self getAndSetFacebookProfileImage];
                }
                else
                {
                    [_cell.contentView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
                }
                
                
                
                _attributes=@{
                              kCCContentMode:[NSNumber numberWithInt:UIViewContentModeScaleAspectFill],
                              kCCCornerRadius:[NSNumber numberWithFloat:_frame.size.width/2.0],
                              kCCContentMode:[NSNumber numberWithInt:UIViewContentModeScaleAspectFill]
                              };
                _profileImageView=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
                [_cell.contentView addSubview:_profileImageView];
                
                [_cell.contentView addSubview:[ccManager() buttonWithAttributes:nil frame:_frame completion:^(UIButton *sender){
                    [self imagePickerButtonAction];
                }]];
            }
            
            else if (indexPath.row==1)
            {
                int numberOfRows=4;
                
                CGRect _frame=CGRectMake(8.0, 0.0, tableView.frame.size.width-16.0, numberOfRows*44.0);
                
                NSArray *_colors=nil;
                _colors=@[
                          COLOR_THEME_LIGHTPINK,
                          COLOR_THEME_BROWN
                          ];
                
                CustomLayer*_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMVertical];
                [_cell.contentView addSubview:_customLayer];
                
                NSDictionary *_attributes=nil;
                _attributes=@{
                              kCCBackgroundColor: [UIColor whiteColor]
                              };
                
                _frame=CGRectMake(_frame.origin.x+0.55, _frame.origin.y+0.55,_frame.size.width-1.1, _frame.size.height-1.1);
                
                UIView *_containerView=[ccManager() viewWithAttributes:_attributes frame:_frame];
                [_cell.contentView addSubview:_containerView];
                
                [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, _containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.55)]];
                
                [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, 2*(_containerView.frame.size.height/numberOfRows), _containerView.frame.size.width, 0.55)]];
                
                [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, 3*(_containerView.frame.size.height/numberOfRows), _containerView.frame.size.width, 0.55)]];
                
                _frame=CGRectMake(10.0, 0.0, tableView.frame.size.width-20.0, _containerView.frame.size.height/numberOfRows);
                UILabel *_firstNameStaticLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
                
                _attributes=@{
                              kASCharacterSpace:[NSNumber numberWithFloat:1.2],
                              kASTextColor:COLOR_THEME_BROWN,
                              kASText:@"FIRST NAME",
                              kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                              kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                              };
                
                [_firstNameStaticLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
                
                [_containerView addSubview:_firstNameStaticLabel];
                
                _attributes=@{
                              kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                              kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                              kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                              kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                              };
                
                _frame=CGRectMake(120.0, 0.0, _containerView.frame.size.width-120.0, _containerView.frame.size.height/numberOfRows);
                
                _firstNameTF=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
                [_cell.contentView addSubview:_firstNameTF];
                _firstNameTF.text=appDelegate().userInfo.firstName;
                _firstNameTF.autocapitalizationType=UITextAutocapitalizationTypeWords;
                _firstNameTF.inputAccessoryView=[_customKeyboard getToolbarWithPrevNextDone:NO :YES];
                
                
                
                _frame=CGRectMake(10.0, _containerView.frame.size.height/numberOfRows, tableView.frame.size.width-20.0, _containerView.frame.size.height/numberOfRows);
                
                UILabel *_lastNameStaticLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
                
                _attributes=@{
                              kASCharacterSpace:[NSNumber numberWithFloat:1.2],
                              kASTextColor:COLOR_THEME_BROWN,
                              kASText:@"LAST NAME",
                              kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                              kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                              };
                
                [_lastNameStaticLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
                
                [_containerView addSubview:_lastNameStaticLabel];
                
                _attributes=@{
                              kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                              kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                              kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                              kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                              };
                
                _frame=CGRectMake(120.0, _containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-120.0, _containerView.frame.size.height/numberOfRows);
                
                _lastNameTF=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
                _lastNameTF.autocapitalizationType=UITextAutocapitalizationTypeWords;
                [_cell.contentView addSubview:_lastNameTF];
                _lastNameTF.text=appDelegate().userInfo.lastName;
                
                _lastNameTF.inputAccessoryView=[_customKeyboard getToolbarWithPrevNextDone:YES :YES];
                
                
                _citiesPicker=[[UIPickerView alloc]initWithFrame:CGRectMake(0.0, 0.0, self.view.frame.size.width, 216.0)];
                _citiesPicker.delegate=self;
                _citiesPicker.dataSource=self;
                
                _frame=CGRectMake(10.0, 2*_containerView.frame.size.height/numberOfRows, tableView.frame.size.width-20.0, _containerView.frame.size.height/numberOfRows);
                
                UILabel *_cityStaticLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
                
                _attributes=@{
                              kASCharacterSpace:[NSNumber numberWithFloat:1.2],
                              kASTextColor:COLOR_THEME_BROWN,
                              kASText:@"MOBILE",
                              kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                              kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                              };
                
                [_cityStaticLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
                
                [_containerView addSubview:_cityStaticLabel];
                
                _attributes=@{
                              kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                              kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                              kCCKeyboardType:@(UIKeyboardTypeNumberPad),
                              kCCTextAlignment:@(NSTextAlignmentRight)
                              };
                
                _frame=CGRectMake(120.0, 2*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-120.0, _containerView.frame.size.height/numberOfRows);
                
                _mobileTF=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
                [_cell.contentView addSubview:_mobileTF];
                
                _mobileTF.inputAccessoryView=[_customKeyboard getToolbarWithPrevNextDone:YES :YES];
                
                
                _frame=CGRectMake(10.0, 3*_containerView.frame.size.height/numberOfRows, tableView.frame.size.width-20.0, _containerView.frame.size.height/numberOfRows);
                
                UILabel *_mobileStaticLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
                
                _attributes=@{
                              kASCharacterSpace:[NSNumber numberWithFloat:1.2],
                              kASTextColor:COLOR_THEME_BROWN,
                              kASText:@"CURRENT CITY",
                              kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                              kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                              };
                
                [_mobileStaticLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
                
                [_containerView addSubview:_mobileStaticLabel];
                
                _attributes=@{
                              kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                              kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                              kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad],
                              kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                              };
                
                
                UIImageView *_arrowImageView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"Chevron.png"]];
                _arrowImageView.frame=CGRectMake(_containerView.frame.size.width-15.0, 3*_containerView.frame.size.height/numberOfRows, 15.0, _containerView.frame.size.height/numberOfRows);
                _arrowImageView.contentMode=UIViewContentModeScaleAspectFit;
                [_cell.contentView addSubview:_arrowImageView];
                
                _frame=CGRectMake(120.0, 3*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-140.0, _containerView.frame.size.height/numberOfRows);
                
                _cityTF=[ccManager() textFieldWithAttributes:_attributes frame:_frame target:self completion:nil];
                _cityTF.text=_selectedCity;
                [_cell.contentView addSubview:_cityTF];
                
                _cityTF.inputAccessoryView=[_customKeyboard getToolbarWithPrevNextDone:YES :NO];
            }
        }
        else if (indexPath.section==1)
        {
            CGRect _frame=CGRectMake(8.0, 39.45, tableView.frame.size.width-16.0, 0.55);
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_BROWN,
                      COLOR_THEME_BROWN
                      ];
            
            CustomLayer*_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            _customLayer.tag=10001;
            [_cell.contentView addSubview:_customLayer];
            
            UIView *_leftDivider=[[UIView alloc]initWithFrame:CGRectMake(8.0, 0.0, 0.55, 40.0)];
            _leftDivider.backgroundColor=COLOR_THEME_BROWN;
            [_cell.contentView addSubview:_leftDivider];
            
            UIView *_rightDivider=[[UIView alloc]initWithFrame:CGRectMake(tableView.frame.size.width-8.55, 0.0, 0.55,
                                                                          40.0)];
            _rightDivider.backgroundColor=COLOR_THEME_BROWN;
            [_cell.contentView addSubview:_rightDivider];
            
            _cell.textLabel.font=[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0];
        }
        else if (indexPath.section==2)
        {
            _cell.textLabel.text=@"LUXit is not yet available for use in your city. We will be expanding Australia-wide in the future, so please create your account and you will be notified when LUXit is active and ready for use in your area.";
            _cell.textLabel.textAlignment=NSTextAlignmentCenter;
            _cell.textLabel.font=[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:13.0];
            _cell.textLabel.textColor=COLOR_THEME_BROWN;
            _cell.textLabel.numberOfLines=5;
        }
       
    }
    
    if (indexPath.section==1)
    {
        CustomLayer *_customLayer=(CustomLayer *)[_cell viewWithTag:10001];
        [_customLayer setHidden:YES];
        
        if (indexPath.row==_citiesArray.count-1)
        {
             [_customLayer setHidden:NO];
        }
        
        
        _cell.textLabel.text=[NSString stringWithFormat:@"  %@",[_citiesArray objectAtIndex:indexPath.row]];
        
        if ([_selectedCity isEqualToString:[_citiesArray objectAtIndex:indexPath.row]])
        {
            _cell.textLabel.textColor=COLOR_THEME_BROWN;
        }
        else
        {
            _cell.textLabel.textColor=COLOR_THEME_DARKGRAY;
        }
    }
    return _cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section==1)
    {
        _selectedCity=[_citiesArray objectAtIndex:indexPath.row];
        _cityTF.text=_selectedCity;

        if ([_selectedCity isEqualToString:@"Sydney"])
        {
            _showErrorCell=NO;
        }
        else
        {
            _showErrorCell=YES;
        }
        
        _isCityPickerVisible=NO;
        [_tableView reloadData];
        
        if (_showErrorCell)
        {
         [_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:2] atScrollPosition:UITableViewScrollPositionTop animated:YES];
        }
    }
}


- (void)getAndSetFacebookProfileImage
{
    NSString *_imagePath=[NSString stringWithFormat:FBIconImagePath,appDelegate().userInfo.fbId,@"300",@"300"];
    [_activityIndicatorView startAnimating];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^(void)
    {
        NSData *_imgData = [NSData dataWithContentsOfURL:[NSURL URLWithString:_imagePath]];
        UIImage *__image = [UIImage imageWithData:_imgData];
        dispatch_sync(dispatch_get_main_queue(), ^(void)
        {
            if(__image!=nil && _isImageUpdatingRequired)
            {
                [_activityIndicatorView stopAnimating];
                _profileImageView.image=__image;
            }
        });
    });
}


#pragma mark------------------------------------------------------------
#pragma mark CUSTOM KEYBOARD DELEGATE
#pragma mark------------------------------------------------------------

-(void)customKeyboardAction:(ActioType)action
{
    if (action==ATNext)
    {
        if ([_firstNameTF isFirstResponder])
        {
            [_lastNameTF becomeFirstResponder];
        }
        else if ([_lastNameTF isFirstResponder])
        {
            [_mobileTF becomeFirstResponder];
        }
        else if ([_mobileTF isFirstResponder])
        {
            [self showExpendedView];
        }
    }
    else  if (action==ATPrevious)
    {
        if ([_mobileTF isFirstResponder])
        {
            [_lastNameTF becomeFirstResponder];
        }
        else if ([_lastNameTF isFirstResponder])
        {
            [_firstNameTF becomeFirstResponder];
        }
    }
    else
    {
        [self resetView];
    }
}


#pragma mark------------------------------------------------------------
#pragma mark TEXTFIELD DELEGATEs
#pragma mark------------------------------------------------------------

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField==_firstNameTF)
    {
        [_lastNameTF becomeFirstResponder];
    }
    else if (textField==_lastNameTF)
    {
        [_mobileTF becomeFirstResponder];
    }
    return YES;
}


- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    _tableView.frame=CGRectMake(0.0, _tableView.frame.origin.y, _tableView.frame.size.width, self.view.frame.size.height-_tableView.frame.origin.y-216.0-50.0);
    [_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0] atScrollPosition:UITableViewScrollPositionMiddle animated:NO];
    
    if (textField==_cityTF)
    {
        [self showExpendedView];
    }
}


- (void)resetView
{
    _tableView.frame=CGRectMake(0.0, _tableView.frame.origin.y, _tableView.frame.size.width, self.view.frame.size.height-_tableView.frame.origin.y-50.0);
    [_cityTF resignFirstResponder];
    [_firstNameTF resignFirstResponder];
    [_lastNameTF resignFirstResponder];
    [_mobileTF resignFirstResponder];
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONs
#pragma mark------------------------------------------------------------

- (void)continueButtonAction
{
    [self validateAndRegister];
}


- (void)cancelButtonAction
{
    [ccManager() showAlertWithTitle:@"Cancel Sign Up?" message:@"By cancelling, your profile or email will not be saved" buttons:[NSArray arrayWithObjects:@"No",@"Yes", nil] completion:^(NSInteger buttonIndex)
     {
         if (buttonIndex==1)
         {
             [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"UserInfo"];
             [[NSUserDefaults standardUserDefaults]synchronize];
             
             [appDelegate().userInfo updateWithAttributes:nil];
             
             [appDelegate() showAppHomeViewController];

         }
     }];
}


- (void)imagePickerButtonAction
{
    UIActionSheet *_actionSheet=[[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Take Photo",@"Photo Library", nil];
    [_actionSheet showInView:self.view];
}


- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex==0)
    {
        [self callCamera];
    }
    else if (buttonIndex==1)
    {
        [self callPhotoLibrary];
    }
}


- (void)callCamera
{
    [self resetView];
   
    AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if(status == AVAuthorizationStatusAuthorized)
    {
        [self showCamera];
    }
    else if(status == AVAuthorizationStatusDenied)
    {
        NSArray *_buttonsArray=@[@"Close",@"Go to Settings"];
        
        [ccManager() showAlertWithTitle:@"Change your Settings to allow LUXit to Access to Your Camera" message:@"We need to have access to your camera to take a New Photo. Please go to the App Settings and allow Camera." buttons:_buttonsArray completion:^(NSInteger buttonIndex)
         {
              if ([[_buttonsArray objectAtIndex:buttonIndex]isEqualToString:@"Go to Settings"])
             {
                 [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
             }
         }];
    }
    else if(status == AVAuthorizationStatusRestricted)
    {
        NSArray *_buttonsArray=@[@"Close",@"Go to Settings"];

        [ccManager() showAlertWithTitle:@"Change your Settings to allow LUXit to Access to Your Camera" message:@"We need to have access to your camera to take a New Photo. Please go to the App Settings and allow Camera." buttons:_buttonsArray completion:^(NSInteger buttonIndex)
         {
             if ([[_buttonsArray objectAtIndex:buttonIndex]isEqualToString:@"Go to Settings"])
             {
                 [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
             }
         }];
    }
    else if(status == AVAuthorizationStatusNotDetermined)
    {
        [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
            if(granted)
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self  showCamera];
                });
            }
            else
            {
                NSArray *_buttonsArray=@[@"Close",@"Go to Settings"];
                
                [ccManager() showAlertWithTitle:@"Change your Settings to allow LUXit to Access to Your Camera" message:@"We need to have access to your camera to take a New Photo. Please go to the App Settings and allow Camera." buttons:_buttonsArray completion:^(NSInteger buttonIndex)
                 {
                     if ([[_buttonsArray objectAtIndex:buttonIndex]isEqualToString:@"Go to Settings"])
                     {
                         [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
                     }
                 }];
            }
        }];
    }
}
- (void)showCamera
{
    if (_imagePicker==nil)
    {
        _imagePicker=[[UIImagePickerController alloc]init];
        _imagePicker.sourceType=UIImagePickerControllerSourceTypeCamera;
        _imagePicker.delegate=self;
        _imagePicker.allowsEditing=YES;
        [self presentViewController:_imagePicker animated:NO completion:nil];
    }
    else
    {
        _imagePicker.sourceType=UIImagePickerControllerSourceTypeCamera;
        [self presentViewController:_imagePicker animated:NO completion:nil];
    }
}


- (void)callPhotoLibrary
{
    [self resetView];
    
    AVAuthorizationStatus status = [ALAssetsLibrary authorizationStatus];
    
    if(status == AVAuthorizationStatusAuthorized)
    {
        [self showPhotoLibrary];
    }
    else if(status == AVAuthorizationStatusDenied)
    {
        NSArray *_buttonsArray=@[@"Close",@"Go to Settings"];
        
        [ccManager() showAlertWithTitle:@"Change your Settings to allow LUXit to Access to Your Photos" message:@"We need to have access to your photos to select a Photo.Please go to the App Settings and allow Photos." buttons:_buttonsArray completion:^(NSInteger buttonIndex)
         {
             if ([[_buttonsArray objectAtIndex:buttonIndex]isEqualToString:@"Go to Settings"])
             {
                 [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
             }
         }];
    }
    else if(status == AVAuthorizationStatusRestricted)
    {
        NSArray *_buttonsArray=@[@"Close",@"Go to Settings"];

        [ccManager() showAlertWithTitle:@"Change your Settings to allow LUXit to Access to Your Photos" message:@"We need to have access to your photos to select a Photo.Please go to the App Settings and allow Photos." buttons:_buttonsArray completion:^(NSInteger buttonIndex)
         {
             if ([[_buttonsArray objectAtIndex:buttonIndex]isEqualToString:@"Go to Settings"])
             {
                 [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
             }
         }];
    }
    else if(status == AVAuthorizationStatusNotDetermined)
    {
       [self  showPhotoLibrary];
    }
}


- (void)showPhotoLibrary
{
    if (_imagePicker==nil)
    {
        _imagePicker=[[UIImagePickerController alloc]init];
        _imagePicker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
        _imagePicker.delegate=self;
        _imagePicker.allowsEditing=YES;
        [self presentViewController:_imagePicker animated:NO completion:nil];
    }
    else
    {
        _imagePicker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentViewController:_imagePicker animated:NO completion:nil];
    }
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [picker dismissViewControllerAnimated:YES completion:nil];
    _profileImageView.image=[info objectForKey:UIImagePickerControllerEditedImage];
    _isImageUpdatingRequired=NO;
    [_activityIndicatorView stopAnimating];
}


- (void)validateAndRegister
{
    NSString *_firstName=[_firstNameTF.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *_lastName=[_lastNameTF.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *_mobile=[_mobileTF.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSString *_city =[_cityTF.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    id        _image=@"";
   
    if (_firstName.length==0 && _lastName.length==0 && _mobile.length==0 && _city.length==0)
    {
        [ccManager() showAlertWithTitle:@"Fill in all the fields" message:@"Please fill in all fields to continue" buttons:nil completion:nil];
        return;
    }
    if (_firstName.length==0)
    {
        [ccManager() showAlertWithTitle:@"First Name" message:@"Your First Name is required" buttons:nil completion:nil];
        return;
    }
    if (_lastName.length==0)
    {
        [ccManager() showAlertWithTitle:@"Last Name" message:@"Your Last Name is required" buttons:nil completion:nil];
        return;
    }
    if (_city.length==0)
    {
        [ccManager() showAlertWithTitle:@"Last Name" message:@"Your City is required" buttons:nil completion:nil];
        return;
    }
    if (_mobile.length==0)
    {
        [ccManager() showAlertWithTitle:@"Mobile" message:@"Your Mobile is required and needs to be digits only" buttons:nil completion:nil];
        return;
    }
    
    if (_profileImageView.image==nil && !appDelegate().userInfo.isFacebookUser)
    {
        [ccManager() showAlertWithTitle:@"Profile Picture" message:@"Your Profile Picture is required" buttons:nil completion:nil];
        return;
    }

    
    if (_profileImageView.image!=nil)
    {
        _image=_profileImageView.image;
    }
    
    [self resetView];
    
    NSDictionary *_attributes=@{
                                @"firstName":_firstName,
                                @"lastName":_lastName,
                                @"mobile":_mobile,
                                @"image":_image,
                                @"userId":appDelegate().userInfo.userId,
                                @"city":_city
                                };
  
    [progressHud() showWithTitle:@"Please wait"];
    
    [API() updateUserInfoWithAttributes:_attributes completion:^(BOOL success, NSError *error)
     {
         if (success)
         {
             [progressHud() showWithTitle:@"Success\nYour account info updated successfully"];
             [self performSelector:@selector(hideProgessHud:) withObject:[NSNumber numberWithBool:success] afterDelay:1.5];
         }
         else
         {
             [progressHud() hide];
             [ccManager() showAlertWithTitle:[[error userInfo] objectForKey:@"title"] message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
         }
     }];
}


- (void)hideProgessHud:(NSNumber *)success
{
    if ([success intValue]==1)
    {
        [[NSUserDefaults standardUserDefaults]setObject:[NSMutableDictionary dictionaryWithCapacity:0] forKey:@"LastJobDetail"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        [ccManager() showAlertWithTitle:@"Add Payment Options" message:@"To perform this action, we require you to add a payment option." buttons:[NSArray arrayWithObjects:@"Cancel",@"Add Payment", nil] completion:^(NSInteger buttonIndex)
         {
             if (buttonIndex==1)
             {
                 LAAddPaymentTypeVC *_addPaymentVC=[[LAAddPaymentTypeVC alloc]init];
                 _addPaymentVC.typeMode=PTNew;
                 [self.navigationController pushViewController:_addPaymentVC animated:YES];
             }
             else
             {
                 [appDelegate() showUserHomeViewController];
             }
         }];
    }
    [progressHud() hide];
}


- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}


- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return _citiesArray.count;
}


- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [_citiesArray objectAtIndex:row];
}


- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    _cityTF.text=[_citiesArray objectAtIndex:row];
}


- (void)showExpendedView
{
     [self resetView];
    if (_isCityPickerVisible)
    {
        [self hideExpendedView];
        return;
    }

    _isCityPickerVisible=YES;
    [_tableView reloadData];
    [_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:1] atScrollPosition:UITableViewScrollPositionTop animated:YES];
}

- (void)hideExpendedView
{
    _isCityPickerVisible=NO;
    [_tableView reloadSections:[NSIndexSet indexSetWithIndex:1] withRowAnimation:UITableViewRowAnimationAutomatic];
}

@end
