//
//  PaymentMode.m
//  Luxit
//
//  Created by GP on 28/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "PaymentMode.h"

@implementation PaymentMode

- (void)updateWithAttributes:(NSDictionary *)attributes
{
    if (attributes.allKeys.count>0)
    {
        _isPaymentModeAvailable=YES;
        
        if ([[[attributes objectForKey:@"type"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] isEqualToString:@"credit card"])
        {
            _type=PTCreditCard;
           
            _cardNumber=[[attributes objectForKey:@"card_no"]stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        }
        else
        {
            _type=PTPaypal;
           
            _email=[attributes objectForKey:@"paypal_email"];
        }
    }
    else
    {
        _isPaymentModeAvailable=NO;
    }
}

@end
