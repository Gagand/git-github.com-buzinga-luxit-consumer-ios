//
//  LATechnicianSearchVC.m
//  Luxit
//
//  Created by GP on 27/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "Constant.h"
#import "LAUserHomeVC.h"
#import "LATechnicianSearchVC.h"
#import "LAParentViewController.h"

@implementation LATechnicianSearchVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    [progressHud() hide];
    
    self.view.backgroundColor=[UIColor clearColor];
 
    self.navigationItem.hidesBackButton=YES;
   
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"Menu.png"] style:UIBarButtonItemStylePlain target:self action:@selector(menuButtonAction)];
   
    CGRect _frame=CGRectMake(0.0, 15.0, 190, 50.0);
   
    UILabel *_headerLabel=[ccManager() labelWithAttributes:nil frame:_frame];
    
    NSDictionary *_attributes;
    _attributes=@{
                  kASCharacterSpace:[NSNumber numberWithFloat:3.0],
                  kASTextColor:COLOR_THEME_BROWN,
                  kASText:[[appDelegate().jobDetail.itemName stringByReplacingOccurrencesOfString:@"\n" withString:@" "] uppercaseString],
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0]
                  };
    [_headerLabel setAttributedText:[NSMutableAttributedString attributedStringWithAttributes:_attributes]];
    
    self.navigationItem.titleView=_headerLabel;
    
    _frame=CGRectMake(0.0, 0.0,self.view.frame.size.width , 1.0);
    _attributes=@{
                  kCCImage:[UIImage imageNamed:@"seprator.png"]
                  };
    UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
    [self.view addSubview:_divider];
    
    appDelegate().updateAppStatus=^(AppStatus status){
        if (status==ASForeground)
        {
            [self checkCalculateTimeInterval];
        }
    };
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (_tableView==nil)
    {
        NSDictionary *_attributes=nil;
   
        _attributes=@{
                      kCCBackgroundColor:[UIColor colorWithRed:221.0/255.0 green:220.0/255.0 blue:220.0/255.0 alpha:1.0]
                      };
        CGRect _frame=CGRectMake(0.0, 0.0, self.view.frame.size.width, 22.0);
       
        UILabel *_staticSearchLabel=[ccManager() labelWithAttributes:_attributes frame:_frame];
        
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:0.52/2.0],
                      kASTextColor:[UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                      kASText:@"Searching",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_BOLD size:13.0]
                      };
        
        _staticSearchLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
        
        [self.view addSubview:_staticSearchLabel];
 
        _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0.0, 22.0, self.view.frame.size.width, self.view.frame.size.height-50.0-22.0) style:UITableViewStylePlain];
        _tableView.delegate=self;
        _tableView.dataSource=self;
        _tableView.backgroundColor=[UIColor clearColor];
        _tableView.separatorColor=[UIColor clearColor];
        [self.view addSubview:_tableView];
        
         _frame=CGRectMake(0.0, self.view.frame.size.height-43.5, self.view.frame.size.width, 43.5);
        _attributes=@{
                      kCCBackgroundColor:COLOR_THEME_DARKGRAY
                      };
        UIButton *_continueButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
           [self cancelBookingButtonAction];
        }];
        _attributes=@{
                      kASCharacterSpace:[NSNumber numberWithFloat:1.35],
                      kASTextColor:COLOR_THEME_BROWN,
                      kASText:@"CANCEL BOOKING",
                      kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:18.0]
                      };
        [_continueButton setAttributedTitle:[NSMutableAttributedString attributedStringWithAttributes:_attributes] forState:UIControlStateNormal];
        [self.view addSubview:_continueButton];
        
    }
    [self checkCalculateTimeInterval];
}


- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(checkJobStatus) object:nil];
}


- (void)checkCalculateTimeInterval
{
    if (appDelegate().jobDetail.status==JSCancelByTechnician)
    {
        [self checkJobStatus];
        return;
    }
    
    NSDate *_savedDate=[appDelegate().jobDetail.date copy];
    _savedDate = [_savedDate dateByAddingTimeInterval:appDelegate().jobDetail.timeInterval*60];
  
    NSDate *_currentDate=[NSDate date];

    NSTimeInterval _interval = [_savedDate timeIntervalSinceDate:_currentDate];

   [self performSelector:@selector(checkJobStatus) withObject:nil afterDelay:_interval];
    
    if (_interval>0)
    {
        [self silentAPICheck];
    }
}


- (void)silentAPICheck
{
    NSDictionary *_attributes=@{
                                @"userId":appDelegate().userInfo.userId
                                };
    [API() fetchLastCreatedJobStatusWithAttributes:_attributes completion:^(BOOL success,NSError *error){
        if (success)
        {
            if (appDelegate().jobDetail.changed)
            {
                [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(checkJobStatus) object:nil];
                [self.menuContainerViewController switchView];
            }
        }
    }];
}


- (void)checkJobStatus
{
    [progressHud() showWithTitle:@"Please wait"];
    NSDictionary *_attributes=@{
                                @"userId":appDelegate().userInfo.userId
                                };
    [API() fetchLastCreatedJobStatusWithAttributes:_attributes completion:^(BOOL success,NSError *error){
        if (success)
        {
            if (appDelegate().jobDetail.changed)
            {
                [self.menuContainerViewController switchView];
            }
            else
            {
                NSDate *_savedDate=[appDelegate().jobDetail.date copy];
                _savedDate = [_savedDate dateByAddingTimeInterval:appDelegate().jobDetail.timeInterval*60];
                
                NSDate *_currentDate=[NSDate date];
                
                NSTimeInterval _interval = [_savedDate timeIntervalSinceDate:_currentDate];
                
                if (_interval<0)
                {
                    LATimeExtendVC *_extendtimeVC=[[LATimeExtendVC alloc]init];
                    
                    if (appDelegate().jobDetail.status==JSSearching)
                    {
                        _extendtimeVC.type=ETSimple;
                    }
                    else
                    {
                        _extendtimeVC.type=ETUponCancellation;
                    }
                    
                    _extendtimeVC.finishedUpdatingJob=^()
                    {
                        [self checkJobStatus];
                    };
                    
                    _extendtimeVC.finishedCancellingJob=^()
                    {
                        [self.menuContainerViewController switchView];
                    };
                    
                    _extendtimeVC.view.backgroundColor = [UIColor clearColor];
                    _extendtimeVC.providesPresentationContextTransitionStyle = YES;
                    [_extendtimeVC setModalPresentationStyle:UIModalPresentationOverCurrentContext];
                    [self.navigationController presentViewController:_extendtimeVC animated:NO completion:nil];
                }
   
            }
        }
        else
        {
            [ccManager() showAlertWithTitle:[[error userInfo] objectForKey:@"title"] message:[[error userInfo] objectForKey:@"description"] buttons:@[@"Retry"] completion:^(NSInteger buttonIndex)
            {
                [self checkJobStatus];
            }];
        }
    }];
}


#pragma mark------------------------------------------------------------
#pragma mark TABLEVIEW DELEGATE/ DATASOURCE
#pragma mark------------------------------------------------------------

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0)
    {
        return 250.0;
    }
    else
    {
        return 132.0;
    }
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=[NSString stringWithFormat:@"Cell_%i",(int)indexPath.row];
    
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
    
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        if (indexPath.row==0)
        {
            CGRect _frame;
            
            NSDictionary *_attributes=nil;

            _frame=CGRectMake(0.0, 9.5, tableView.frame.size.width, 13.0);
           
            UILabel *_staticSearchInfoLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.48/2.0],
                          kASTextColor:[UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kASText:@"Searching for your technician nearby.",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0]
                          };
            _staticSearchInfoLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            
            [_cell.contentView addSubview:_staticSearchInfoLabel];
            
            _frame=CGRectMake(tableView.frame.size.width/2-12.0, _frame.origin.y+_frame.size.height+7.5, 24.0, 0.5);
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                     COLOR_THEME_LIGHTPINK
                      ];
            CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
            _customLayer.alpha=0.8;
            [_cell.contentView addSubview:_customLayer];
            
            _frame=CGRectMake(tableView.frame.size.width/2-145.0/2,53.5, 145.0, 145.0);
            _attributes=@{
                          kCCImage: [UIImage imageNamed:@"Logo_Search.png"]
                          };
            [_cell.contentView addSubview:[ccManager() imageViewWithAttributes:_attributes frame:_frame]];
            
        }
        
        else if (indexPath.row==1)
        {
            int numberOfRows=3;
            
            NSDictionary *_attributes=nil;
            
            CGRect _frame=CGRectMake(8.0, 0.0, tableView.frame.size.width-16.0, 132.0);
            
            NSArray *_colors=nil;
            _colors=@[
                      COLOR_THEME_LIGHTPINK,
                      COLOR_THEME_BROWN
                      ];
            
            CustomLayer*_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMVertical];
            [_cell.contentView addSubview:_customLayer];
            
            
            _attributes=@{
                          kCCBackgroundColor: [UIColor whiteColor]
                          };
            
            _frame=CGRectMake(_frame.origin.x+0.5, _frame.origin.y+0.5,_frame.size.width-1.0, _frame.size.height-1.0);
            UIView *_containerView=[ccManager() viewWithAttributes:_attributes frame:_frame];
            [_cell.contentView addSubview:_containerView];
            

            [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, _containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.5)]];
            
            [_containerView addSubview:[ccManager() viewWithAttributes:@{kCCBackgroundColor: COLOR_THEME_BROWN} frame:CGRectMake(0.0, 2*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width, 0.5)]];
            

            _frame=CGRectMake(16.0, 0.0, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"DATE",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticDateLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticDateLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticDateLabel];
            
          
            
            _attributes=@{
                          kCCText: appDelegate().jobDetail.dateString,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];

   
            _frame=CGRectMake(16.0, _containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"TIME",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticTimeLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticTimeLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticTimeLabel];
            
            
            _attributes=@{
                          kCCText: appDelegate().jobDetail.timeString,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCReturnKey:[NSNumber numberWithInt:UIReturnKeyNext],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
            [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
  

            _frame=CGRectMake(16.0, 2*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-32.0, _containerView.frame.size.height/numberOfRows);
            
            _attributes=@{
                          kASCharacterSpace:[NSNumber numberWithFloat:0.65/2.0],
                          kASTextColor:COLOR_THEME_BROWN,
                          kASText:@"ADDRESS",
                          kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                          };
            UILabel *_staticAddressLabel=[ccManager() labelWithAttributes:nil frame:_frame];
            _staticAddressLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
            [_containerView addSubview:_staticAddressLabel];
         
            _frame=CGRectMake(90.0, 2*_containerView.frame.size.height/numberOfRows, _containerView.frame.size.width-105.0, _containerView.frame.size.height/numberOfRows);
            _attributes=@{
                          kCCText: appDelegate().jobDetail.location,
                          kCCTextColor: [UIColor colorWithRed:34.0/255.0 green:34.0/255.0 blue:34.0/255.0 alpha:1.0],
                          kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                          kCCKeyboardType:[NSNumber numberWithInt:UIKeyboardTypeNumberPad],
                          kCCTextAlignment:[NSNumber numberWithInt:NSTextAlignmentRight]
                          };
            
           [_containerView addSubview:[ccManager() labelWithAttributes:_attributes frame:_frame]];
            
        }
    }
    return _cell;
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONS
#pragma mark------------------------------------------------------------

- (void)menuButtonAction
{

    [self.menuContainerViewController openSideMenu];
}


- (void)cancelBookingButtonAction
{
    [ccManager() showAlertWithTitle:@"Do you wish to Cancel the Booking?" message:@"" buttons:[NSArray arrayWithObjects:@"No",@"Yes", nil] completion:^(NSInteger buttonIndex)
     {
         if (buttonIndex==1)
         {
             [self cancelJob];
         }
     }];
}


- (void)cancelJob
{
    [progressHud() showWithTitle:@"Please wait"];

    NSDictionary *_attributes=@{
                                @"userId":appDelegate().userInfo.userId,
                                @"jobId":appDelegate().jobDetail.jobId,
                                @"status":@"2",
                                @"comment":@""
                                };
    [API() cancelJobWithAttributes:_attributes completion:^(BOOL success,NSError *error,BOOL invalid){
        
        if (success)
        {
            [appDelegate().jobDetail resetJobDetails];
            
            [self.menuContainerViewController switchView];
            
            if (!appDelegate().jobDetail.isPaidByPaypal)
            {
                [progressHud() hide];
            }
        }
        else
        {
            if (invalid)
            {
                [progressHud() showWithTitle:@"Please wait"];
                
                NSDictionary *_attributes=@{
                                            @"userId":appDelegate().userInfo.userId
                                            };
                [API() fetchLastCreatedJobStatusWithAttributes:_attributes completion:^(BOOL success,NSError *error1)
                 {
                     [progressHud() hide];
                    
                     if (success)
                     {
                         [self.menuContainerViewController switchView];
                     }
                     else
                     {
                         [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
                     }
                 }];
                return;
            }
           
            [progressHud() hide];
         
            [ccManager() showAlertWithTitle:@"Error" message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:nil];
        }
    }];
}

@end
