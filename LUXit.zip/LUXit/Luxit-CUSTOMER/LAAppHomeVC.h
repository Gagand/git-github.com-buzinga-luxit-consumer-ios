//
//  LAAppHomeVC.h
//  Luxit
//
//  Created by GP on 20/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CCPageControl.h"

@interface LAAppHomeVC : UIViewController<UIScrollViewDelegate>
{
    UIScrollView *_scrollView;
    CCPageControl*_customPageController;
    BOOL                    _upward;
}

@end
