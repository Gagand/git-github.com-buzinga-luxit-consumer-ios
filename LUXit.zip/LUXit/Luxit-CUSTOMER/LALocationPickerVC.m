//
//  LALocationPickerVC.m
//  Luxit
//
//  Created by GP on 21/08/15.
//  Copyright (c) 2015 Luxit. All rights reserved.
//

#import "LALocationPickerVC.h"
#import "Constant.h"

@implementation LALocationPickerVC

#pragma mark------------------------------------------------------------
#pragma mark VIEW LIFE CYCLE
#pragma mark------------------------------------------------------------

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    _locationsArray=[[NSMutableArray alloc]init];
    _searchQuery = [[SPGooglePlacesAutocompleteQuery alloc] init];
    _searchQuery.radius = 100.0;
    
    self.view.backgroundColor=[UIColor whiteColor];

    NSDictionary *_attributes=nil;
   
    CGRect _frame=CGRectMake(16.0, 28.5, self.view.frame.size.width-90.0, 22.0);
    
    NSArray *_colors=nil;
    _colors=@[
               COLOR_THEME_BROWN,
               COLOR_THEME_LIGHTPINK
              ];
    CustomLayer *_customLayer=[[CustomLayer alloc]initWithFrame:_frame withColors:_colors gradientMode:GMHorizontal];
    [self.view addSubview:_customLayer];
    
    _frame=CGRectMake(16.5, 29, self.view.frame.size.width-91.0, 21.0);
    _attributes=@{
                  kCCBackgroundColor: [UIColor whiteColor]
                  };
    UIView *_containerView=[ccManager() viewWithAttributes:_attributes frame:_frame];
    [self.view addSubview:_containerView];
    

    _attributes=@{
                  kCCImage:[UIImage imageNamed:@"location.png"],
                  kCCContentMode:[NSNumber numberWithInt:UIViewContentModeScaleAspectFit]
                  };
   _frame=CGRectMake(5.0, 4.0, 10, 14.0);
    [_containerView addSubview:[ccManager() imageViewWithAttributes:_attributes frame:_frame]];
  
    _attributes=@{
                  kCCText:@"x",
                  kCCTextColor:COLOR_THEME_BROWN,
                  kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:15.0]
                  };
    _frame=CGRectMake(0.0, 0.0, 20.0, 20.0);
    UIButton *_closeButton=[ccManager() buttonWithAttributes:_attributes frame:_frame completion:^(UIButton *sender){
        _searchTF.text=@"";
    }];
    
    _attributes=@{
                  kCCRightView:_closeButton,
                  kCCTextColor: COLOR_THEME_BROWN,
                  kCCTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0],
                  kCCPlaceHolderColor:[UIColor colorWithRed:169.0/255.0  green:120.0/255.0   blue:67.0/255.0  alpha:0.5],
                  kCCPlaceHolderText:@"Enter appointment location",
                  kCCReturnKey:[NSNumber numberWithInt:UIReturnKeySearch]
                  };
    _searchTF=[ccManager() textFieldWithAttributes:_attributes frame:CGRectMake(12.0, 0.0, _containerView.frame.size.width-8.0, _containerView.frame.size.height) target:self completion:nil];
    [_containerView addSubview:_searchTF];
    [_searchTF becomeFirstResponder];
    
    if (appDelegate().userInfo.location.isLocatioAvailable)
    {
        _searchTF.text=appDelegate().userInfo.location.address;
    }
 

    _attributes=@{
                  kASTextColor: COLOR_THEME_BROWN,
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_REGULAR size:12.0],
                  kASText:@"Cancel",
                  kASCharacterSpace:[NSNumber numberWithFloat:1.2]
                  };
    _frame=CGRectMake(self.view.frame.size.width-80.0, 15.0, 80.0, 50.0);
    UIButton *_cancelButton=[ccManager() buttonWithAttributes:nil frame:_frame completion:^(UIButton *sender){
        [self dismissViewControllerAnimated:YES completion:nil];
    }];
    [_cancelButton setAttributedTitle:[NSMutableAttributedString attributedStringWithAttributes:_attributes] forState:UIControlStateNormal];
    [self.view addSubview:_cancelButton];
   
   
    _frame=CGRectMake(0.0, 65.0,self.view.frame.size.width , 1.0);
    _attributes=@{
                  kCCImage:[UIImage imageNamed:@"seprator.png"]
                  };
    UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
    [self.view addSubview:_divider];
    

    _frame=CGRectMake(16.0, 66.0, self.view.frame.size.width-32.0, 40.0);
    UILabel *_mycurrentLocationStaticLabel=[ccManager() labelWithAttributes:nil frame:_frame];
    _attributes=@{
                  kASTextColor: COLOR_THEME_BROWN,
                  kASTextFont:[UIFont fontWithName:FONT_AVENIRNEXT_DEMI size:12.0],
                  kASText:@"My Current Location",
                  kASCharacterSpace:[NSNumber numberWithFloat:0.3],
                  kASTextAlignment:[NSNumber numberWithInt:NSTextAlignmentLeft]
                  };
    _mycurrentLocationStaticLabel.attributedText=[NSMutableAttributedString attributedStringWithAttributes:_attributes];
   
    [self.view addSubview:_mycurrentLocationStaticLabel];
    
    [self.view addSubview:[ccManager() buttonWithAttributes:nil frame:_frame completion:^(UIButton *sender){
        [self mycurrentLocationButtonAction];
    }]];
    

    _frame=CGRectMake(0.0, 105.0,self.view.frame.size.width , 1.0);
    _attributes=@{
                  kCCImage:[UIImage imageNamed:@"seprator.png"]
                  };
    _divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
    [self.view addSubview:_divider];
 
    
    _frame=CGRectMake(.0, 106.0, self.view.frame.size.width, self.view.frame.size.height-106.0-216.0);
    _tableView=[[UITableView alloc]initWithFrame:_frame style:UITableViewStylePlain];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    _tableView.backgroundColor=[UIColor clearColor];
    _tableView.separatorColor=[UIColor clearColor];
    [self.view addSubview:_tableView];
    
    [self findKey];
}


#pragma mark------------------------------------------------------------
#pragma mark TABLEVIEW DELEGATE/ DATASOURCE
#pragma mark------------------------------------------------------------

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _locationsArray.count;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44.0;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *_cellIdentifier=[NSString stringWithFormat:@"Cell_%i",(int)indexPath.row];
    
    UITableViewCell *_cell=[tableView dequeueReusableCellWithIdentifier:_cellIdentifier];
    
    if (_cell==nil)
    {
        _cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:_cellIdentifier];
        _cell.backgroundColor=[UIColor clearColor];
        _cell.selectionStyle=UITableViewCellSelectionStyleNone;
        
        _cell.textLabel.font=[UIFont fontWithName:FONT_AVENIRNEXT_MEDIUM size:12.0];
        _cell.textLabel.numberOfLines=3;
        _cell.textLabel.textColor=[UIColor colorWithRed:175.0/255.0 green:131.0/255.0 blue:84.0/255.0 alpha:1.0];
        
        
        CGRect _frame;
        NSDictionary *_attributes;
        _frame=CGRectMake(0.0, 43.0,tableView.frame.size.width , 1.0);
        _attributes=@{
                      kCCImage:[UIImage imageNamed:@"seprator.png"]
                      };
        UIImageView *_divider=[ccManager() imageViewWithAttributes:_attributes frame:_frame];
        [_cell.contentView addSubview:_divider];
        
    }
    
    _cell.textLabel.text=[_locationsArray objectAtIndex:indexPath.row];
    
    return _cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [progressHud() showWithTitle:@"Please wait"];
    
    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        CLLocationCoordinate2D searchLocation = [self geoCodeUsingAddress:[_locationsArray objectAtIndex:indexPath.row]];
        dispatch_async(dispatch_get_main_queue(), ^
        {
            
            CGFloat _lat=searchLocation.latitude;
            CGFloat _lng=searchLocation.longitude;
            
            NSMutableDictionary *_dict=[NSMutableDictionary dictionaryWithCapacity:3];
            [_dict setObject:[_locationsArray objectAtIndex:indexPath.row] forKey:@"Address"];
            [_dict setObject:[[NSNumber numberWithDouble:_lat]stringValue] forKey:@"Lat"];
            [_dict setObject:[[NSNumber numberWithDouble:_lng]stringValue] forKey:@"Lng"];
           
            [API() fetchPostalCodeForAddress:[_locationsArray objectAtIndex:indexPath.row] completion:^(BOOL success, NSString *postalCode)
            {
                if (success)
                {
                    [API() checkPostalCode:postalCode completion:^(BOOL success, NSError *error)
                    {
                        [progressHud() hide];
                        if (success)
                        {
                            [[NSUserDefaults standardUserDefaults]setObject:_dict forKey:@"MySelectedLocation"];
                             [[NSUserDefaults standardUserDefaults]synchronize];
                            
                             [appDelegate().userInfo updateLocationWithAttributes:_dict];
                            
                              [self dismissViewControllerAnimated:YES completion:nil];
                            
                        }
                        else
                        {
                            [ccManager() showAlertWithTitle:[[error userInfo] objectForKey:@"title"] message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:^(NSInteger buttonIndex){
                            _searchTF.text=@"";
                            }];
                        }
                    }];
                }
                else
                {
                    [progressHud() hide];
                    [ccManager() showAlertWithTitle:@"Error" message:@"Fail to fetch postal code for selected location. Please try again" buttons:nil completion:nil];
                }
            }];
          
        });
    });
}
// get lattitude and logitude from location name
- (CLLocationCoordinate2D) geoCodeUsingAddress:(NSString *)address
{
    NSString *esc_addr =  [address stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
   
    NSString *req = [NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?sensor=false&address=%@", esc_addr];
   
    NSData *_responseData=[NSData dataWithContentsOfURL:[NSURL URLWithString:req]];
    
    double _lLat=0.0;
    double _lLng=0.0;
   
    NSDictionary *_responseDictionary=[NSJSONSerialization JSONObjectWithData:_responseData options:0 error:nil];
   
    if ([[_responseDictionary objectForKey:@"status"]isEqualToString:@"OK"])
    {
        NSArray *_resultArray=[_responseDictionary objectForKey:@"results"];
       
        if (_resultArray.count>0)
        {
            if([[[_resultArray objectAtIndex:0]allKeys]containsObject:@"geometry"])
            {
                NSDictionary *_geometry=[[_resultArray objectAtIndex:0]objectForKey:@"geometry"];
               
                if ([[_geometry allKeys]containsObject:@"location"])
                {
                    NSDictionary *_location=[_geometry objectForKey:@"location"];
                    _lLat=[[_location objectForKey:@"lat"]doubleValue];
                    _lLng=[[_location objectForKey:@"lng"]doubleValue];
                    
                }
            }
        }
    }
    
    CLLocationCoordinate2D center;
    center.latitude = _lLat;
    center.longitude = _lLng;
    return center;
}

#pragma mark------------------------------------------------------------
#pragma mark TEXTFIELD DELEGATE
#pragma mark------------------------------------------------------------

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    _tableView.frame=CGRectMake(.0, 106.0, self.view.frame.size.width, self.view.frame.size.height-106.0-216.0);
}


- (void)textFieldDidEndEditing:(UITextField *)textField
{
    _tableView.frame=CGRectMake(.0, 106.0, self.view.frame.size.width, self.view.frame.size.height-106.0);
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    [self performSelector:@selector(findKey) withObject:nil afterDelay:0.1];
    return YES;
}


-(void)findKey
{
    if([_searchTF.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]].length>0)
    {
        _searchQuery.input = _searchTF.text;
        [_searchQuery fetchPlaces:^(NSArray *places, NSError *error)
        {
            if (!error)
            {
                [_locationsArray removeAllObjects];
                [_locationsArray addObjectsFromArray:[places valueForKey:@"name"]];
                [_tableView reloadData];
            }
        }];
    }
}


#pragma mark------------------------------------------------------------
#pragma mark BUTTON ACTIONS
#pragma mark------------------------------------------------------------

- (void)mycurrentLocationButtonAction
{
    
    NSLog(@"authorizationStatus %d",[CLLocationManager authorizationStatus]);
    
    
    if ([CLLocationManager authorizationStatus]==kCLAuthorizationStatusAuthorizedAlways||[CLLocationManager authorizationStatus]==kCLAuthorizationStatusAuthorizedWhenInUse)
    {
        if ([[NSUserDefaults standardUserDefaults]objectForKey:@"MyCurrentLocation"]!=NULL)
        {
            NSString *_addressString=[[[NSUserDefaults standardUserDefaults]objectForKey:@"MyCurrentLocation"]objectForKey:@"Address"];
            [API() fetchPostalCodeForAddress:_addressString completion:^(BOOL success, NSString *postalCode)
             {
                 if (success)
                 {
                     [API() checkPostalCode:postalCode completion:^(BOOL success, NSError *error)
                      {
                          [progressHud() hide];
                          
                          if (success)
                          {
                              [[NSUserDefaults standardUserDefaults]setObject:[[NSUserDefaults standardUserDefaults]objectForKey:@"MyCurrentLocation"] forKey:@"MySelectedLocation"];
                              [[NSUserDefaults standardUserDefaults]synchronize];
                              
                              [appDelegate().userInfo updateLocationWithAttributes:[[NSUserDefaults standardUserDefaults]objectForKey:@"MyCurrentLocation"]];
                              
                              [self dismissViewControllerAnimated:YES completion:nil];
                              
                          }
                          else
                          {
                              [ccManager() showAlertWithTitle:[[error userInfo] objectForKey:@"title"] message:[[error userInfo] objectForKey:@"description"] buttons:nil completion:^(NSInteger buttonIndex){
                                  _searchTF.text=@"";
                              }];
                          }
                      }];
                 }
                 else
                 {
                     [progressHud() hide];
                    
                     [ccManager() showAlertWithTitle:@"Error" message:@"Fail to fetch postal code for selected location. Please try again" buttons:nil completion:nil];
                 }
             }];
        }
        else
        {
            NSArray *_buttonsArray=@[@"Close",@"Go to Settings"];

            [ccManager() showAlertWithTitle:@"Change your Settings to allow LUXit to Access to Your Current Location" message:@"We need to know your current location  to provide an accurate service and find the closest technicians around you. Please go to the App Settings, tap on Location and then select Always." buttons:_buttonsArray completion:^(NSInteger buttonIndex){
                 if ([[_buttonsArray objectAtIndex:buttonIndex]isEqualToString:@"Go to Settings"])
                {
                    NSURL *settingsURL = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
                    [[UIApplication sharedApplication] openURL:settingsURL];
                }
            }];
        }
    }
    else
    {
        NSArray *_buttonsArray=@[@"Close",@"Go to Settings"];

        [ccManager() showAlertWithTitle:@"Change your Settings to allow LUXit to Access to Your Current Location" message:@"We need to know your current location  to provide an accurate service and find the closest technicians around you. Please go to the App Settings, tap on Location and then select Always." buttons:_buttonsArray completion:^(NSInteger buttonIndex){
            if ([[_buttonsArray objectAtIndex:buttonIndex]isEqualToString:@"Go to Settings"])
            {
                NSURL *settingsURL = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
                [[UIApplication sharedApplication] openURL:settingsURL];
            }
        }];
    }
}


@end
